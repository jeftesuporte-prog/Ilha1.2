#include "VkEngine.h"
#include "HudFont.h"
#include <android/log.h>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include "Cfg.h"
#include "ChunkMat.h"
#include "TexGen.h"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "Ilha", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "Ilha", __VA_ARGS__)
#define VKOK(call) do { VkResult _r = (call); if (_r != VK_SUCCESS) { LOGE("Vulkan erro %d em %s (%s:%d)", (int)_r, #call, __FILE__, __LINE__); return false; } } while (0)

namespace {
// Mesmo layout do bloco "Frame" dos shaders (std140): mat4 + 5 vec4.
struct FrameUBO {
    float viewProj[16];
    float camPos[4];
    float toLight[4];
    float lightColor[4];
    float ambient[4];
    float fogColor[4];
    float params[4];
    // ---- céu e reflexo (mesmo layout do bloco "Frame" de sky.frag / shine.frag) ----
    float invPV[16];
    float top[4];       // rgb, w = tw
    float hor[4];
    float sun[4];
    float sunH[4];
    float warm1[4];
    float warm2[4];
    float warm3[4];
    float halo[4];
    float sunE[4];
    float sunN[4];
    float sunP[4];      // x = raio do disco, y = achatamento
    float sunCol[4];
    float moon[4];
    float sunGlit[4];
    float moonGlit[4];
    float shine[4];     // x = força do reflexo
    float wind[4];      // x = tempo do vento, y = rajada, zw = direção (wind.vert)
};
static_assert(sizeof(FrameUBO) == 496, "FrameUBO precisa ter 496 bytes (std140)");
struct WaterPC { float trans[4]; float uvx[4]; };   // push constants: deslocamento+opacidade, transformação de UV
static_assert(sizeof(WaterPC) == 32, "push constants de 32 bytes");
constexpr bool kCullBackFaces = false;   // Etapa 4: sem culling (garante que o terreno apareça). Ligue (true) depois de ver que está tudo certo.
constexpr uint32_t kVertexStride = 9 * sizeof(float);   // x y z | nx ny nz | cor RGBA8 | u v
// bytes por vértice de cada material de chunk (7 floats = sem UV; 10 = com dados de vento)
inline uint32_t strideBytes(int mat) { return static_cast<uint32_t>(ChunkMat::strideOf(mat)) * sizeof(float); }
}  // namespace

// ============================================================================
//  utilitários
// ============================================================================
std::vector<uint8_t> VkEngine::loadAsset(const char* name) const {
    std::vector<uint8_t> data;
    AAsset* a = AAssetManager_open(assets_, name, AASSET_MODE_BUFFER);
    if (!a) { LOGE("Asset nao encontrado: %s", name); return data; }
    off_t len = AAsset_getLength(a);
    data.resize(static_cast<size_t>(len));
    AAsset_read(a, data.data(), static_cast<size_t>(len));
    AAsset_close(a);
    return data;
}

VkShaderModule VkEngine::loadShader(const char* name) const {
    std::vector<uint8_t> code = loadAsset(name);
    if (code.empty() || code.size() % 4 != 0) return VK_NULL_HANDLE;
    VkShaderModuleCreateInfo ci{};
    ci.sType = VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO;
    ci.codeSize = code.size();
    ci.pCode = reinterpret_cast<const uint32_t*>(code.data());
    VkShaderModule m = VK_NULL_HANDLE;
    if (vkCreateShaderModule(device_, &ci, nullptr, &m) != VK_SUCCESS) return VK_NULL_HANDLE;
    return m;
}

uint32_t VkEngine::findMemType(uint32_t typeBits, VkMemoryPropertyFlags props) const {
    for (uint32_t i = 0; i < memProps_.memoryTypeCount; i++) {
        if ((typeBits & (1u << i)) && (memProps_.memoryTypes[i].propertyFlags & props) == props) return i;
    }
    return 0xFFFFFFFFu;
}

bool VkEngine::createBuffer(VkDeviceSize size, VkBufferUsageFlags usage, VkMemoryPropertyFlags props, VkBuffer& buf, VkDeviceMemory& mem) const {
    VkBufferCreateInfo bi{};
    bi.sType = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO;
    bi.size = size;
    bi.usage = usage;
    bi.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    VKOK(vkCreateBuffer(device_, &bi, nullptr, &buf));
    VkMemoryRequirements mr;
    vkGetBufferMemoryRequirements(device_, buf, &mr);
    uint32_t type = findMemType(mr.memoryTypeBits, props);
    if (type == 0xFFFFFFFFu) { LOGE("Sem tipo de memoria adequado"); return false; }
    VkMemoryAllocateInfo ai{};
    ai.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
    ai.allocationSize = mr.size;
    ai.memoryTypeIndex = type;
    VKOK(vkAllocateMemory(device_, &ai, nullptr, &mem));
    VKOK(vkBindBufferMemory(device_, buf, mem, 0));
    return true;
}

VkCommandBuffer VkEngine::beginOneShot() const {
    VkCommandBufferAllocateInfo ai{};
    ai.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;
    ai.commandPool = cmdPool_;
    ai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    ai.commandBufferCount = 1;
    VkCommandBuffer cb = VK_NULL_HANDLE;
    vkAllocateCommandBuffers(device_, &ai, &cb);
    VkCommandBufferBeginInfo bi{};
    bi.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;
    bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    vkBeginCommandBuffer(cb, &bi);
    return cb;
}

void VkEngine::endOneShot(VkCommandBuffer cb) const {
    vkEndCommandBuffer(cb);
    VkSubmitInfo si{};
    si.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;
    si.commandBufferCount = 1;
    si.pCommandBuffers = &cb;
    vkQueueSubmit(queue_, 1, &si, VK_NULL_HANDLE);
    vkQueueWaitIdle(queue_);
    vkFreeCommandBuffers(device_, cmdPool_, 1, &cb);
}

void VkEngine::destroyMesh(GpuMesh& m) const {
    if (m.buf) vkDestroyBuffer(device_, m.buf, nullptr);
    if (m.mem) vkFreeMemory(device_, m.mem, nullptr);
    m = GpuMesh{};
}

// ============================================================================
//  instância, surface e dispositivo
// ============================================================================
bool VkEngine::createInstance() {
    VkApplicationInfo app{};
    app.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
    app.pApplicationName = "Ilha";
    app.applicationVersion = 1;
    app.pEngineName = "IlhaEngine";
    app.engineVersion = 1;
    app.apiVersion = VK_API_VERSION_1_0;
    const char* exts[] = {VK_KHR_SURFACE_EXTENSION_NAME, VK_KHR_ANDROID_SURFACE_EXTENSION_NAME};
    VkInstanceCreateInfo ci{};
    ci.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
    ci.pApplicationInfo = &app;
    ci.enabledExtensionCount = 2;
    ci.ppEnabledExtensionNames = exts;
    VKOK(vkCreateInstance(&ci, nullptr, &instance_));
    return true;
}

bool VkEngine::createSurfaceAndDevice(ANativeWindow* window) {
    VkAndroidSurfaceCreateInfoKHR sci{};
    sci.sType = VK_STRUCTURE_TYPE_ANDROID_SURFACE_CREATE_INFO_KHR;
    sci.window = window;
    VKOK(vkCreateAndroidSurfaceKHR(instance_, &sci, nullptr, &surface_));
    return createDevice();
}

bool VkEngine::createDevice() {
    uint32_t count = 0;
    VKOK(vkEnumeratePhysicalDevices(instance_, &count, nullptr));
    if (count == 0) { LOGE("Nenhuma GPU com Vulkan"); return false; }
    std::vector<VkPhysicalDevice> devs(count);
    VKOK(vkEnumeratePhysicalDevices(instance_, &count, devs.data()));

    for (VkPhysicalDevice d : devs) {
        uint32_t qn = 0;
        vkGetPhysicalDeviceQueueFamilyProperties(d, &qn, nullptr);
        std::vector<VkQueueFamilyProperties> qf(qn);
        vkGetPhysicalDeviceQueueFamilyProperties(d, &qn, qf.data());
        for (uint32_t i = 0; i < qn; i++) {
            VkBool32 present = VK_FALSE;
            vkGetPhysicalDeviceSurfaceSupportKHR(d, i, surface_, &present);
            if ((qf[i].queueFlags & VK_QUEUE_GRAPHICS_BIT) && present) { phys_ = d; queueFamily_ = i; break; }
        }
        if (phys_) break;
    }
    if (!phys_) { LOGE("Nenhuma fila grafica com apresentacao"); return false; }

    VkPhysicalDeviceProperties props;
    vkGetPhysicalDeviceProperties(phys_, &props);
    LOGI("GPU: %s (Vulkan %u.%u)", props.deviceName, VK_VERSION_MAJOR(props.apiVersion), VK_VERSION_MINOR(props.apiVersion));
    vkGetPhysicalDeviceMemoryProperties(phys_, &memProps_);
    VkPhysicalDeviceFeatures feats;
    vkGetPhysicalDeviceFeatures(phys_, &feats);
    anisotropy_ = feats.samplerAnisotropy == VK_TRUE;
    maxAniso_ = std::min(4.0f, props.limits.maxSamplerAnisotropy);

    float prio = 1.0f;
    VkDeviceQueueCreateInfo qci{};
    qci.sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO;
    qci.queueFamilyIndex = queueFamily_;
    qci.queueCount = 1;
    qci.pQueuePriorities = &prio;

    VkPhysicalDeviceFeatures enabled{};
    enabled.samplerAnisotropy = anisotropy_ ? VK_TRUE : VK_FALSE;
    const char* devExts[] = {VK_KHR_SWAPCHAIN_EXTENSION_NAME};
    VkDeviceCreateInfo dci{};
    dci.sType = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO;
    dci.queueCreateInfoCount = 1;
    dci.pQueueCreateInfos = &qci;
    dci.enabledExtensionCount = 1;
    dci.ppEnabledExtensionNames = devExts;
    dci.pEnabledFeatures = &enabled;
    VKOK(vkCreateDevice(phys_, &dci, nullptr, &device_));
    vkGetDeviceQueue(device_, queueFamily_, 0, &queue_);
    return true;
}

// ============================================================================
//  swapchain, profundidade, render pass, framebuffers
// ============================================================================
bool VkEngine::createRenderPass() {
    VkAttachmentDescription at[2]{};
    at[0].format = colorFormat_;
    at[0].samples = VK_SAMPLE_COUNT_1_BIT;
    at[0].loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
    at[0].storeOp = VK_ATTACHMENT_STORE_OP_STORE;
    at[0].stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
    at[0].stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    at[0].initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    at[0].finalLayout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;
    at[1].format = depthFormat_;
    at[1].samples = VK_SAMPLE_COUNT_1_BIT;
    at[1].loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
    at[1].storeOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    at[1].stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
    at[1].stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    at[1].initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    at[1].finalLayout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL;

    VkAttachmentReference colorRef{0, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL};
    VkAttachmentReference depthRef{1, VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL};
    VkSubpassDescription sub{};
    sub.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS;
    sub.colorAttachmentCount = 1;
    sub.pColorAttachments = &colorRef;
    sub.pDepthStencilAttachment = &depthRef;

    VkSubpassDependency dep{};
    dep.srcSubpass = VK_SUBPASS_EXTERNAL;
    dep.dstSubpass = 0;
    dep.srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT | VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT;
    dep.dstStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT | VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT;
    dep.srcAccessMask = 0;
    dep.dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT | VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;

    VkRenderPassCreateInfo rpi{};
    rpi.sType = VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO;
    rpi.attachmentCount = 2;
    rpi.pAttachments = at;
    rpi.subpassCount = 1;
    rpi.pSubpasses = &sub;
    rpi.dependencyCount = 1;
    rpi.pDependencies = &dep;
    VKOK(vkCreateRenderPass(device_, &rpi, nullptr, &renderPass_));
    return true;
}

bool VkEngine::createSwapchain() {
    VkSurfaceCapabilitiesKHR caps;
    VKOK(vkGetPhysicalDeviceSurfaceCapabilitiesKHR(phys_, surface_, &caps));
    extent_ = caps.currentExtent;
    if (extent_.width == 0xFFFFFFFFu || extent_.width == 0 || extent_.height == 0) { LOGE("Janela sem tamanho valido"); extent_ = {0, 0}; return false; }

    // formato de cor: UNORM (sem correção sRGB automática, igual ao libGDX)
    uint32_t fn = 0;
    vkGetPhysicalDeviceSurfaceFormatsKHR(phys_, surface_, &fn, nullptr);
    std::vector<VkSurfaceFormatKHR> fmts(fn);
    vkGetPhysicalDeviceSurfaceFormatsKHR(phys_, surface_, &fn, fmts.data());
    VkSurfaceFormatKHR chosen = fmts[0];
    for (const auto& f : fmts) {
        if ((f.format == VK_FORMAT_R8G8B8A8_UNORM || f.format == VK_FORMAT_B8G8R8A8_UNORM) && f.colorSpace == VK_COLORSPACE_SRGB_NONLINEAR_KHR) { chosen = f; break; }
    }
    if (renderPass_ != VK_NULL_HANDLE && chosen.format != colorFormat_) { LOGE("Formato da surface mudou"); return false; }
    colorFormat_ = chosen.format;

    // formato de profundidade
    if (depthFormat_ == VK_FORMAT_UNDEFINED) {
        const VkFormat cands[] = {VK_FORMAT_D32_SFLOAT, VK_FORMAT_X8_D24_UNORM_PACK32, VK_FORMAT_D24_UNORM_S8_UINT, VK_FORMAT_D16_UNORM};
        for (VkFormat f : cands) {
            VkFormatProperties fp;
            vkGetPhysicalDeviceFormatProperties(phys_, f, &fp);
            if (fp.optimalTilingFeatures & VK_FORMAT_FEATURE_DEPTH_STENCIL_ATTACHMENT_BIT) { depthFormat_ = f; break; }
        }
        if (depthFormat_ == VK_FORMAT_UNDEFINED) { LOGE("Sem formato de profundidade"); return false; }
    }

    uint32_t imageCount = caps.minImageCount + 1;
    if (caps.maxImageCount > 0 && imageCount > caps.maxImageCount) imageCount = caps.maxImageCount;

    VkCompositeAlphaFlagBitsKHR alpha = VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR;
    const VkCompositeAlphaFlagBitsKHR alphas[] = {VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR, VK_COMPOSITE_ALPHA_INHERIT_BIT_KHR,
                                                  VK_COMPOSITE_ALPHA_PRE_MULTIPLIED_BIT_KHR, VK_COMPOSITE_ALPHA_POST_MULTIPLIED_BIT_KHR};
    for (auto a : alphas) if (caps.supportedCompositeAlpha & a) { alpha = a; break; }

    VkSwapchainCreateInfoKHR sci{};
    sci.sType = VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR;
    sci.surface = surface_;
    sci.minImageCount = imageCount;
    sci.imageFormat = chosen.format;
    sci.imageColorSpace = chosen.colorSpace;
    sci.imageExtent = extent_;
    sci.imageArrayLayers = 1;
    sci.imageUsage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;
    sci.imageSharingMode = VK_SHARING_MODE_EXCLUSIVE;
    // IDENTITY: o sistema gira a imagem se preciso (mais simples; a pré-rotação fica para a etapa de otimização)
    sci.preTransform = (caps.supportedTransforms & VK_SURFACE_TRANSFORM_IDENTITY_BIT_KHR) ? VK_SURFACE_TRANSFORM_IDENTITY_BIT_KHR : caps.currentTransform;
    sci.compositeAlpha = alpha;
    sci.presentMode = VK_PRESENT_MODE_FIFO_KHR;   // vsync (sempre disponível)
    sci.clipped = VK_TRUE;
    VKOK(vkCreateSwapchainKHR(device_, &sci, nullptr, &swapchain_));

    uint32_t n = 0;
    vkGetSwapchainImagesKHR(device_, swapchain_, &n, nullptr);
    images_.resize(n);
    vkGetSwapchainImagesKHR(device_, swapchain_, &n, images_.data());

    views_.resize(n);
    for (uint32_t i = 0; i < n; i++) {
        VkImageViewCreateInfo vi{};
        vi.sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO;
        vi.image = images_[i];
        vi.viewType = VK_IMAGE_VIEW_TYPE_2D;
        vi.format = colorFormat_;
        vi.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
        VKOK(vkCreateImageView(device_, &vi, nullptr, &views_[i]));
    }

    // imagem de profundidade
    const bool hasStencil = depthFormat_ == VK_FORMAT_D24_UNORM_S8_UINT;
    VkImageCreateInfo di{};
    di.sType = VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO;
    di.imageType = VK_IMAGE_TYPE_2D;
    di.format = depthFormat_;
    di.extent = {extent_.width, extent_.height, 1};
    di.mipLevels = 1;
    di.arrayLayers = 1;
    di.samples = VK_SAMPLE_COUNT_1_BIT;
    di.tiling = VK_IMAGE_TILING_OPTIMAL;
    di.usage = VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT;
    di.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    di.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    VKOK(vkCreateImage(device_, &di, nullptr, &depthImage_));
    VkMemoryRequirements mr;
    vkGetImageMemoryRequirements(device_, depthImage_, &mr);
    uint32_t mt = findMemType(mr.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    if (mt == 0xFFFFFFFFu) mt = findMemType(mr.memoryTypeBits, 0);
    VkMemoryAllocateInfo mai{};
    mai.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
    mai.allocationSize = mr.size;
    mai.memoryTypeIndex = mt;
    VKOK(vkAllocateMemory(device_, &mai, nullptr, &depthMem_));
    VKOK(vkBindImageMemory(device_, depthImage_, depthMem_, 0));
    VkImageViewCreateInfo dv{};
    dv.sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO;
    dv.image = depthImage_;
    dv.viewType = VK_IMAGE_VIEW_TYPE_2D;
    dv.format = depthFormat_;
    dv.subresourceRange = {static_cast<VkImageAspectFlags>(VK_IMAGE_ASPECT_DEPTH_BIT | (hasStencil ? VK_IMAGE_ASPECT_STENCIL_BIT : 0)), 0, 1, 0, 1};
    VKOK(vkCreateImageView(device_, &dv, nullptr, &depthView_));

    if (renderPass_ == VK_NULL_HANDLE && !createRenderPass()) return false;

    framebuffers_.resize(n);
    for (uint32_t i = 0; i < n; i++) {
        VkImageView atts[2] = {views_[i], depthView_};
        VkFramebufferCreateInfo fi{};
        fi.sType = VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO;
        fi.renderPass = renderPass_;
        fi.attachmentCount = 2;
        fi.pAttachments = atts;
        fi.width = extent_.width;
        fi.height = extent_.height;
        fi.layers = 1;
        VKOK(vkCreateFramebuffer(device_, &fi, nullptr, &framebuffers_[i]));
    }

    // um semáforo "render terminou" por imagem da swapchain
    renderDone_.resize(n);
    for (uint32_t i = 0; i < n; i++) {
        VkSemaphoreCreateInfo si{};
        si.sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO;
        VKOK(vkCreateSemaphore(device_, &si, nullptr, &renderDone_[i]));
    }
    LOGI("Swapchain %ux%u, %u imagens", extent_.width, extent_.height, n);
    return true;
}

void VkEngine::destroySwapchain() {
    if (!device_) return;
    vkDeviceWaitIdle(device_);
    for (auto s : renderDone_) vkDestroySemaphore(device_, s, nullptr);
    renderDone_.clear();
    for (auto f : framebuffers_) vkDestroyFramebuffer(device_, f, nullptr);
    framebuffers_.clear();
    if (depthView_) vkDestroyImageView(device_, depthView_, nullptr);
    if (depthImage_) vkDestroyImage(device_, depthImage_, nullptr);
    if (depthMem_) vkFreeMemory(device_, depthMem_, nullptr);
    depthView_ = VK_NULL_HANDLE; depthImage_ = VK_NULL_HANDLE; depthMem_ = VK_NULL_HANDLE;
    for (auto v : views_) vkDestroyImageView(device_, v, nullptr);
    views_.clear();
    images_.clear();
    if (swapchain_) vkDestroySwapchainKHR(device_, swapchain_, nullptr);
    swapchain_ = VK_NULL_HANDLE;
}

bool VkEngine::recreateSwapchain() {
    destroySwapchain();
    return createSwapchain();
}

// ============================================================================
//  pipeline do terreno, descritores, quadros em voo
// ============================================================================
bool VkEngine::createFrameResources() {
    VkCommandPoolCreateInfo pi{};
    pi.sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO;
    pi.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
    pi.queueFamilyIndex = queueFamily_;
    VKOK(vkCreateCommandPool(device_, &pi, nullptr, &cmdPool_));

    VkCommandBufferAllocateInfo ai{};
    ai.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;
    ai.commandPool = cmdPool_;
    ai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    ai.commandBufferCount = MAX_FRAMES;
    VKOK(vkAllocateCommandBuffers(device_, &ai, cmd_));

    for (int i = 0; i < MAX_FRAMES; i++) {
        VkFenceCreateInfo fi{};
        fi.sType = VK_STRUCTURE_TYPE_FENCE_CREATE_INFO;
        fi.flags = VK_FENCE_CREATE_SIGNALED_BIT;
        VKOK(vkCreateFence(device_, &fi, nullptr, &inFlight_[i]));
        VkSemaphoreCreateInfo si{};
        si.sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO;
        VKOK(vkCreateSemaphore(device_, &si, nullptr, &imageAvail_[i]));
        if (!createBuffer(sizeof(FrameUBO), VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT,
                          VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, ubo_[i], uboMem_[i])) return false;
        VKOK(vkMapMemory(device_, uboMem_[i], 0, sizeof(FrameUBO), 0, &uboPtr_[i]));
    }

    // layouts: set 0 = bloco "Frame" (UBO); set 1 = textura do material
    VkDescriptorSetLayoutBinding b0{};
    b0.binding = 0;
    b0.descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
    b0.descriptorCount = 1;
    b0.stageFlags = VK_SHADER_STAGE_VERTEX_BIT | VK_SHADER_STAGE_FRAGMENT_BIT;
    VkDescriptorSetLayoutCreateInfo l0{};
    l0.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO;
    l0.bindingCount = 1;
    l0.pBindings = &b0;
    VKOK(vkCreateDescriptorSetLayout(device_, &l0, nullptr, &frameLayout_));

    VkDescriptorSetLayoutBinding b1{};
    b1.binding = 0;
    b1.descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER;
    b1.descriptorCount = 1;
    b1.stageFlags = VK_SHADER_STAGE_FRAGMENT_BIT;
    VkDescriptorSetLayoutCreateInfo l1{};
    l1.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO;
    l1.bindingCount = 1;
    l1.pBindings = &b1;
    VKOK(vkCreateDescriptorSetLayout(device_, &l1, nullptr, &matLayout_));

    VkDescriptorPoolSize ps[2]{};
    ps[0].type = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
    ps[0].descriptorCount = MAX_FRAMES;
    ps[1].type = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER;
    ps[1].descriptorCount = 10;
    VkDescriptorPoolCreateInfo dpi{};
    dpi.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO;
    dpi.maxSets = MAX_FRAMES + 10;
    dpi.poolSizeCount = 2;
    dpi.pPoolSizes = ps;
    VKOK(vkCreateDescriptorPool(device_, &dpi, nullptr, &descPool_));

    for (int i = 0; i < MAX_FRAMES; i++) {
        VkDescriptorSetAllocateInfo dsa{};
        dsa.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO;
        dsa.descriptorPool = descPool_;
        dsa.descriptorSetCount = 1;
        dsa.pSetLayouts = &frameLayout_;
        VKOK(vkAllocateDescriptorSets(device_, &dsa, &frameSet_[i]));
        VkDescriptorBufferInfo bi{ubo_[i], 0, sizeof(FrameUBO)};
        VkWriteDescriptorSet w{};
        w.sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
        w.dstSet = frameSet_[i];
        w.dstBinding = 0;
        w.descriptorCount = 1;
        w.descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
        w.pBufferInfo = &bi;
        vkUpdateDescriptorSets(device_, 1, &w, 0, nullptr);
    }
    return true;
}

VkPipeline VkEngine::buildPipeline(const char* shaderName, int vertexInput, int blendMode, int depthMode, bool depthBias, bool noCull) {
    char vsPath[96], fsPath[96];
    std::snprintf(vsPath, sizeof(vsPath), "shaders/%s.vert.spv", shaderName);
    std::snprintf(fsPath, sizeof(fsPath), "shaders/%s.frag.spv", shaderName);
    VkShaderModule vs = loadShader(vsPath);
    VkShaderModule fs = loadShader(fsPath);
    if (!vs || !fs) {
        LOGE("Falha ao carregar shaders (%s / %s)", vsPath, fsPath);
        if (vs) vkDestroyShaderModule(device_, vs, nullptr);
        if (fs) vkDestroyShaderModule(device_, fs, nullptr);
        return VK_NULL_HANDLE;
    }

    VkPipelineShaderStageCreateInfo st[2]{};
    st[0].sType = st[1].sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    st[0].stage = VK_SHADER_STAGE_VERTEX_BIT;   st[0].module = vs; st[0].pName = "main";
    st[1].stage = VK_SHADER_STAGE_FRAGMENT_BIT; st[1].module = fs; st[1].pName = "main";

    // vertexInput 1 = 9 floats (pos, normal, cor, uv) | 2 = 7 floats (pos, normal, cor) | 3 = 10 floats (7 + a_wind vec3)
    const uint32_t stride = vertexInput == 4 ? sizeof(HudVertex) : vertexInput == 2 ? 7 * sizeof(float) : vertexInput == 3 ? 10 * sizeof(float) : kVertexStride;
    VkVertexInputBindingDescription bind{0, stride, VK_VERTEX_INPUT_RATE_VERTEX};
    VkVertexInputAttributeDescription attr[4]{};
    attr[0] = {0, 0, VK_FORMAT_R32G32B32_SFLOAT, 0};
    attr[1] = {1, 0, VK_FORMAT_R32G32B32_SFLOAT, 12};
    attr[2] = {2, 0, VK_FORMAT_R8G8B8A8_UNORM, 24};
    if (vertexInput == 4) {                                                       // HUD: pos(2) uv(2) cor RGBA8
        attr[0] = {0, 0, VK_FORMAT_R32G32_SFLOAT, 0};
        attr[1] = {1, 0, VK_FORMAT_R32G32_SFLOAT, 8};
        attr[2] = {2, 0, VK_FORMAT_R8G8B8A8_UNORM, 16};
    }
    if (vertexInput == 3) attr[3] = {3, 0, VK_FORMAT_R32G32B32_SFLOAT, 28};    // a_wind
    else                  attr[3] = {3, 0, VK_FORMAT_R32G32_SFLOAT, 28};       // uv (só o terreno usa)
    VkPipelineVertexInputStateCreateInfo vin{};
    vin.sType = VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO;
    if (vertexInput != 0) {
        vin.vertexBindingDescriptionCount = 1;
        vin.pVertexBindingDescriptions = &bind;
        vin.vertexAttributeDescriptionCount = (vertexInput == 2 || vertexInput == 4) ? 3 : 4;      // vegetação simples não tem o 4º atributo
        vin.pVertexAttributeDescriptions = attr;
    }

    VkPipelineInputAssemblyStateCreateInfo ia{};
    ia.sType = VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO;
    ia.topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;

    VkPipelineViewportStateCreateInfo vp{};
    vp.sType = VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO;
    vp.viewportCount = 1;
    vp.scissorCount = 1;

    VkPipelineRasterizationStateCreateInfo rs{};
    rs.sType = VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO;
    rs.polygonMode = VK_POLYGON_MODE_FILL;
    // terreno: ver kCullBackFaces; céu, mar, espuma e reflexo nunca têm culling (como no original)
    rs.cullMode = (depthMode == 1 && kCullBackFaces && !noCull) ? VK_CULL_MODE_BACK_BIT : VK_CULL_MODE_NONE;
    rs.frontFace = VK_FRONT_FACE_COUNTER_CLOCKWISE;   // a projeção já inverte o Y; a imagem sai igual ao OpenGL
    rs.lineWidth = 1.0f;
    if (depthBias) {                                  // glPolygonOffset(-1, -2) do reflexo
        rs.depthBiasEnable = VK_TRUE;
        rs.depthBiasConstantFactor = -2.0f;
        rs.depthBiasSlopeFactor = -1.0f;
    }

    VkPipelineMultisampleStateCreateInfo ms{};
    ms.sType = VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO;
    ms.rasterizationSamples = VK_SAMPLE_COUNT_1_BIT;

    VkPipelineDepthStencilStateCreateInfo ds{};
    ds.sType = VK_STRUCTURE_TYPE_PIPELINE_DEPTH_STENCIL_STATE_CREATE_INFO;
    ds.depthTestEnable = depthMode != 0 ? VK_TRUE : VK_FALSE;
    ds.depthWriteEnable = depthMode == 1 ? VK_TRUE : VK_FALSE;
    ds.depthCompareOp = depthMode == 1 ? VK_COMPARE_OP_LESS : VK_COMPARE_OP_LESS_OR_EQUAL;

    VkPipelineColorBlendAttachmentState cba{};
    cba.colorWriteMask = VK_COLOR_COMPONENT_R_BIT | VK_COLOR_COMPONENT_G_BIT | VK_COLOR_COMPONENT_B_BIT | VK_COLOR_COMPONENT_A_BIT;
    if (blendMode != 0) {
        cba.blendEnable = VK_TRUE;
        const VkBlendFactor src = blendMode == 1 ? VK_BLEND_FACTOR_SRC_ALPHA : VK_BLEND_FACTOR_ONE;   // 2 = alfa pré-multiplicado
        cba.srcColorBlendFactor = src;
        cba.dstColorBlendFactor = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA;
        cba.colorBlendOp = VK_BLEND_OP_ADD;
        cba.srcAlphaBlendFactor = VK_BLEND_FACTOR_ONE;
        cba.dstAlphaBlendFactor = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA;
        cba.alphaBlendOp = VK_BLEND_OP_ADD;
    }
    VkPipelineColorBlendStateCreateInfo cb{};
    cb.sType = VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO;
    cb.attachmentCount = 1;
    cb.pAttachments = &cba;

    const VkDynamicState dyn[] = {VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR};
    VkPipelineDynamicStateCreateInfo dsi{};
    dsi.sType = VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO;
    dsi.dynamicStateCount = 2;
    dsi.pDynamicStates = dyn;

    VkGraphicsPipelineCreateInfo gp{};
    gp.sType = VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO;
    gp.stageCount = 2;
    gp.pStages = st;
    gp.pVertexInputState = &vin;
    gp.pInputAssemblyState = &ia;
    gp.pViewportState = &vp;
    gp.pRasterizationState = &rs;
    gp.pMultisampleState = &ms;
    gp.pDepthStencilState = &ds;
    gp.pColorBlendState = &cb;
    gp.pDynamicState = &dsi;
    gp.layout = pipeLayout_;
    gp.renderPass = renderPass_;
    gp.subpass = 0;
    VkPipeline pipe = VK_NULL_HANDLE;
    VkResult r = vkCreateGraphicsPipelines(device_, VK_NULL_HANDLE, 1, &gp, nullptr, &pipe);
    vkDestroyShaderModule(device_, vs, nullptr);
    vkDestroyShaderModule(device_, fs, nullptr);
    if (r != VK_SUCCESS) { LOGE("vkCreateGraphicsPipelines(%s) falhou: %d", shaderName, (int)r); return VK_NULL_HANDLE; }
    return pipe;
}

bool VkEngine::createPipeline() {
    // layout único para todos os pipelines: set 0 = bloco "Frame", set 1 = textura, 32 bytes de push constants
    VkDescriptorSetLayout layouts[2] = {frameLayout_, matLayout_};
    VkPushConstantRange pcr{};
    pcr.stageFlags = VK_SHADER_STAGE_VERTEX_BIT | VK_SHADER_STAGE_FRAGMENT_BIT;
    pcr.offset = 0;
    pcr.size = sizeof(WaterPC);
    VkPipelineLayoutCreateInfo pl{};
    pl.sType = VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO;
    pl.setLayoutCount = 2;
    pl.pSetLayouts = layouts;
    pl.pushConstantRangeCount = 1;
    pl.pPushConstantRanges = &pcr;
    VKOK(vkCreatePipelineLayout(device_, &pl, nullptr, &pipeLayout_));

    pipeline_  = buildPipeline("terrain", true,  0, 1, false);   // opaco, escreve profundidade
    skyPipe_   = buildPipeline("sky",     false, 0, 0, false);   // tela cheia, sem profundidade
    waterPipe_ = buildPipeline("water",   true,  1, 2, false);   // mar/espuma: alfa, testa mas não escreve profundidade
    shinePipe_ = buildPipeline("shine",   false, 2, 2, true);    // reflexo: alfa pré-multiplicado + depth bias
    rockPipe_  = buildPipeline("terrain", 1, 0, 1, false, true); // pedras: igual ao terreno, mas sem culling (GL_NONE no original)
    decoPipe_  = buildPipeline("deco",    2, 0, 1, false, true); // árvores, arbustos, flores: cor de vértice
    palmPipe_  = buildPipeline("wind",    3, 0, 1, false, true); // coqueiros e árvores: cor de vértice + balanço do vento
    hudPipe_   = buildPipeline("hud",     4, 1, 0, false, true); // camada 2D: alfa, sem profundidade
    return pipeline_ && skyPipe_ && waterPipe_ && shinePipe_ && rockPipe_ && decoPipe_ && palmPipe_ && hudPipe_;
}

// ============================================================================
//  texturas (TexGen -> imagem Vulkan com mipmaps)
// ============================================================================
bool VkEngine::createTexture(const uint8_t* rgba, int w, int h, Tex& out, bool mipmaps) {
    const VkFormat fmt = VK_FORMAT_R8G8B8A8_UNORM;
    VkFormatProperties fp;
    vkGetPhysicalDeviceFormatProperties(phys_, fmt, &fp);
    const VkFormatFeatureFlags need = VK_FORMAT_FEATURE_BLIT_SRC_BIT | VK_FORMAT_FEATURE_BLIT_DST_BIT | VK_FORMAT_FEATURE_SAMPLED_IMAGE_FILTER_LINEAR_BIT;
    uint32_t mips = 1;
    if (mipmaps && (fp.optimalTilingFeatures & need) == need) {
        int m = std::max(w, h);
        mips = 1;
        while (m > 1) { m >>= 1; mips++; }
    }

    const VkDeviceSize size = static_cast<VkDeviceSize>(w) * h * 4;
    VkBuffer stage = VK_NULL_HANDLE;
    VkDeviceMemory stageMem = VK_NULL_HANDLE;
    if (!createBuffer(size, VK_BUFFER_USAGE_TRANSFER_SRC_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, stage, stageMem)) return false;
    void* p = nullptr;
    VKOK(vkMapMemory(device_, stageMem, 0, size, 0, &p));
    std::memcpy(p, rgba, static_cast<size_t>(size));
    vkUnmapMemory(device_, stageMem);

    VkImageCreateInfo ii{};
    ii.sType = VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO;
    ii.imageType = VK_IMAGE_TYPE_2D;
    ii.format = fmt;
    ii.extent = {static_cast<uint32_t>(w), static_cast<uint32_t>(h), 1};
    ii.mipLevels = mips;
    ii.arrayLayers = 1;
    ii.samples = VK_SAMPLE_COUNT_1_BIT;
    ii.tiling = VK_IMAGE_TILING_OPTIMAL;
    ii.usage = VK_IMAGE_USAGE_TRANSFER_SRC_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT | VK_IMAGE_USAGE_SAMPLED_BIT;
    ii.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    ii.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    VKOK(vkCreateImage(device_, &ii, nullptr, &out.image));
    VkMemoryRequirements mr;
    vkGetImageMemoryRequirements(device_, out.image, &mr);
    uint32_t mt = findMemType(mr.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    if (mt == 0xFFFFFFFFu) mt = findMemType(mr.memoryTypeBits, 0);
    VkMemoryAllocateInfo mai{};
    mai.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
    mai.allocationSize = mr.size;
    mai.memoryTypeIndex = mt;
    VKOK(vkAllocateMemory(device_, &mai, nullptr, &out.mem));
    VKOK(vkBindImageMemory(device_, out.image, out.mem, 0));

    VkCommandBuffer cb = beginOneShot();
    auto barrier = [&](uint32_t mip, VkImageLayout from, VkImageLayout to, VkAccessFlags srcA, VkAccessFlags dstA,
                       VkPipelineStageFlags srcS, VkPipelineStageFlags dstS) {
        VkImageMemoryBarrier b{};
        b.sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;
        b.oldLayout = from;
        b.newLayout = to;
        b.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
        b.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
        b.image = out.image;
        b.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, mip, 1, 0, 1};
        b.srcAccessMask = srcA;
        b.dstAccessMask = dstA;
        vkCmdPipelineBarrier(cb, srcS, dstS, 0, 0, nullptr, 0, nullptr, 1, &b);
    };

    // todos os níveis: UNDEFINED -> TRANSFER_DST
    for (uint32_t i = 0; i < mips; i++)
        barrier(i, VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 0, VK_ACCESS_TRANSFER_WRITE_BIT,
                VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT);

    VkBufferImageCopy region{};
    region.imageSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1};
    region.imageExtent = {static_cast<uint32_t>(w), static_cast<uint32_t>(h), 1};
    vkCmdCopyBufferToImage(cb, stage, out.image, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &region);

    int mw = w, mh = h;
    for (uint32_t i = 1; i < mips; i++) {
        barrier(i - 1, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
                VK_ACCESS_TRANSFER_WRITE_BIT, VK_ACCESS_TRANSFER_READ_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT);
        VkImageBlit blit{};
        blit.srcSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, i - 1, 0, 1};
        blit.srcOffsets[1] = {mw, mh, 1};
        const int nw = std::max(1, mw / 2), nh = std::max(1, mh / 2);
        blit.dstSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, i, 0, 1};
        blit.dstOffsets[1] = {nw, nh, 1};
        vkCmdBlitImage(cb, out.image, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, out.image, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &blit, VK_FILTER_LINEAR);
        barrier(i - 1, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,
                VK_ACCESS_TRANSFER_READ_BIT, VK_ACCESS_SHADER_READ_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT);
        mw = nw; mh = nh;
    }
    // último nível (ou o único)
    barrier(mips - 1, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,
            VK_ACCESS_TRANSFER_WRITE_BIT, VK_ACCESS_SHADER_READ_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT);
    endOneShot(cb);
    vkDestroyBuffer(device_, stage, nullptr);
    vkFreeMemory(device_, stageMem, nullptr);

    VkImageViewCreateInfo vi{};
    vi.sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO;
    vi.image = out.image;
    vi.viewType = VK_IMAGE_VIEW_TYPE_2D;
    vi.format = fmt;
    vi.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, mips, 0, 1};
    VKOK(vkCreateImageView(device_, &vi, nullptr, &out.view));
    return true;
}

bool VkEngine::createTextures() {
    VkSamplerCreateInfo si{};
    si.sType = VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO;
    si.magFilter = VK_FILTER_LINEAR;
    si.minFilter = VK_FILTER_LINEAR;
    si.mipmapMode = VK_SAMPLER_MIPMAP_MODE_LINEAR;
    si.addressModeU = si.addressModeV = si.addressModeW = VK_SAMPLER_ADDRESS_MODE_REPEAT;
    si.anisotropyEnable = anisotropy_ ? VK_TRUE : VK_FALSE;
    si.maxAnisotropy = anisotropy_ ? maxAniso_ : 1.0f;
    si.minLod = 0.0f;
    si.maxLod = VK_LOD_CLAMP_NONE;
    VKOK(vkCreateSampler(device_, &si, nullptr, &sampler_));

    // ordem = ChunkMat::SAND, GRASS, ROCK, ROCKMOSS, FOREST
    const TexGen::Pixels px[5] = {TexGen::sand(), TexGen::grass(), TexGen::rock(false), TexGen::rock(true), TexGen::forest()};
    for (int i = 0; i < 5; i++) {
        if (!createTexture(px[i].data(), TexGen::S, TexGen::S, tex_[i])) return false;
        VkDescriptorSetAllocateInfo dsa{};
        dsa.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO;
        dsa.descriptorPool = descPool_;
        dsa.descriptorSetCount = 1;
        dsa.pSetLayouts = &matLayout_;
        VKOK(vkAllocateDescriptorSets(device_, &dsa, &matSet_[i]));
        VkDescriptorImageInfo ii{sampler_, tex_[i].view, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL};
        VkWriteDescriptorSet w{};
        w.sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
        w.dstSet = matSet_[i];
        w.dstBinding = 0;
        w.descriptorCount = 1;
        w.descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER;
        w.pImageInfo = &ii;
        vkUpdateDescriptorSets(device_, 1, &w, 0, nullptr);
    }
    return true;
}

// ============================================================================
//  ciclo de vida
// ============================================================================
bool VkEngine::attachWindow(ANativeWindow* window, AAssetManager* assets) {
    assets_ = assets;
    if (!deviceReady_) {
        if (!createInstance()) return false;
        if (!createSurfaceAndDevice(window)) return false;
        if (!createFrameResources()) return false;
        if (!createSwapchain()) return false;          // também cria o render pass
        if (!createPipeline()) return false;
        if (!createTextures()) return false;
        deviceReady_ = true;
        LOGI("Vulkan pronto");
        return true;
    }
    // nova janela (voltou do segundo plano): só surface + swapchain
    VkAndroidSurfaceCreateInfoKHR sci{};
    sci.sType = VK_STRUCTURE_TYPE_ANDROID_SURFACE_CREATE_INFO_KHR;
    sci.window = window;
    VKOK(vkCreateAndroidSurfaceKHR(instance_, &sci, nullptr, &surface_));
    return createSwapchain();
}

void VkEngine::detachWindow() {
    destroySwapchain();
    if (surface_) { vkDestroySurfaceKHR(instance_, surface_, nullptr); surface_ = VK_NULL_HANDLE; }
    extent_ = {0, 0};
}

void VkEngine::shutdown() {
    if (device_) vkDeviceWaitIdle(device_);
    for (auto& kv : chunks_) for (auto& m : kv.second.parts) destroyMesh(m);
    chunks_.clear();
    for (auto& v : retired_) { for (auto& m : v) destroyMesh(m); v.clear(); }
    detachWindow();
    if (device_) {
        for (auto& t : tex_) {
            if (t.view) vkDestroyImageView(device_, t.view, nullptr);
            if (t.image) vkDestroyImage(device_, t.image, nullptr);
            if (t.mem) vkFreeMemory(device_, t.mem, nullptr);
            t = Tex{};
        }
        for (Tex* t : {&waterTex_, &swashTex_, &wetTex_, &noiseTex_, &whiteTex_, &hudTex_}) {
            if (t->view) vkDestroyImageView(device_, t->view, nullptr);
            if (t->image) vkDestroyImage(device_, t->image, nullptr);
            if (t->mem) vkFreeMemory(device_, t->mem, nullptr);
            *t = Tex{};
        }
        for (auto& pg : props_) destroyMesh(pg.mesh);
        destroyDynBuf(boatDyn_);
        destroyDynBuf(playerDyn_);
        destroyDynBuf(hudDyn_);
        destroyMesh(planeMesh_);
        destroyMesh(bandMesh_);
        for (auto& m : foamMesh_) destroyMesh(m);
        if (samplerClamp_) vkDestroySampler(device_, samplerClamp_, nullptr);
        if (sampler_) vkDestroySampler(device_, sampler_, nullptr);
        if (skyPipe_) vkDestroyPipeline(device_, skyPipe_, nullptr);
        if (waterPipe_) vkDestroyPipeline(device_, waterPipe_, nullptr);
        if (shinePipe_) vkDestroyPipeline(device_, shinePipe_, nullptr);
        if (hudPipe_) vkDestroyPipeline(device_, hudPipe_, nullptr);
        if (rockPipe_) vkDestroyPipeline(device_, rockPipe_, nullptr);
        if (decoPipe_) vkDestroyPipeline(device_, decoPipe_, nullptr);
        if (palmPipe_) vkDestroyPipeline(device_, palmPipe_, nullptr);
        if (pipeline_) vkDestroyPipeline(device_, pipeline_, nullptr);
        if (pipeLayout_) vkDestroyPipelineLayout(device_, pipeLayout_, nullptr);
        if (descPool_) vkDestroyDescriptorPool(device_, descPool_, nullptr);
        if (frameLayout_) vkDestroyDescriptorSetLayout(device_, frameLayout_, nullptr);
        if (matLayout_) vkDestroyDescriptorSetLayout(device_, matLayout_, nullptr);
        for (int i = 0; i < MAX_FRAMES; i++) {
            if (uboPtr_[i]) vkUnmapMemory(device_, uboMem_[i]);
            if (ubo_[i]) vkDestroyBuffer(device_, ubo_[i], nullptr);
            if (uboMem_[i]) vkFreeMemory(device_, uboMem_[i], nullptr);
            if (inFlight_[i]) vkDestroyFence(device_, inFlight_[i], nullptr);
            if (imageAvail_[i]) vkDestroySemaphore(device_, imageAvail_[i], nullptr);
        }
        if (cmdPool_) vkDestroyCommandPool(device_, cmdPool_, nullptr);
        if (renderPass_) vkDestroyRenderPass(device_, renderPass_, nullptr);
        vkDestroyDevice(device_, nullptr);
    }
    if (instance_) vkDestroyInstance(instance_, nullptr);
    *this = VkEngine();
}

// ============================================================================
//  mar: texturas, malhas e descritores
// ============================================================================
bool VkEngine::makeTexSet(const Tex& t, VkSampler s, VkDescriptorSet& out) {
    VkDescriptorSetAllocateInfo dsa{};
    dsa.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO;
    dsa.descriptorPool = descPool_;
    dsa.descriptorSetCount = 1;
    dsa.pSetLayouts = &matLayout_;
    VKOK(vkAllocateDescriptorSets(device_, &dsa, &out));
    VkDescriptorImageInfo ii{s, t.view, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL};
    VkWriteDescriptorSet w{};
    w.sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
    w.dstSet = out;
    w.dstBinding = 0;
    w.descriptorCount = 1;
    w.descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER;
    w.pImageInfo = &ii;
    vkUpdateDescriptorSets(device_, 1, &w, 0, nullptr);
    return true;
}

bool VkEngine::uploadMesh(const std::vector<float>& v, GpuMesh& m) {
    if (v.empty()) return true;
    const VkDeviceSize size = v.size() * sizeof(float);
    m.vertexCount = static_cast<uint32_t>(size / kVertexStride);
    if (!createBuffer(size, VK_BUFFER_USAGE_VERTEX_BUFFER_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, m.buf, m.mem)) return false;
    void* p = nullptr;
    VKOK(vkMapMemory(device_, m.mem, 0, size, 0, &p));
    std::memcpy(p, v.data(), static_cast<size_t>(size));
    vkUnmapMemory(device_, m.mem);
    return true;
}

bool VkEngine::uploadWater(const Water& w) {
    if (!deviceReady_ || waterReady_) return false;

    // sampler das ondas na praia: repete em U (dá a volta na ilha), trava em V (sem mipmaps)
    VkSamplerCreateInfo si{};
    si.sType = VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO;
    si.magFilter = VK_FILTER_LINEAR;
    si.minFilter = VK_FILTER_LINEAR;
    si.mipmapMode = VK_SAMPLER_MIPMAP_MODE_NEAREST;
    si.addressModeU = VK_SAMPLER_ADDRESS_MODE_REPEAT;
    si.addressModeV = VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
    si.addressModeW = VK_SAMPLER_ADDRESS_MODE_REPEAT;
    si.maxLod = 0.0f;
    VKOK(vkCreateSampler(device_, &si, nullptr, &samplerClamp_));

    const Image noise = makeNoiseTexture();
    const uint8_t white[4] = {255, 255, 255, 255};
    if (!createTexture(w.waterTex.rgba.data(), w.waterTex.w, w.waterTex.h, waterTex_, true)) return false;
    if (!createTexture(w.swashTex.rgba.data(), w.swashTex.w, w.swashTex.h, swashTex_, false)) return false;
    if (!createTexture(w.wetTex.rgba.data(), w.wetTex.w, w.wetTex.h, wetTex_, false)) return false;
    if (!createTexture(noise.rgba.data(), noise.w, noise.h, noiseTex_, true)) return false;
    if (!createTexture(white, 1, 1, whiteTex_, false)) return false;

    if (!makeTexSet(waterTex_, sampler_, waterSet_)) return false;
    if (!makeTexSet(swashTex_, samplerClamp_, swashSet_)) return false;
    if (!makeTexSet(wetTex_, samplerClamp_, wetSet_)) return false;
    if (!makeTexSet(noiseTex_, sampler_, noiseSet_)) return false;
    if (!makeTexSet(whiteTex_, samplerClamp_, whiteSet_)) return false;

    if (!uploadMesh(w.planeVerts, planeMesh_)) return false;
    if (!uploadMesh(w.bandVerts, bandMesh_)) return false;
    for (int i = 0; i < 3; i++) if (!uploadMesh(w.foamVerts[i], foamMesh_[i])) return false;
    waterReady_ = true;
    LOGI("Mar pronto: plano=%u band=%u vertices", planeMesh_.vertexCount, bandMesh_.vertexCount);
    return true;
}

bool VkEngine::createDynBuf(DynBuf& d, VkDeviceSize bytes) {
    for (int i = 0; i < MAX_FRAMES; i++) {
        if (d.buf[i]) continue;
        if (!createBuffer(bytes, VK_BUFFER_USAGE_VERTEX_BUFFER_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, d.buf[i], d.mem[i])) return false;
        VKOK(vkMapMemory(device_, d.mem[i], 0, bytes, 0, &d.ptr[i]));
    }
    return true;
}

void VkEngine::destroyDynBuf(DynBuf& d) {
    for (int i = 0; i < MAX_FRAMES; i++) {
        if (d.ptr[i]) vkUnmapMemory(device_, d.mem[i]);
        if (d.buf[i]) vkDestroyBuffer(device_, d.buf[i], nullptr);
        if (d.mem[i]) vkFreeMemory(device_, d.mem[i], nullptr);
        d.ptr[i] = nullptr; d.buf[i] = VK_NULL_HANDLE; d.mem[i] = VK_NULL_HANDLE;
    }
}

bool VkEngine::initHud() {
    if (!deviceReady_) return false;
    if (hudReady_) return true;
    // atlas: RGB branco + alfa da fonte (o bloco 4x4 branco serve para formas sólidas)
    std::vector<uint8_t> rgba(static_cast<size_t>(HudFont::W) * HudFont::H * 4);
    for (int i = 0; i < HudFont::W * HudFont::H; i++) {
        rgba[i * 4] = rgba[i * 4 + 1] = rgba[i * 4 + 2] = 255;
        rgba[i * 4 + 3] = HudFont::ATLAS[i];
    }
    if (!createTexture(rgba.data(), HudFont::W, HudFont::H, hudTex_, false)) return false;
    if (!makeTexSet(hudTex_, samplerClamp_, hudSet_)) return false;
    if (!createDynBuf(hudDyn_, static_cast<VkDeviceSize>(kHudMaxVerts) * sizeof(HudVertex))) return false;
    hudReady_ = true;
    return true;
}

bool VkEngine::uploadProps(const std::vector<float>& pier, const std::vector<float>& bridge) {
    if (!deviceReady_) return false;
    if (propsReady_) return true;                       // já subiu (não vaza se o jogo recomeçar)
    const std::vector<float>* src[2] = {&pier, &bridge};
    for (int i = 0; i < 2; i++) {
        const std::vector<float>& v = *src[i];
        if (v.empty()) continue;
        PropGpu& pg = props_[i];
        const VkDeviceSize size = v.size() * sizeof(float);
        pg.mesh.vertexCount = static_cast<uint32_t>(v.size() / 7);
        if (!createBuffer(size, VK_BUFFER_USAGE_VERTEX_BUFFER_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, pg.mesh.buf, pg.mesh.mem)) return false;
        void* p = nullptr;
        VKOK(vkMapMemory(device_, pg.mesh.mem, 0, size, 0, &p));
        std::memcpy(p, v.data(), static_cast<size_t>(size));
        vkUnmapMemory(device_, pg.mesh.mem);
        // centro e raio (no chão) para o corte por distância
        float mnx = 1e9f, mxx = -1e9f, mnz = 1e9f, mxz = -1e9f;
        for (size_t k = 0; k + 6 < v.size(); k += 7) { mnx = std::min(mnx, v[k]); mxx = std::max(mxx, v[k]); mnz = std::min(mnz, v[k + 2]); mxz = std::max(mxz, v[k + 2]); }
        pg.cx = (mnx + mxx) * 0.5f; pg.cz = (mnz + mxz) * 0.5f;
        pg.r = std::sqrt((mxx - mnx) * (mxx - mnx) + (mxz - mnz) * (mxz - mnz)) * 0.5f;
    }
    const VkDeviceSize dynBytes = static_cast<VkDeviceSize>(kDynMaxVerts) * 7 * sizeof(float);
    if (!createDynBuf(boatDyn_, dynBytes) || !createDynBuf(playerDyn_, dynBytes)) return false;
    propsReady_ = true;
    return true;
}

// ============================================================================
//  chunks na GPU
// ============================================================================
void VkEngine::uploadChunk(const Built& b) {
    if (!deviceReady_) return;                     // layer 0 = terreno, layer 1 = vegetação (etapa 3B)
    const int id = b.layer * 100000 + b.key;
    if (chunks_.count(id)) return;
    ChunkGpu cg;
    cg.x0 = static_cast<float>(b.key % Cfg::CHUNKS) * Cfg::CHUNK - Cfg::HALF;
    cg.z0 = static_cast<float>(b.key / Cfg::CHUNKS) * Cfg::CHUNK - Cfg::HALF;
    cg.minY = b.minY;
    cg.maxY = b.maxY;
    for (size_t i = 0; i < b.parts.size(); i++) {
        const std::vector<float>& v = b.parts[i];
        if (v.empty() || b.mats[i] < 0 || b.mats[i] >= ChunkMat::COUNT) continue;
        GpuMesh m;
        m.mat = b.mats[i];
        m.vertexCount = static_cast<uint32_t>(v.size() * sizeof(float) / strideBytes(m.mat));   // 7, 9 ou 10 floats por vértice
        const VkDeviceSize size = v.size() * sizeof(float);
        if (!createBuffer(size, VK_BUFFER_USAGE_VERTEX_BUFFER_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, m.buf, m.mem)) {
            destroyMesh(m);
            continue;
        }
        void* p = nullptr;
        if (vkMapMemory(device_, m.mem, 0, size, 0, &p) == VK_SUCCESS) {
            std::memcpy(p, v.data(), static_cast<size_t>(size));
            vkUnmapMemory(device_, m.mem);
            cg.parts.push_back(m);
        } else {
            destroyMesh(m);
        }
    }
    chunks_[id] = std::move(cg);
}

void VkEngine::unloadChunk(int layer, int key) {
    auto it = chunks_.find(layer * 100000 + key);
    if (it == chunks_.end()) return;
    // ainda pode estar em uso por um quadro em voo: destrói só quando o quadro atual terminar
    for (auto& m : it->second.parts) retired_[cur_].push_back(m);
    chunks_.erase(it);
}

// ============================================================================
//  um quadro
// ============================================================================
bool VkEngine::drawFrame(const FrameParams& fp) {
    if (!deviceReady_ || !swapchain_) return false;

    vkWaitForFences(device_, 1, &inFlight_[cur_], VK_TRUE, UINT64_MAX);
    for (auto& m : retired_[cur_]) destroyMesh(m);
    retired_[cur_].clear();

    uint32_t img = 0;
    VkResult r = vkAcquireNextImageKHR(device_, swapchain_, UINT64_MAX, imageAvail_[cur_], VK_NULL_HANDLE, &img);
    if (r == VK_ERROR_OUT_OF_DATE_KHR) { recreateSwapchain(); return true; }
    if (r != VK_SUCCESS && r != VK_SUBOPTIMAL_KHR) { LOGE("vkAcquireNextImageKHR: %d", (int)r); return false; }
    vkResetFences(device_, 1, &inFlight_[cur_]);

    // bloco de dados do quadro
    const Mat4 vp = fp.proj * fp.view;
    FrameUBO u{};
    std::memcpy(u.viewProj, vp.m, sizeof(u.viewProj));
    for (int i = 0; i < 3; i++) {
        u.camPos[i] = fp.camPos[i];
        u.toLight[i] = fp.toLight[i];
        u.lightColor[i] = fp.lightColor[i];
        u.ambient[i] = fp.ambient[i];
        u.fogColor[i] = fp.fogColor[i];
    }
    u.params[0] = 1.0f / (fp.farPlane * fp.farPlane);
    u.camPos[3] = fp.time;
    const Mat4 ipv = vp.inverse();
    std::memcpy(u.invPV, ipv.m, sizeof(u.invPV));
    auto put3 = [](float* o, const float* s, float w) { o[0] = s[0]; o[1] = s[1]; o[2] = s[2]; o[3] = w; };
    const SkyFrame& sk = fp.sky;
    put3(u.top, sk.top, sk.tw); put3(u.hor, sk.hor, 0.0f); put3(u.sun, sk.sun, 0.0f);
    u.sunH[0] = sk.sunH[0]; u.sunH[1] = sk.sunH[1];
    put3(u.warm1, sk.warm1, 0.0f); put3(u.warm2, sk.warm2, 0.0f); put3(u.warm3, sk.warm3, 0.0f); put3(u.halo, sk.halo, 0.0f);
    put3(u.sunE, sk.sunE, 0.0f); put3(u.sunN, sk.sunN, 0.0f);
    u.sunP[0] = sk.sunR; u.sunP[1] = sk.squash;
    put3(u.sunCol, sk.sunCol, 0.0f); put3(u.moon, sk.moon, 0.0f); put3(u.sunGlit, sk.sunGlit, 0.0f); put3(u.moonGlit, sk.moonGlit, 0.0f);
    u.shine[0] = sk.refl;
    u.wind[0] = fp.windTime; u.wind[1] = fp.windGust; u.wind[2] = fp.windDirX; u.wind[3] = fp.windDirZ;
    std::memcpy(uboPtr_[cur_], &u, sizeof(u));

    VkCommandBuffer cb = cmd_[cur_];
    vkResetCommandBuffer(cb, 0);
    VkCommandBufferBeginInfo bi{};
    bi.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;
    vkBeginCommandBuffer(cb, &bi);

    VkClearValue clears[2]{};
    clears[0].color = {{fp.fogColor[0], fp.fogColor[1], fp.fogColor[2], 1.0f}};
    clears[1].depthStencil = {1.0f, 0};
    VkRenderPassBeginInfo rp{};
    rp.sType = VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO;
    rp.renderPass = renderPass_;
    rp.framebuffer = framebuffers_[img];
    rp.renderArea = {{0, 0}, extent_};
    rp.clearValueCount = 2;
    rp.pClearValues = clears;
    vkCmdBeginRenderPass(cb, &rp, VK_SUBPASS_CONTENTS_INLINE);
    VkViewport vpt{0.0f, 0.0f, static_cast<float>(extent_.width), static_cast<float>(extent_.height), 0.0f, 1.0f};
    VkRect2D sc{{0, 0}, extent_};
    vkCmdSetViewport(cb, 0, 1, &vpt);
    vkCmdSetScissor(cb, 0, 1, &sc);
    vkCmdBindDescriptorSets(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, pipeLayout_, 0, 1, &frameSet_[cur_], 0, nullptr);

    // 1) céu (tela cheia, sem profundidade): o terreno e o mar cobrem por cima
    vkCmdBindPipeline(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, skyPipe_);
    vkCmdDraw(cb, 3, 1, 0, 0);

    // 2) terreno
    vkCmdBindPipeline(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, pipeline_);
    Frustum fr;
    fr.set(vp);
    std::vector<const ChunkGpu*> visible;
    for (const auto& kv : chunks_) {
        const ChunkGpu& c = kv.second;
        // corte por distância (como os jogos de celular): o que está além do raio nem é enviado para a GPU
        const float cx = c.x0 + Cfg::CHUNK * 0.5f - fp.camPos[0];
        const float cz = c.z0 + Cfg::CHUNK * 0.5f - fp.camPos[2];
        const float lim = fp.drawRadius + Cfg::CHUNK * 0.75f;
        if (cx * cx + cz * cz > lim * lim) continue;
        if (fr.intersectsBox(c.x0, c.minY, c.z0, c.x0 + Cfg::CHUNK, c.maxY, c.z0 + Cfg::CHUNK)) visible.push_back(&c);
    }
    for (int mat = 0; mat < 5; mat++) {
        bool bound = false;
        for (const ChunkGpu* c : visible) for (const GpuMesh& m : c->parts) {
            if (m.mat != mat) continue;
            if (!bound) {
                vkCmdBindDescriptorSets(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, pipeLayout_, 1, 1, &matSet_[mat], 0, nullptr);
                bound = true;
            }
            VkDeviceSize off = 0;
            vkCmdBindVertexBuffers(cb, 0, 1, &m.buf, &off);
            vkCmdDraw(cb, m.vertexCount, 1, 0, 0);
        }
    }

    // 2b) vegetação (etapa 3B): opaca, sem culling. Ordem: cor de vértice -> pedras -> árvores com vento.
    {
        const float lim = fp.decoRadius + Cfg::CHUNK * 0.75f;
        // distância (no chão) da câmera até o chunk inteiro: usada no raio de detalhe (flores, cogumelos, pedrinhas)
        auto boxDist2 = [&](const ChunkGpu& c) {
            const float dx = std::max(std::max(c.x0 - fp.camPos[0], 0.0f), fp.camPos[0] - (c.x0 + Cfg::CHUNK));
            const float dz = std::max(std::max(c.z0 - fp.camPos[2], 0.0f), fp.camPos[2] - (c.z0 + Cfg::CHUNK));
            return dx * dx + dz * dz;
        };
        std::vector<const ChunkGpu*> deco, detail;
        for (const auto& kv : chunks_) {
            const ChunkGpu& c = kv.second;
            if (c.parts.empty() || c.parts[0].mat < ChunkMat::DECO) continue;       // só chunks de vegetação
            const float cx = c.x0 + Cfg::CHUNK * 0.5f - fp.camPos[0];
            const float cz = c.z0 + Cfg::CHUNK * 0.5f - fp.camPos[2];
            if (cx * cx + cz * cz > lim * lim) continue;
            if (!fr.intersectsBox(c.x0, c.minY, c.z0, c.x0 + Cfg::CHUNK, c.maxY, c.z0 + Cfg::CHUNK)) continue;
            deco.push_back(&c);
            if (boxDist2(c) < fp.detailRadius * fp.detailRadius) detail.push_back(&c);
        }
        auto drawMat = [&](const std::vector<const ChunkGpu*>& list, int mat) {
            for (const ChunkGpu* c : list) for (const GpuMesh& m : c->parts) {
                if (m.mat != mat || m.vertexCount == 0) continue;
                VkDeviceSize off = 0;
                vkCmdBindVertexBuffers(cb, 0, 1, &m.buf, &off);
                vkCmdDraw(cb, m.vertexCount, 1, 0, 0);
            }
        };
        vkCmdBindPipeline(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, decoPipe_);
        drawMat(deco, ChunkMat::DECO);
        drawMat(detail, ChunkMat::DECO_DETAIL);
        vkCmdBindPipeline(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, rockPipe_);
        vkCmdBindDescriptorSets(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, pipeLayout_, 1, 1, &matSet_[ChunkMat::ROCK], 0, nullptr);
        drawMat(deco, ChunkMat::DECOROCK);
        drawMat(detail, ChunkMat::DECOROCK_DETAIL);
        vkCmdBindPipeline(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, palmPipe_);
        drawMat(deco, ChunkMat::PALM);

        // píer, ponte e barco (cor de vértice, sem culling): só se estiverem perto
        if (propsReady_) {
            vkCmdBindPipeline(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, decoPipe_);
            auto closeEnough = [&](float cx, float cz, float r) {
                const float dx = cx - fp.camPos[0], dz = cz - fp.camPos[2];
                const float l = fp.decoRadius + r + 20.0f;
                return dx * dx + dz * dz < l * l;
            };
            for (const PropGpu& pg : props_) {
                if (pg.mesh.vertexCount == 0 || !closeEnough(pg.cx, pg.cz, pg.r)) continue;
                VkDeviceSize off = 0;
                vkCmdBindVertexBuffers(cb, 0, 1, &pg.mesh.buf, &off);
                vkCmdDraw(cb, pg.mesh.vertexCount, 1, 0, 0);
            }
            auto drawDyn = [&](const std::vector<float>* v, DynBuf& d, bool useDist) {
                if (!v || v->empty()) return;
                uint32_t n = std::min(static_cast<uint32_t>(v->size() / 7), kDynMaxVerts);
                std::memcpy(d.ptr[cur_], v->data(), static_cast<size_t>(n) * 7 * sizeof(float));
                if (useDist && !closeEnough((*v)[0], (*v)[2], 4.0f)) return;
                VkDeviceSize off = 0;
                vkCmdBindVertexBuffers(cb, 0, 1, &d.buf[cur_], &off);
                vkCmdDraw(cb, n, 1, 0, 0);
            };
            drawDyn(fp.boatVerts, boatDyn_, true);       // barco: só se estiver perto
            drawDyn(fp.playerVerts, playerDyn_, false);  // boneco: sempre perto (a câmera segue ele)
        }
    }

    if (waterReady_) {
        const VkShaderStageFlags pcStages = VK_SHADER_STAGE_VERTEX_BIT | VK_SHADER_STAGE_FRAGMENT_BIT;
        auto push = [&](float x, float y, float z, float alpha, const float uv[4]) {
            WaterPC pc{};
            pc.trans[0] = x; pc.trans[1] = y; pc.trans[2] = z; pc.trans[3] = alpha;
            for (int i = 0; i < 4; i++) pc.uvx[i] = uv[i];
            vkCmdPushConstants(cb, pipeLayout_, pcStages, 0, sizeof(pc), &pc);
        };
        auto drawMesh = [&](const GpuMesh& m) {
            if (m.vertexCount == 0) return;
            VkDeviceSize off = 0;
            vkCmdBindVertexBuffers(cb, 0, 1, &m.buf, &off);
            vkCmdDraw(cb, m.vertexCount, 1, 0, 0);
        };
        auto bindTex = [&](VkDescriptorSet s) {
            vkCmdBindDescriptorSets(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, pipeLayout_, 1, 1, &s, 0, nullptr);
        };
        const WaterFrame& wf = fp.water;
        static const float kIdentUV[4] = {0.0f, 0.0f, 1.0f, 1.0f};

        // 3) mar: duas camadas de ondas que andam para lados opostos
        vkCmdBindPipeline(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, waterPipe_);
        bindTex(waterSet_);
        push(wf.planeX, 0.0f, wf.planeZ, 0.78f, wf.uv1);
        drawMesh(planeMesh_);
        push(wf.planeX, 0.03f, wf.planeZ, 0.35f, wf.uv2);
        drawMesh(planeMesh_);

        // 4) reflexo do céu e trilha do sol/lua (some se a câmera estiver dentro d'água)
        if (fp.camPos[1] >= 0.6f) {
            vkCmdBindPipeline(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, shinePipe_);
            bindTex(noiseSet_);
            vkCmdDraw(cb, 6, 1, 0, 0);
            vkCmdBindPipeline(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, waterPipe_);
        }

        // 5) areia molhada, onda subindo a praia e espuma
        const float wetUV[4] = {wf.swashOffU, wf.wetOffV, 1.0f, 1.0f};
        const float swashUV[4] = {wf.swashOffU, wf.swashOffV, 1.0f, 1.0f};
        bindTex(wetSet_);
        push(0.0f, 0.0f, 0.0f, 1.0f, wetUV);
        drawMesh(bandMesh_);
        bindTex(swashSet_);
        push(0.0f, 0.0f, 0.0f, 1.0f, swashUV);
        drawMesh(bandMesh_);
        bindTex(whiteSet_);
        for (int i = 0; i < 3; i++) {
            push(0.0f, 0.0f, 0.0f, wf.foamAlpha[i], kIdentUV);
            drawMesh(foamMesh_[i]);
        }
    }

    // 6) HUD (camada 2D): por cima de tudo, alfa, sem profundidade
    if (hudReady_ && fp.hud && !fp.hud->empty()) {
        const uint32_t n = std::min(static_cast<uint32_t>(fp.hud->size()), kHudMaxVerts);
        std::memcpy(hudDyn_.ptr[cur_], fp.hud->data(), static_cast<size_t>(n) * sizeof(HudVertex));
        WaterPC pc{};
        pc.trans[0] = static_cast<float>(extent_.width);
        pc.trans[1] = static_cast<float>(extent_.height);
        vkCmdBindPipeline(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, hudPipe_);
        vkCmdBindDescriptorSets(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, pipeLayout_, 1, 1, &hudSet_, 0, nullptr);
        vkCmdPushConstants(cb, pipeLayout_, VK_SHADER_STAGE_VERTEX_BIT | VK_SHADER_STAGE_FRAGMENT_BIT, 0, sizeof(pc), &pc);
        VkDeviceSize off = 0;
        vkCmdBindVertexBuffers(cb, 0, 1, &hudDyn_.buf[cur_], &off);
        vkCmdDraw(cb, n, 1, 0, 0);
    }

    vkCmdEndRenderPass(cb);
    vkEndCommandBuffer(cb);

    const VkPipelineStageFlags waitStage = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
    VkSubmitInfo si{};
    si.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;
    si.waitSemaphoreCount = 1;
    si.pWaitSemaphores = &imageAvail_[cur_];
    si.pWaitDstStageMask = &waitStage;
    si.commandBufferCount = 1;
    si.pCommandBuffers = &cb;
    si.signalSemaphoreCount = 1;
    si.pSignalSemaphores = &renderDone_[img];
    if (vkQueueSubmit(queue_, 1, &si, inFlight_[cur_]) != VK_SUCCESS) { LOGE("vkQueueSubmit falhou"); return false; }

    VkPresentInfoKHR pi{};
    pi.sType = VK_STRUCTURE_TYPE_PRESENT_INFO_KHR;
    pi.waitSemaphoreCount = 1;
    pi.pWaitSemaphores = &renderDone_[img];
    pi.swapchainCount = 1;
    pi.pSwapchains = &swapchain_;
    pi.pImageIndices = &img;
    r = vkQueuePresentKHR(queue_, &pi);
    if (r == VK_ERROR_OUT_OF_DATE_KHR || r == VK_SUBOPTIMAL_KHR) recreateSwapchain();
    else if (r != VK_SUCCESS) LOGE("vkQueuePresentKHR: %d", (int)r);

    cur_ = (cur_ + 1) % MAX_FRAMES;
    return true;
}
