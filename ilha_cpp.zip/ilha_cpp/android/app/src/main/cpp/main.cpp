// Ponto de entrada Android (NativeActivity + android_native_app_glue). 100% C++.
#include <android/input.h>
#include <android/log.h>
#include <android_native_app_glue.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <memory>
#include "Camera.h"
#include "ChunkManager.h"
#include "Controls.h"
#include "Hud.h"
#include "Player.h"
#include "Sky.h"
#include "Streaming.h"
#include "Water.h"
#include "VkEngine.h"
#include "Wind.h"
#include "Props.h"
#include "World.h"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "Ilha", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "Ilha", __VA_ARGS__)

namespace {
constexpr float kFovDeg = 67.0f;     // = PerspectiveCamera(67f) do original
constexpr float kNear = 0.4f;
constexpr float kFar = 1000.0f;
struct Game {
    VkEngine eng;
    std::unique_ptr<ChunkManager> cm;
    std::unique_ptr<Sky> sky;
    std::unique_ptr<Water> water;
    float t = 0;                         // tempo de jogo (s)
    double coconutDays = 0;              // dia do jogo no HUD (Coconuts.days): avança 1 por Cfg::COCO_DIA_SEGUNDOS
    QualityController quality{Streaming::DEFAULT_LEVEL};   // sobe/desce a distância de carregamento pelo FPS
    Controls ctl;
    Player player;
    CameraRig cam;                       // câmera em 3ª pessoa
    bool active = false;
    bool started = false;
    std::chrono::steady_clock::time_point last;
    float fpsTimer = 0;
    int fpsFrames = 0;
    int fpsShown = 0;                    // FPS do último segundo (o HUD mostra, como o framesPerSecond do libGDX)
    float logTimer = 0;
    BoatModel::Pose boatPose = BoatModel::mooredPose();   // barco amarrado no píer (remar/amarrar: próxima etapa)
    std::vector<float> boatVerts, playerVerts;
    std::vector<HudVertex> hudVerts;
};

void startGame(Game& g) {
    g.player.place(RoadNet::startX(), RoadNet::startZ(), Player::headingFromDir(0.8f, -0.6f));   // de frente para a ilha

    g.cm = std::make_unique<ChunkManager>();
    g.cm->setProfile(Streaming::profile(g.quality.level()));
    g.cm->onUpload = [&g](const Built& b) { g.eng.uploadChunk(b); };
    g.cm->onUnload = [&g](int layer, int key) { g.eng.unloadChunk(layer, key); };
    g.cm->warmup(g.player.pos.x, g.player.pos.z, std::min(120.0f, g.cm->profile().terrainR));   // mundo já aparece ao abrir
    g.sky = std::make_unique<Sky>();                     // começa 6h12: amanhecer rosa (Cfg::START_HOUR)
    g.water = std::make_unique<Water>();
    if (!g.eng.uploadWater(*g.water)) LOGE("Falha ao criar o mar na GPU");
    if (!g.eng.uploadProps(Props::pier(), Props::bridge())) LOGE("Falha ao criar o píer e a ponte na GPU");
    if (!g.eng.initHud()) LOGE("Falha ao criar o HUD na GPU");
    g.last = std::chrono::steady_clock::now();
    g.started = true;
    LOGI("Jogo iniciado: terreno=%d chunks", g.cm->terrainChunks());
}

void frame(Game& g) {
    auto now = std::chrono::steady_clock::now();
    float dt = std::chrono::duration<float>(now - g.last).count();
    g.last = now;
    const float rawDt = dt;
    dt = std::min(std::max(dt, 0.0f), 0.05f);            // update(min(deltaTime, 0.05f)) do original

    // qualidade automática: encolhe/aumenta os raios de carregamento conforme o FPS
    if (g.quality.frame(rawDt)) {
        const StreamProfile& pr = Streaming::profile(g.quality.level());
        g.cm->setProfile(pr);
        LOGI("Qualidade -> %s (%.0f fps): terreno %.0f m, vegetacao %.0f m", pr.name, g.quality.lastFps(), pr.terrainR, pr.decoR);
    }

    // ---- update (IlhaGame.update) ----
    g.t += dt;
    g.ctl.setScreen(g.eng.width(), g.eng.height());
    g.ctl.poll();
    g.cam.look(g.ctl.lookX, g.ctl.lookY);
    g.ctl.consumeLook();
    g.player.drive(g.cam.yaw, g.ctl.moveX, g.ctl.moveY, g.ctl.run, g.ctl.jump, dt, *g.cm);   // andar/correr/pular/nadar com colisão
    g.cam.update(g.player.pos, *g.cm);                                                         // câmera em terceira pessoa

    g.cm->update(g.player.pos.x, g.player.pos.z, g.cam.dir[0], g.cam.dir[2]);   // o que está na frente carrega primeiro
    g.water->update(dt, g.t);
    g.water->follow(g.player.pos.x, g.player.pos.z);
    Wind::time += dt;
    Wind::update(dt);
    g.coconutDays += dt / Cfg::COCO_DIA_SEGUNDOS;
    g.sky->update(dt, g.cam.pos[0], g.cam.pos[2], g.cam.dir[0], g.cam.dir[2]);
    g.sky->noteCamera(g.cam.dir[0], g.cam.dir[2]);

    // ---- render ----
    FrameParams fp;
    fp.view = Mat4::lookAt(g.cam.pos[0], g.cam.pos[1], g.cam.pos[2], g.cam.pos[0] + g.cam.dir[0], g.cam.pos[1] + g.cam.dir[1], g.cam.pos[2] + g.cam.dir[2]);
    fp.proj = Mat4::perspective(kFovDeg, static_cast<float>(g.eng.width()) / static_cast<float>(g.eng.height()), kNear, kFar);
    fp.camPos[0] = g.cam.pos[0]; fp.camPos[1] = g.cam.pos[1]; fp.camPos[2] = g.cam.pos[2];
    // luz, ambiente e névoa vêm do céu (applyLighting do original)
    const Sky& sk = *g.sky;
    fp.toLight[0] = sk.toLight.x; fp.toLight[1] = sk.toLight.y; fp.toLight[2] = sk.toLight.z;
    fp.lightColor[0] = sk.lightC.r; fp.lightColor[1] = sk.lightC.g; fp.lightColor[2] = sk.lightC.b;
    fp.ambient[0] = sk.ambient.r; fp.ambient[1] = sk.ambient.g; fp.ambient[2] = sk.ambient.b;
    fp.fogColor[0] = sk.fog.r; fp.fogColor[1] = sk.fog.g; fp.fogColor[2] = sk.fog.b;
    const StreamProfile& prof = g.cm->profile();
    fp.farPlane = prof.fogFar;                          // névoa mais curta nos níveis baixos: esconde o corte do terreno
    fp.drawRadius = prof.terrainR;
    fp.decoRadius = prof.decoR;
    fp.detailRadius = prof.detailR;                     // flores, cogumelos e pedrinhas só dentro deste raio
    BoatModel::build(g.boatPose, g.t, g.boatVerts);     // casco e remos balançando nas ondas
    fp.boatVerts = &g.boatVerts;
    if (g.player.visible()) {                           // cabeça abaixo da água = boneco some
        g.player.buildModel(g.playerVerts);
        fp.playerVerts = &g.playerVerts;
    }
    fp.windTime = Wind::time; fp.windGust = Wind::gust; fp.windDirX = Wind::dirX; fp.windDirZ = Wind::dirZ;
    fp.time = g.t;
    sk.fillFrame(fp.sky);
    g.water->fillFrame(fp.water);

    // FPS do último segundo (o HUD mostra)
    g.fpsTimer += rawDt;
    g.fpsFrames++;
    if (g.fpsTimer >= 1.0f) { g.fpsShown = static_cast<int>(g.fpsFrames / g.fpsTimer + 0.5f); g.fpsTimer = 0; g.fpsFrames = 0; }

    Hud::Info hi;
    hi.altitude = static_cast<int>(g.player.pos.y);     // Float.toInt() trunca para zero
    hi.fps = g.fpsShown;
    hi.terrainChunks = g.cm->terrainChunks();
    hi.decoChunks = g.cm->decoChunks();
    hi.tod = sk.tod;
    hi.day = static_cast<int>(std::floor(g.coconutDays)) + 1;
    hi.quality = prof.name;                             // o que a qualidade automática por FPS decidiu
    hi.terrainR = prof.terrainR;
    hi.decoR = prof.decoR;
    Hud::build(g.ctl, hi, g.hudVerts);
    fp.hud = &g.hudVerts;

    g.eng.drawFrame(fp);

    g.logTimer += rawDt;
    if (g.logTimer >= 2.0f) {
        LOGI("%d fps | %s | terreno=%d veg=%d | pos=(%.0f, %.1f, %.0f) | hora do jogo=%.1f", g.fpsShown, prof.name, g.cm->terrainChunks(), g.cm->decoChunks(), g.player.pos.x, g.player.pos.y, g.player.pos.z, g.sky->tod);
        g.logTimer = 0;
    }
}

void onCmd(android_app* app, int32_t cmd) {
    Game* g = static_cast<Game*>(app->userData);
    switch (cmd) {
        case APP_CMD_INIT_WINDOW:
            if (app->window) {
                if (g->eng.attachWindow(app->window, app->activity->assetManager)) {
                    if (!g->started) startGame(*g);
                    g->last = std::chrono::steady_clock::now();
                    g->active = true;
                } else {
                    LOGE("Falha ao iniciar o Vulkan (veja as linhas acima no logcat)");
                }
            }
            break;
        case APP_CMD_TERM_WINDOW:
            g->active = false;
            g->eng.detachWindow();
            break;
        case APP_CMD_LOST_FOCUS:
            g->ctl.cancelAll();
            break;
        default:
            break;
    }
}

int32_t onInput(android_app* app, AInputEvent* ev) {
    Game* g = static_cast<Game*>(app->userData);
    if (AInputEvent_getType(ev) != AINPUT_EVENT_TYPE_MOTION) return 0;
    const int32_t action = AMotionEvent_getAction(ev);
    const int32_t masked = action & AMOTION_EVENT_ACTION_MASK;
    const size_t idx = static_cast<size_t>((action & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK) >> AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT);
    switch (masked) {
        case AMOTION_EVENT_ACTION_DOWN:
        case AMOTION_EVENT_ACTION_POINTER_DOWN:
            g->ctl.touchDown(AMotionEvent_getPointerId(ev, idx), AMotionEvent_getX(ev, idx), AMotionEvent_getY(ev, idx));
            break;
        case AMOTION_EVENT_ACTION_MOVE: {
            const size_t n = AMotionEvent_getPointerCount(ev);
            for (size_t i = 0; i < n; i++) g->ctl.touchMove(AMotionEvent_getPointerId(ev, i), AMotionEvent_getX(ev, i), AMotionEvent_getY(ev, i));
            break;
        }
        case AMOTION_EVENT_ACTION_UP:
        case AMOTION_EVENT_ACTION_POINTER_UP:
            g->ctl.touchUp(AMotionEvent_getPointerId(ev, idx));
            break;
        case AMOTION_EVENT_ACTION_CANCEL:
            g->ctl.cancelAll();
            break;
        default:
            break;
    }
    return 1;
}
}  // namespace

void android_main(android_app* app) {
    Game game;
    app->userData = &game;
    app->onAppCmd = onCmd;
    app->onInputEvent = onInput;

    for (;;) {
        int events = 0;
        android_poll_source* source = nullptr;
        // parado em segundo plano: espera eventos (sem gastar bateria); ativo: não espera
        while (ALooper_pollAll(game.active ? 0 : -1, nullptr, &events, reinterpret_cast<void**>(&source)) >= 0) {
            if (source) source->process(app, source);
            if (app->destroyRequested) {
                game.cm.reset();          // para as threads antes de destruir a GPU
                game.sky.reset();
                game.water.reset();
                game.eng.shutdown();
                return;
            }
        }
        if (game.active) frame(game);
    }
}
