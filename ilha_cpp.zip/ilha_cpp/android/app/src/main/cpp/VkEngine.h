#pragma once
// Motor Vulkan (etapa 4): instância, dispositivo, swapchain, texturas procedurais, pipeline do terreno e desenho dos chunks.
// Usa só Vulkan 1.0 + VK_KHR_swapchain/android_surface. Sem bibliotecas externas.
#define VK_USE_PLATFORM_ANDROID_KHR
#include <vulkan/vulkan.h>
#include <android/asset_manager.h>
#include <android/native_window.h>
#include <unordered_map>
#include <vector>
#include "HudVertex.h"
#include "ChunkBuilder.h"
#include "Math3D.h"
#include "Sky.h"
#include "Water.h"

struct FrameParams {
    Mat4 view, proj;
    float camPos[3];
    float toLight[3];      // direção PARA o sol (unitária)
    float lightColor[3];
    float ambient[3];
    float fogColor[3];     // também é a cor de fundo (céu no horizonte)
    float farPlane;
    float time = 0.0f;       // tempo de jogo em segundos (ondas do reflexo)
    float drawRadius = 1000.0f;   // chunks de terreno além disto (centro) nem são desenhados
    float decoRadius = 250.0f;    // árvores, arbustos e pedras: chunks além disto nem são desenhados
    float detailRadius = 90.0f;   // flores, cogumelos e pedrinhas: só dentro deste raio (StreamProfile::detailR)
    float windTime = 0.0f;        // vento (Wind::time, gust, dirX, dirZ): balanço das árvores no shader
    float windGust = 0.0f;
    float windDirX = 0.82f, windDirZ = 0.57f;
    const std::vector<float>* boatVerts = nullptr;   // casco + remos já no mundo (7 floats por vértice), refeito todo quadro
    const std::vector<float>* playerVerts = nullptr; // boneco já no mundo (7 floats por vértice); nullptr = não desenha
    const std::vector<HudVertex>* hud = nullptr;     // camada 2D (HUD), desenhada por último
    SkyFrame sky{};
    WaterFrame water{};
};

class VkEngine {
public:
    static constexpr int MAX_FRAMES = 2;

    // Primeira chamada: cria tudo (instância, dispositivo, texturas, pipeline). Chamadas seguintes (nova janela): só refaz a swapchain.
    bool attachWindow(ANativeWindow* window, AAssetManager* assets);
    // A janela foi destruída (app em segundo plano): libera a swapchain e a surface, mantém o resto.
    void detachWindow();
    void shutdown();

    bool hasWindow() const { return swapchain_ != VK_NULL_HANDLE; }
    int width() const { return static_cast<int>(extent_.width); }
    int height() const { return static_cast<int>(extent_.height); }

    // Chamados na thread principal (callbacks do ChunkManager)
    void uploadChunk(const Built& b);
    void unloadChunk(int layer, int key);

    // Cria as texturas e malhas do mar (chamar uma vez, depois do attachWindow).
    bool uploadWater(const Water& w);

    // Píer e ponte (estáticos, já em coordenadas do mundo, 7 floats por vértice) e o buffer por quadro do barco.
    bool uploadProps(const std::vector<float>& pier, const std::vector<float>& bridge);
    // Atlas de fonte e buffer da camada 2D (HUD).
    bool initHud();

    bool drawFrame(const FrameParams& fp);

private:
    struct GpuMesh { VkBuffer buf = VK_NULL_HANDLE; VkDeviceMemory mem = VK_NULL_HANDLE; uint32_t vertexCount = 0; int mat = 0; };
    struct ChunkGpu { std::vector<GpuMesh> parts; float x0 = 0, z0 = 0, minY = 0, maxY = 0; };
    struct Tex { VkImage image = VK_NULL_HANDLE; VkDeviceMemory mem = VK_NULL_HANDLE; VkImageView view = VK_NULL_HANDLE; };

    bool createInstance();
    bool createSurfaceAndDevice(ANativeWindow* window);
    bool createDevice();
    bool createSwapchain();
    void destroySwapchain();
    bool createRenderPass();
    bool createPipeline();
    bool createFrameResources();
    bool createTextures();
    bool createTexture(const uint8_t* rgba, int w, int h, Tex& out, bool mipmaps = true);
    // vertexInput: 0 = sem vértices (tela cheia), 1 = terreno/pedras (9 floats), 2 = vegetação de cor de vértice (7 floats),
    //              3 = vegetação com vento (10 floats), 4 = HUD 2D (HudVertex, 20 bytes). noCull: sem culling (vegetação e pedras do original são GL_NONE).
    VkPipeline buildPipeline(const char* shaderName, int vertexInput, int blendMode, int depthMode, bool depthBias, bool noCull = false);
    bool makeTexSet(const Tex& t, VkSampler s, VkDescriptorSet& out);
    bool uploadMesh(const std::vector<float>& v, GpuMesh& m);
    bool recreateSwapchain();

    std::vector<uint8_t> loadAsset(const char* name) const;
    VkShaderModule loadShader(const char* name) const;
    uint32_t findMemType(uint32_t typeBits, VkMemoryPropertyFlags props) const;
    bool createBuffer(VkDeviceSize size, VkBufferUsageFlags usage, VkMemoryPropertyFlags props, VkBuffer& buf, VkDeviceMemory& mem) const;
    VkCommandBuffer beginOneShot() const;
    void endOneShot(VkCommandBuffer cb) const;
    void destroyMesh(GpuMesh& m) const;

    AAssetManager* assets_ = nullptr;
    VkInstance instance_ = VK_NULL_HANDLE;
    VkSurfaceKHR surface_ = VK_NULL_HANDLE;
    VkPhysicalDevice phys_ = VK_NULL_HANDLE;
    VkPhysicalDeviceMemoryProperties memProps_{};
    VkDevice device_ = VK_NULL_HANDLE;
    VkQueue queue_ = VK_NULL_HANDLE;
    uint32_t queueFamily_ = 0;
    bool anisotropy_ = false;
    float maxAniso_ = 1.0f;

    VkSwapchainKHR swapchain_ = VK_NULL_HANDLE;
    VkFormat colorFormat_ = VK_FORMAT_UNDEFINED;
    VkFormat depthFormat_ = VK_FORMAT_UNDEFINED;
    VkExtent2D extent_{0, 0};
    std::vector<VkImage> images_;
    std::vector<VkImageView> views_;
    std::vector<VkFramebuffer> framebuffers_;
    VkImage depthImage_ = VK_NULL_HANDLE;
    VkDeviceMemory depthMem_ = VK_NULL_HANDLE;
    VkImageView depthView_ = VK_NULL_HANDLE;

    VkRenderPass renderPass_ = VK_NULL_HANDLE;
    VkDescriptorSetLayout frameLayout_ = VK_NULL_HANDLE;
    VkDescriptorSetLayout matLayout_ = VK_NULL_HANDLE;
    VkPipelineLayout pipeLayout_ = VK_NULL_HANDLE;
    VkPipeline pipeline_ = VK_NULL_HANDLE;       // terreno
    VkPipeline rockPipe_ = VK_NULL_HANDLE;       // pedras (mesmo shader do terreno, sem culling)
    VkPipeline decoPipe_ = VK_NULL_HANDLE;       // árvores, arbustos, flores (cor de vértice)
    VkPipeline palmPipe_ = VK_NULL_HANDLE;       // coqueiros e árvores com vento
    VkPipeline skyPipe_ = VK_NULL_HANDLE;
    VkPipeline waterPipe_ = VK_NULL_HANDLE;
    VkPipeline shinePipe_ = VK_NULL_HANDLE;
    VkDescriptorPool descPool_ = VK_NULL_HANDLE;
    VkSampler sampler_ = VK_NULL_HANDLE;
    Tex tex_[5];
    VkDescriptorSet matSet_[5] = {};

    // mar
    VkSampler samplerClamp_ = VK_NULL_HANDLE;    // repete em U, trava em V (ondas na praia)
    Tex waterTex_, swashTex_, wetTex_, noiseTex_, whiteTex_;
    VkDescriptorSet waterSet_ = VK_NULL_HANDLE, swashSet_ = VK_NULL_HANDLE, wetSet_ = VK_NULL_HANDLE, noiseSet_ = VK_NULL_HANDLE, whiteSet_ = VK_NULL_HANDLE;
    GpuMesh planeMesh_, bandMesh_, foamMesh_[3];
    bool waterReady_ = false;

    // píer e ponte (estáticos) e barco (um buffer por quadro em voo)
    struct PropGpu { GpuMesh mesh; float cx = 0, cz = 0, r = 0; };
    PropGpu props_[2];
    // buffers que o CPU reescreve todo quadro (um por quadro em voo): barco, boneco (7 floats/vértice) e HUD
    struct DynBuf { VkBuffer buf[MAX_FRAMES] = {}; VkDeviceMemory mem[MAX_FRAMES] = {}; void* ptr[MAX_FRAMES] = {}; };
    static constexpr uint32_t kDynMaxVerts = 2048;      // barco e boneco
    static constexpr uint32_t kHudMaxVerts = 8192;
    DynBuf boatDyn_, playerDyn_, hudDyn_;
    bool createDynBuf(DynBuf& d, VkDeviceSize bytes);
    void destroyDynBuf(DynBuf& d);
    VkPipeline hudPipe_ = VK_NULL_HANDLE;        // camada 2D: alfa, sem profundidade
    Tex hudTex_;
    VkDescriptorSet hudSet_ = VK_NULL_HANDLE;
    bool hudReady_ = false;
    bool propsReady_ = false;

    VkCommandPool cmdPool_ = VK_NULL_HANDLE;
    VkCommandBuffer cmd_[MAX_FRAMES] = {};
    VkFence inFlight_[MAX_FRAMES] = {};
    VkSemaphore imageAvail_[MAX_FRAMES] = {};
    std::vector<VkSemaphore> renderDone_;       // um por imagem da swapchain
    VkBuffer ubo_[MAX_FRAMES] = {};
    VkDeviceMemory uboMem_[MAX_FRAMES] = {};
    void* uboPtr_[MAX_FRAMES] = {};
    VkDescriptorSet frameSet_[MAX_FRAMES] = {};
    int cur_ = 0;
    bool deviceReady_ = false;

    std::unordered_map<int, ChunkGpu> chunks_;            // chave = layer * 100000 + key
    std::vector<GpuMesh> retired_[MAX_FRAMES];            // buffers a destruir quando o quadro correspondente terminar
};
