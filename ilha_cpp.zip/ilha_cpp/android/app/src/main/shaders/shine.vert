#version 450
// Reflexo do céu no mar: um quadrado de 2,2 km em volta da câmera, rente à água (y = 0,045).
layout(set = 0, binding = 0) uniform Frame {
    mat4 viewProj;
    vec4 camPos;
} f;

layout(location = 0) out vec3 vPos;

void main() {
    const vec2 Q[6] = vec2[6](vec2(-1.0, -1.0), vec2(1.0, -1.0), vec2(1.0, 1.0), vec2(-1.0, -1.0), vec2(1.0, 1.0), vec2(-1.0, 1.0));
    vec2 q = Q[gl_VertexIndex];
    vPos = vec3(f.camPos.x + q.x * 1100.0, 0.045, f.camPos.z + q.y * 1100.0);
    gl_Position = f.viewProj * vec4(vPos, 1.0);
}
