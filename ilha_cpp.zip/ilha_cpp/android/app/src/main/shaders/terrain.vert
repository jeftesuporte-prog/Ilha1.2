#version 450
// Terreno: vértice = posição, normal, cor (RGBA8) e UV (stride 36 bytes, igual ao MeshAccum de 9 floats).
layout(location = 0) in vec3 inPos;
layout(location = 1) in vec3 inNormal;
layout(location = 2) in vec4 inColor;
layout(location = 3) in vec2 inUV;

layout(set = 0, binding = 0) uniform Frame {
    mat4 viewProj;
    vec4 camPos;       // xyz
    vec4 toLight;      // xyz = direção PARA o sol
    vec4 lightColor;   // rgb
    vec4 ambient;      // rgb
    vec4 fogColor;     // rgb
    vec4 params;       // x = 1/(far*far)
} f;

layout(location = 0) out vec3 vNormal;
layout(location = 1) out vec4 vColor;
layout(location = 2) out vec2 vUV;
layout(location = 3) out float vFog;

void main() {
    gl_Position = f.viewProj * vec4(inPos, 1.0);
    vNormal = inNormal;
    vColor = inColor;
    vUV = inUV;
    vec3 d = inPos - f.camPos.xyz;
    vFog = min(dot(d, d) * f.params.x, 1.0);     // mesma névoa do libGDX: (distância/far)^2
}
