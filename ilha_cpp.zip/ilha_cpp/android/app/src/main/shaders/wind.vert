#version 450
// Coqueiros e árvores com vento: igual ao deco.vert, mais o balanço (WindGlsl.SWAY do Kotlin = shaders/wind_sway.glsl).
layout(location = 0) in vec3 inPos;
layout(location = 1) in vec3 inNormal;
layout(location = 2) in vec4 inColor;
layout(location = 3) in vec3 a_wind;     // x = quanto está alto na árvore (dobra), y = fase própria, z = tremor da folha

// Bloco "Frame" COMPLETO (o vento fica no fim): tem que ter o mesmo layout std140 do FrameUBO do C++.
layout(set = 0, binding = 0) uniform Frame {
    mat4 viewProj;
    vec4 camPos;
    vec4 toLight;
    vec4 lightColor;
    vec4 ambient;
    vec4 fogColor;
    vec4 params;
    mat4 invPV;
    vec4 top;
    vec4 hor;
    vec4 sun;
    vec4 sunH;
    vec4 warm1;
    vec4 warm2;
    vec4 warm3;
    vec4 halo;
    vec4 sunE;
    vec4 sunN;
    vec4 sunP;
    vec4 sunCol;
    vec4 moon;
    vec4 sunGlit;
    vec4 moonGlit;
    vec4 shine;
    vec4 wind;         // x = tempo, y = rajada, zw = direção do vento
} f;

layout(location = 0) out vec3 vNormal;
layout(location = 1) out vec4 vColor;
layout(location = 2) out float vFog;

void main() {
    vec4 pos = vec4(inPos, 1.0);
    float windTime = f.wind.x;
    float windGust = f.wind.y;
    vec2 windDir = f.wind.zw;
    {
        vec3 p0 = pos.xyz;
        float w = a_wind.x;
        float ph = a_wind.y;
        float fl = a_wind.z;
        float tt = windTime;
        float g = windGust * (0.85 + 0.15 * sin(tt * 0.6 + p0.x * 0.05 + p0.z * 0.04));
        float sw = 0.6 * sin(tt * 0.9 + ph) + 0.4 * sin(tt * 1.7 + ph * 1.9 + 1.3);
        float along = 0.03 + 0.03 * sin(tt * 0.5 + ph) + g * (0.55 + 0.25 * sw);
        float across = 0.10 * g * sin(tt * 1.3 + ph * 2.1);
        vec2 wd = windDir;
        pos.x += (wd.x * along - wd.y * across) * w;
        pos.z += (wd.y * along + wd.x * across) * w;
        float fk = fl * min(1.0, w * 3.0);     // (no wind_sway.glsl chama "f": aqui "f" é o bloco de uniformes)
        float fm = 0.12 + 0.88 * g;
        pos.x += fk * 0.08 * fm * sin(tt * 3.1 + ph * 3.0 + p0.x * 0.9 + p0.z * 0.7);
        pos.z += fk * 0.08 * fm * sin(tt * 2.7 + ph * 2.0 + p0.z * 0.9 + p0.x * 0.6);
        pos.y += fk * 0.05 * fm * sin(tt * 4.3 + ph + p0.x * 1.1 + p0.z * 1.3);
    }
    gl_Position = f.viewProj * pos;
    vNormal = inNormal;
    vColor = inColor;
    vec3 d = pos.xyz - f.camPos.xyz;
    vFog = min(dot(d, d) * f.params.x, 1.0);
}
