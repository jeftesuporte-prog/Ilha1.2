#version 450
// Céu pixel a pixel (port do SkyGlsl.SKY_FRAG): degradê azul + camadas do pôr do sol + brilho e disco do sol.
layout(location = 0) in vec2 vNdc;

layout(set = 0, binding = 0) uniform Frame {
    mat4 viewProj;
    vec4 camPos;       // xyz, w = tempo
    vec4 toLight;
    vec4 lightColor;
    vec4 ambient;
    vec4 fogColor;
    vec4 params;
    mat4 invPV;
    vec4 top;          // rgb, w = tw (0 = sem crepúsculo, 1 = auge)
    vec4 hor;
    vec4 sun;          // xyz = direção PARA o sol
    vec4 sunH;         // xy = direção horizontal do sol
    vec4 warm1;
    vec4 warm2;
    vec4 warm3;
    vec4 halo;
    vec4 sunE;
    vec4 sunN;
    vec4 sunP;         // x = raio do disco, y = achatamento
    vec4 sunCol;
    vec4 moon;
    vec4 sunGlit;
    vec4 moonGlit;
    vec4 shine;
} f;

layout(location = 0) out vec4 outColor;

vec3 skyColor(vec3 d) {
    float y = max(d.y, 0.0);
    float fr = pow(clamp(y / 0.9, 0.0, 1.0), 0.45);
    vec3 col = mix(f.hor.rgb, f.top.rgb, fr);
    vec2 dh = d.xz / (length(d.xz) + 0.00001);
    float a = clamp(0.5 + 0.5 * dot(dh, f.sunH.xy), 0.0, 1.0);
    float wa = pow(a, 2.2);
    float ext = mix(0.30, 0.80, wa);
    vec3 lay = mix(f.warm1.rgb, f.warm2.rgb, smoothstep(0.0, 0.20, y));
    lay = mix(lay, f.warm3.rgb, smoothstep(0.14, 0.55, y));
    float wl = f.top.w * wa * (1.0 - smoothstep(0.0, 1.0, y / ext));
    col = mix(col, lay, clamp(wl * 0.9, 0.0, 1.0));
    vec3 belt = mix(f.warm2.rgb, f.hor.rgb, 0.5);
    float wb = f.top.w * (1.0 - a) * 0.5 * (1.0 - smoothstep(0.0, 0.28, y));
    col = mix(col, belt, wb);
    float cs = clamp(dot(d, f.sun.xyz), 0.0, 1.0);
    float halo = pow(cs, 24.0) * 0.35 + pow(cs, 400.0) * 0.6;
    col += f.halo.rgb * halo;
    return clamp(col, 0.0, 1.0);
}

void main() {
    vec4 p = f.invPV * vec4(vNdc, 1.0, 1.0);
    vec3 d = normalize(p.xyz / p.w - f.camPos.xyz);
    vec3 col = skyColor(d);

    float sunR = f.sunP.x;
    float cs0 = dot(d, f.sun.xyz);
    float px = dot(d, f.sunE.xyz);
    float py = dot(d, f.sunN.xyz) * f.sunP.y;
    float rr = sqrt(px * px + py * py);
    float front = step(0.0, cs0);
    float vis = front * smoothstep(0.0, 0.0014, d.y);
    float disc = (1.0 - smoothstep(sunR * 0.93, sunR * 1.03, rr)) * vis;
    float bloom = exp(-max(rr - sunR, 0.0) / (sunR * 1.6)) * 0.30 * front * smoothstep(-0.01, 0.01, d.y);
    col += f.sunCol.rgb * (bloom * 0.5 * f.halo.r);
    float rn = clamp(rr / sunR, 0.0, 1.0);
    float core = 1.0 - rn * rn;
    vec3 dcol = mix(f.sunCol.rgb, vec3(1.0, 0.98, 0.88), 0.30 + 0.55 * core);
    col = mix(col, dcol, disc);

    float n = fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453);
    col += (n - 0.5) / 255.0;                       // ruído leve: evita faixas no degradê
    outColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
