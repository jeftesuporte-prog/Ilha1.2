#version 450
layout(location = 0) in vec3 vNormal;
layout(location = 1) in vec4 vColor;
layout(location = 2) in float vFog;

layout(set = 0, binding = 0) uniform Frame {
    mat4 viewProj;
    vec4 camPos;
    vec4 toLight;
    vec4 lightColor;
    vec4 ambient;
    vec4 fogColor;
    vec4 params;
} f;

layout(location = 0) out vec4 outColor;

void main() {
    vec3 n = normalize(vNormal);
    float nd = max(dot(n, normalize(f.toLight.xyz)), 0.0);
    vec3 lit = vColor.rgb * (f.ambient.rgb + f.lightColor.rgb * nd);   // mesma luz do terreno, sem textura
    outColor = vec4(mix(lit, f.fogColor.rgb, vFog), 1.0);
}
