#version 450
// Mar, ondas na praia (swash/wet) e espuma: mesmo formato de vértice do terreno.
layout(location = 0) in vec3 inPos;
layout(location = 1) in vec3 inNormal;
layout(location = 2) in vec4 inColor;
layout(location = 3) in vec2 inUV;

layout(set = 0, binding = 0) uniform Frame {
    mat4 viewProj;
    vec4 camPos;
    vec4 toLight;
    vec4 lightColor;
    vec4 ambient;
    vec4 fogColor;
    vec4 params;
} f;

layout(push_constant) uniform PC {
    vec4 trans;    // xyz = deslocamento do modelo, w = opacidade
    vec4 uvx;      // offsetU, offsetV, scaleU, scaleV
} pc;

layout(location = 0) out vec3 vNormal;
layout(location = 1) out vec4 vColor;
layout(location = 2) out vec2 vUV;
layout(location = 3) out float vFog;

void main() {
    vec3 wp = inPos + pc.trans.xyz;
    gl_Position = f.viewProj * vec4(wp, 1.0);
    vNormal = inNormal;
    vColor = inColor;
    vUV = pc.uvx.xy + inUV * pc.uvx.zw;
    vec3 d = wp - f.camPos.xyz;
    vFog = min(dot(d, d) * f.params.x, 1.0);
}
