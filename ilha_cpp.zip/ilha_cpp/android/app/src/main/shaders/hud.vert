#version 450
// Camada 2D: posição em pixels (y para baixo) -> tela. Largura e altura da tela vão em push constant (trans.xy).
layout(location = 0) in vec2 inPos;
layout(location = 1) in vec2 inUV;
layout(location = 2) in vec4 inColor;

layout(push_constant) uniform PC {
    vec4 trans;    // xy = largura e altura da tela em pixels
    vec4 uvx;
} pc;

layout(location = 0) out vec2 vUV;
layout(location = 1) out vec4 vColor;

void main() {
    gl_Position = vec4(inPos.x / pc.trans.x * 2.0 - 1.0, inPos.y / pc.trans.y * 2.0 - 1.0, 0.0, 1.0);
    vUV = inUV;
    vColor = inColor;
}
