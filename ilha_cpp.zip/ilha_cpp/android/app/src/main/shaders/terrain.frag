#version 450
layout(location = 0) in vec3 vNormal;
layout(location = 1) in vec4 vColor;
layout(location = 2) in vec2 vUV;
layout(location = 3) in float vFog;

layout(set = 0, binding = 0) uniform Frame {
    mat4 viewProj;
    vec4 camPos;
    vec4 toLight;
    vec4 lightColor;
    vec4 ambient;
    vec4 fogColor;
    vec4 params;
} f;

layout(set = 1, binding = 0) uniform sampler2D tex;

layout(location = 0) out vec4 outColor;

void main() {
    vec4 base = texture(tex, vUV) * vColor;                    // textura x cor do vértice
    vec3 n = normalize(vNormal);
    float nd = max(dot(n, normalize(f.toLight.xyz)), 0.0);
    vec3 lit = base.rgb * (f.ambient.rgb + f.lightColor.rgb * nd);   // luz do céu + sol
    outColor = vec4(mix(lit, f.fogColor.rgb, vFog), 1.0);
}
