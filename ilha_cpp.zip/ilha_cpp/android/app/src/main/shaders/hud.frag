#version 450
layout(location = 0) in vec2 vUV;
layout(location = 1) in vec4 vColor;

layout(set = 1, binding = 0) uniform sampler2D tex;   // atlas da fonte: RGB branco, alfa = cobertura (o bloco branco serve para formas)

layout(location = 0) out vec4 outColor;

void main() {
    outColor = vColor * texture(tex, vUV);
}
