#version 450
// Céu: um triângulo que cobre a tela inteira; cada pixel calcula a cor da direção em que olha (sky.frag).
layout(location = 0) out vec2 vNdc;

void main() {
    vec2 p = vec2(float((gl_VertexIndex << 1) & 2), float(gl_VertexIndex & 2));   // (0,0) (2,0) (0,2)
    vec2 ndc = p * 2.0 - 1.0;
    vNdc = ndc;
    gl_Position = vec4(ndc, 0.0, 1.0);
}
