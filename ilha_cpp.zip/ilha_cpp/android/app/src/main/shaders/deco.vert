#version 450
// Vegetação de cor de vértice (árvores, arbustos, flores): vértice = posição, normal e cor RGBA8 (stride 28 bytes, sem UV).
layout(location = 0) in vec3 inPos;
layout(location = 1) in vec3 inNormal;
layout(location = 2) in vec4 inColor;

layout(set = 0, binding = 0) uniform Frame {
    mat4 viewProj;
    vec4 camPos;
    vec4 toLight;
    vec4 lightColor;
    vec4 ambient;
    vec4 fogColor;
    vec4 params;       // x = 1/(far*far)
} f;

layout(location = 0) out vec3 vNormal;
layout(location = 1) out vec4 vColor;
layout(location = 2) out float vFog;

void main() {
    gl_Position = f.viewProj * vec4(inPos, 1.0);
    vNormal = inNormal;
    vColor = inColor;
    vec3 d = inPos - f.camPos.xyz;
    vFog = min(dot(d, d) * f.params.x, 1.0);
}
