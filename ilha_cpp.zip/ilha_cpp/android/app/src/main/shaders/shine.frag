#version 450
// Fresnel + céu refletido + trilha de brilho do sol/lua com cintilar das ondinhas (port do SkyGlsl.SHINE_FRAG).
layout(location = 0) in vec3 vPos;

layout(set = 0, binding = 0) uniform Frame {
    mat4 viewProj;
    vec4 camPos;       // xyz, w = tempo
    vec4 toLight;
    vec4 lightColor;
    vec4 ambient;
    vec4 fogColor;
    vec4 params;
    mat4 invPV;
    vec4 top;
    vec4 hor;
    vec4 sun;
    vec4 sunH;
    vec4 warm1;
    vec4 warm2;
    vec4 warm3;
    vec4 halo;
    vec4 sunE;
    vec4 sunN;
    vec4 sunP;
    vec4 sunCol;
    vec4 moon;
    vec4 sunGlit;
    vec4 moonGlit;
    vec4 shine;        // x = força do reflexo
} f;

layout(set = 1, binding = 0) uniform sampler2D uNoise;

layout(location = 0) out vec4 outColor;

vec3 skyColor(vec3 d) {
    float y = max(d.y, 0.0);
    float fr = pow(clamp(y / 0.9, 0.0, 1.0), 0.45);
    vec3 col = mix(f.hor.rgb, f.top.rgb, fr);
    vec2 dh = d.xz / (length(d.xz) + 0.00001);
    float a = clamp(0.5 + 0.5 * dot(dh, f.sunH.xy), 0.0, 1.0);
    float wa = pow(a, 2.2);
    float ext = mix(0.30, 0.80, wa);
    vec3 lay = mix(f.warm1.rgb, f.warm2.rgb, smoothstep(0.0, 0.20, y));
    lay = mix(lay, f.warm3.rgb, smoothstep(0.14, 0.55, y));
    float wl = f.top.w * wa * (1.0 - smoothstep(0.0, 1.0, y / ext));
    col = mix(col, lay, clamp(wl * 0.9, 0.0, 1.0));
    vec3 belt = mix(f.warm2.rgb, f.hor.rgb, 0.5);
    float wb = f.top.w * (1.0 - a) * 0.5 * (1.0 - smoothstep(0.0, 0.28, y));
    col = mix(col, belt, wb);
    float cs = clamp(dot(d, f.sun.xyz), 0.0, 1.0);
    float halo = pow(cs, 24.0) * 0.35 + pow(cs, 400.0) * 0.6;
    col += f.halo.rgb * halo;
    return clamp(col, 0.0, 1.0);
}

float lobeFor(vec3 V, vec3 S, float m) {
    vec3 H = V + S;
    H = H / max(length(H), 0.0001);
    float hy = max(H.y, 0.004);
    float tanSq = (H.x * H.x + H.z * H.z) / (hy * hy);
    return exp(-tanSq / (m * m));
}

void main() {
    float time = f.camPos.w;
    vec3 V = f.camPos.xyz - vPos;
    V = V / max(length(V), 0.0001);

    vec2 w1 = texture(uNoise, vPos.xz * 0.050 + vec2(time * 0.010, time * 0.006)).rg - 0.5;
    vec2 w2 = texture(uNoise, vPos.xz * 0.190 + vec2(-time * 0.018, time * 0.012)).rg - 0.5;
    vec2 sl = w1 * 0.45 + w2 * 0.55;
    vec3 N = normalize(vec3(-sl.x, 1.0, -sl.y));

    float nv = clamp(dot(N, V), 0.0, 1.0);
    float fr = 0.02 + 0.98 * pow(1.0 - nv, 5.0);
    vec3 R = reflect(-V, N);
    R = normalize(vec3(R.x, max(R.y, 0.01), R.z));
    vec3 sk = skyColor(R);
    float refl = clamp(fr * f.shine.x, 0.0, 1.0);

    float g1 = texture(uNoise, vPos.xz * 0.22 + vec2(time * 0.05, -time * 0.03)).b;
    float g2 = texture(uNoise, vPos.xz * 0.37 + vec2(-time * 0.04, time * 0.07)).a;
    float glint = clamp(pow(g1 * g2, 1.2) * 3.0, 0.0, 1.5);
    float sm = 0.45 + glint * 0.75;
    float fw = 0.30 + 0.70 * fr;
    vec3 glit = (f.sunGlit.rgb * lobeFor(V, f.sun.xyz, 0.26) + f.moonGlit.rgb * lobeFor(V, f.moon.xyz, 0.26)) * (fw * sm);

    outColor = vec4(sk * refl + glit, refl);        // alfa pré-multiplicado (blend ONE, ONE_MINUS_SRC_ALPHA)
}
