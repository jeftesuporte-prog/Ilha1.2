#version 450
layout(location = 0) in vec3 vNormal;
layout(location = 1) in vec4 vColor;
layout(location = 2) in vec2 vUV;
layout(location = 3) in float vFog;

layout(set = 0, binding = 0) uniform Frame {
    mat4 viewProj;
    vec4 camPos;
    vec4 toLight;
    vec4 lightColor;
    vec4 ambient;
    vec4 fogColor;
    vec4 params;
} f;

layout(set = 1, binding = 0) uniform sampler2D tex;

layout(push_constant) uniform PC {
    vec4 trans;
    vec4 uvx;
} pc;

layout(location = 0) out vec4 outColor;

void main() {
    vec4 base = texture(tex, vUV) * vColor;
    vec3 n = normalize(vNormal);
    float nd = max(dot(n, normalize(f.toLight.xyz)), 0.0);
    vec3 lit = base.rgb * (f.ambient.rgb + f.lightColor.rgb * nd);
    outColor = vec4(mix(lit, f.fogColor.rgb, vFog), base.a * pc.trans.w);   // a névoa só mistura a cor; a opacidade fica
}
