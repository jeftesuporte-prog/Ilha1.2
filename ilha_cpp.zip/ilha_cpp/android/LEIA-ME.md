# Como compilar e rodar (Etapa 4)

## O que instalar (uma vez)
1. **Android Studio** (versão recente).
2. Em *Settings > Languages & Frameworks > Android SDK > SDK Tools*, marque e instale:
   **NDK (Side by side)**, **CMake 3.22.1**, e **Android SDK Platform 34**.
3. Celular com Android 7.0+ e Vulkan (quase todos de 2018 em diante), com **depuração USB** ligada.

## Rodar
1. No Android Studio: **File > Open** e escolha a pasta `android/` (a que tem o `settings.gradle`).
2. Espere o *Gradle sync*. Se ele pedir para instalar algo (NDK, CMake, plataforma), aceite.
3. Conecte o celular e clique em **Run**.
4. Controles: **dedo na metade esquerda** = andar (arraste para onde quer ir); **metade direita** = arrastar para olhar.

Você deve ver: a ilha começando às **6h12 (amanhecer rosa)**, com o dia passando em 10 minutos (sol, pôr do sol e noite),
o **mar** com duas camadas de ondas, **ondas subindo a praia**, anéis de **espuma** e o **brilho do sol** na água.
Ainda **sem árvores** (etapa 3B) e **sem nuvens, estrelas e lua** (etapa 5B). De noite o céu fica escuro e vazio por enquanto.
O log (`Ilha` no Logcat) mostra fps, o nível de qualidade e a hora do jogo a cada 2 segundos. O jogo começa em **MÉDIO** e sobe/desce
sozinho conforme o FPS do seu celular (aparece "Qualidade -> ..." no log quando muda).

## Se der erro
- **Erro de compilação**: copie as primeiras linhas do erro (a aba *Build*) e me mande. O código Vulkan foi escrito
  sem poder compilar no meu ambiente, então é esperado que apareça um ou outro ajuste.
- **App abre e fecha / tela preta**: no Android Studio abra a aba **Logcat**, filtre por `Ilha` e mande o que aparecer
  (as mensagens de erro do meu código começam com "Vulkan erro" ou "Asset nao encontrado").
- **Se aparecer "Asset nao encontrado: shaders/terrain.vert.spv"**: o Gradle não compilou os shaders. Me avise com
  a versão do Android Studio que você usa.
- **Mar preto/branco ou sem brilho, céu estranho**: me mande o Logcat e uma foto da tela; os shaders (`sky`, `water`, `shine`) são os mais novos e nunca rodaram.
- **Terreno invisível/de dentro para fora**: avise; é um ajuste de 1 linha (`kCullBackFaces` em `VkEngine.cpp`).

## Notas
- O build é só `arm64-v8a`. Para emulador x86_64, acrescente `'x86_64'` em `abiFilters` no `app/build.gradle`.
- O `run_tests.sh` na pasta de cima continua rodando no PC (precisa de g++, java 11+ e python3).
