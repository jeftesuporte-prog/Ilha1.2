#!/usr/bin/env python3
# Gera src/HudFont.h: atlas de fonte (alfa 8 bits) do HUD, ASCII 32..126, mais um bloco branco para desenhar formas.
# O libGDX usa a Arial 15 embutida; a Liberation Sans tem a mesma métrica da Arial e é livre (SIL OFL).
# Uso:  python3 tools/gen_font.py [caminho da fonte .ttf]     (precisa do Pillow)
import sys
from PIL import Image, ImageDraw, ImageFont
path = sys.argv[1] if len(sys.argv) > 1 else '/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf'
SIZE = 15
font = ImageFont.truetype(path, SIZE)
ascent, descent = font.getmetrics()
CW, CH, COLS, ROWS = 16, 20, 16, 7
W, H = 256, 128
img = Image.new('L', (W, H), 0)
d = ImageDraw.Draw(img)
cap = ascent - font.getbbox('H')[1]
glyphs = []
for i, code in enumerate(range(32, 127)):
    ch = chr(code)
    cx, cy = (i % COLS) * CW, (i // COLS) * CH
    l, t, r, b = font.getbbox(ch)
    adv = int(round(font.getlength(ch)))
    if r > l and b > t:
        d.text((cx + 1 - l, cy + 1 - t), ch, font=font, fill=255)   # bbox desenhada com 1 px de folga no canto da célula
        glyphs.append((cx + 1, cy + 1, r - l, b - t, l, t - ascent, adv))
    else:
        glyphs.append((cx + 1, cy + 1, 0, 0, 0, 0, adv))
# bloco branco 4x4 (centro usado para formas sólidas): última linha da grade
WX, WY = 4, ROWS * CH - CH + 4
d.rectangle([WX, WY, WX + 3, WY + 3], fill=255)
px = list(img.getdata())
out = ['#pragma once',
       '// GERADO por tools/gen_font.py (Liberation Sans %d px). Não edite à mão.' % SIZE,
       '#include <cstdint>', 'namespace HudFont {',
       f'constexpr int W = {W}, H = {H};', f'constexpr int ASCENT = {ascent}, DESCENT = {descent}, CAP = {cap}, LINE = {ascent + descent};',
       f'constexpr int WHITE_X = {WX}, WHITE_Y = {WY};   // bloco 4x4 branco',
       'struct Glyph { int16_t x, y, w, h, xoff, yoff, adv; };   // yoff = topo do desenho em relação à linha de base (negativo = acima)',
       'constexpr Glyph GLYPHS[95] = {']
for g in glyphs: out.append('    {%d, %d, %d, %d, %d, %d, %d},' % g)
out.append('};')
out.append('constexpr uint8_t ATLAS[W * H] = {')
for i in range(0, len(px), 32): out.append('    ' + ','.join(str(v) for v in px[i:i + 32]) + ',')
out.append('};')
out.append('}  // namespace HudFont')
open('src/HudFont.h', 'w').write('\n'.join(out) + '\n')
img.save('/tmp/hud_atlas.png')
print('ok: ascent', ascent, 'descent', descent, 'cap', cap, 'glifos', len(glyphs))
