#include <cstdio>
#include "../src/World.h"
int main() {
    std::printf("%.9g %.9g %.9g %.9g %.9g %.9g %.9g %.9g %d\n", RoadNet::shoreX(), RoadNet::shoreZ(), RoadNet::bridgeX(), RoadNet::bridgeZ(),
                RoadNet::bridgeTX(), RoadNet::bridgeTZ(), Bridge::deckY(), Bridge::pitchDeg(), 627);
    float o[10];
    int idx = 0;
    for (int i = -60; i <= 60; i++) for (int j = -60; j <= 60; j++) {
        float x = i * 8.7f + 0.37f * (float)(j % 5), z = j * 8.3f - 0.41f * (float)(i % 7);
        float h = World::heightAt(x, z);
        float ny = 0.55f + 0.45f * ((float)(idx * 37 % 100) / 100.0f); idx++;
        World::sample(x, z, h, ny, o, 0);
        std::printf("%.9g %.9g %.9g %.9g %.9g", Base::depth(x, z), Base::baseHeight(x, z), h, World::groundAt(x, z), River::dist(x, z));
        for (int k = 0; k < 10; k++) std::printf(" %.9g", o[k]);
        std::printf("\n");
    }
}
