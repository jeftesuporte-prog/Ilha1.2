// Etapa 6: HUD. Confere a geometria 2D: vértices válidos dentro da tela, textos com a largura certa, círculos com o nº de
// segmentos do ShapeRenderer, e cada elemento aparece só quando deve (analógico, PULAR, barco). Também grava um PPM do HUD.
#include <cmath>
#include <cstdio>
#include <cstring>
#include <vector>
#include "Hud.h"
#include "HudFont.h"

static int fails = 0;
#define CHECK(c, ...) do { if (!(c)) { fails++; std::printf("FALHA: "); std::printf(__VA_ARGS__); std::printf("\n"); } } while (0)

// rasteriza triângulos do HUD num PPM (só para ver: amostra o atlas, mistura com fundo azul)
static void render(const std::vector<HudVertex>& v, int W, int H, const char* path) {
    std::vector<float> img(W * H * 3);
    for (int i = 0; i < W * H; i++) { img[i*3] = 0.25f; img[i*3+1] = 0.45f; img[i*3+2] = 0.30f; }
    for (size_t i = 0; i + 2 < v.size(); i += 3) {
        const HudVertex &a = v[i], &b = v[i+1], &c = v[i+2];
        float minx = std::fmin(a.x, std::fmin(b.x, c.x)), maxx = std::fmax(a.x, std::fmax(b.x, c.x));
        float miny = std::fmin(a.y, std::fmin(b.y, c.y)), maxy = std::fmax(a.y, std::fmax(b.y, c.y));
        float den = (b.y - c.y) * (a.x - c.x) + (c.x - b.x) * (a.y - c.y);
        if (std::fabs(den) < 1e-9f) continue;
        for (int y = std::max(0, (int)miny); y <= std::min(H - 1, (int)maxy); y++) for (int x = std::max(0, (int)minx); x <= std::min(W - 1, (int)maxx); x++) {
            float px = x + 0.5f, py = y + 0.5f;
            float l1 = ((b.y - c.y) * (px - c.x) + (c.x - b.x) * (py - c.y)) / den;
            float l2 = ((c.y - a.y) * (px - c.x) + (a.x - c.x) * (py - c.y)) / den;
            float l3 = 1 - l1 - l2;
            if (l1 < 0 || l2 < 0 || l3 < 0) continue;
            float u = l1 * a.u + l2 * b.u + l3 * c.u, w = l1 * a.v + l2 * b.v + l3 * c.v;
            int tx = std::min(HudFont::W - 1, std::max(0, (int)(u * HudFont::W))), ty = std::min(HudFont::H - 1, std::max(0, (int)(w * HudFont::H)));
            float cov = HudFont::ATLAS[ty * HudFont::W + tx] / 255.0f;
            uint32_t col = a.rgba;
            float al = ((col >> 24) & 255) / 255.0f * cov;
            float cr = (col & 255) / 255.0f, cg = ((col >> 8) & 255) / 255.0f, cb = ((col >> 16) & 255) / 255.0f;
            img[(y * W + x) * 3] = img[(y * W + x) * 3] * (1 - al) + cr * al;
            img[(y * W + x) * 3 + 1] = img[(y * W + x) * 3 + 1] * (1 - al) + cg * al;
            img[(y * W + x) * 3 + 2] = img[(y * W + x) * 3 + 2] * (1 - al) + cb * al;
        }
    }
    FILE* f = std::fopen(path, "wb");
    std::fprintf(f, "P6\n%d %d\n255\n", W, H);
    for (float x : img) std::fputc((int)(std::fmin(1.0f, x) * 255), f);
    std::fclose(f);
}

int main() {
    const int W = 1280, H = 720;
    Controls c; c.setScreen(W, H);
    Hud::Info info; info.altitude = 7; info.fps = 59; info.terrainChunks = 54; info.decoChunks = 20; info.tod = 6.2f; info.day = 1;
    info.quality = "ALTO"; info.terrainR = 430; info.decoR = 250;
    std::vector<HudVertex> v;

    // escala do texto
    CHECK(std::fabs(Hud::textScale(540) - 1.0f) < 1e-6f && std::fabs(Hud::textScale(1080) - 2.0f) < 1e-6f && std::fabs(Hud::textScale(300) - 1.0f) < 1e-6f, "escala do texto");
    // largura: "PULAR" = soma dos avanços
    float w1 = Hud::textWidth("PULAR", 1.0f), w2 = Hud::textWidth("PULAR", 2.0f);
    CHECK(w1 > 20.0f && w1 < 60.0f && std::fabs(w2 - 2 * w1) < 1e-4f, "largura do texto %.1f / %.1f", w1, w2);

    // parado, sem dedo: PULAR (círculo + texto) + 4 linhas de texto; sem analógico
    Hud::build(c, info, v);
    size_t idle = v.size();
    CHECK(idle > 0 && idle % 3 == 0, "vértices %zu", idle);
    // tela 1280x720: raio do analógico = max(70, 720*0.12) = 86.4; PULAR = 0.8*86.4 = 69.12 => 6*cbrt(69.12) = 24 segmentos (ShapeRenderer)
    int segs = std::max(1, (int)(6.0f * std::cbrt(c.jumpR())));
    CHECK(std::fabs(c.radius - 86.4f) < 1e-3f && segs == 24, "raio %.2f, segmentos do círculo %d", c.radius, segs);
    // tudo dentro da tela, UV dentro do atlas, cor com alfa
    size_t bad = 0;
    for (const auto& q : v) if (!(q.x >= -1 && q.x <= W + 1 && q.y >= -1 && q.y <= H + 1 && q.u >= 0 && q.u <= 1 && q.v >= 0 && q.v <= 1 && (q.rgba >> 24) > 0)) bad++;
    CHECK(bad == 0, "%zu vértices fora da tela/atlas", bad);

    // analógico aparece só com o dedo e some no barco
    c.touchDown(0, 200, 500); c.touchMove(0, 260, 460); c.poll();
    Hud::build(c, info, v);
    size_t withJoy = v.size();
    int jsegs = std::max(1, (int)(6.0f * std::cbrt(c.radius))), ksegs = std::max(1, (int)(6.0f * std::cbrt(c.radius * 0.4f)));
    CHECK(withJoy == idle + 3u * (jsegs + ksegs), "analógico: %zu vértices a mais, esperado %d", withJoy - idle, 3 * (jsegs + ksegs));
    c.inBoat = true; Hud::build(c, info, v); CHECK(v.size() < withJoy, "no barco some o analógico e o PULAR"); c.inBoat = false;
    c.touchUp(0);

    // botões do barco
    c.showRow = true; c.act1Text = "DESAMARRAR"; c.act2Text = "SAIR"; c.inBoat = true;
    Hud::build(c, info, v);
    CHECK(v.size() > idle, "botões do barco aparecem");
    render(v, W, H, "/tmp/hud_barco.ppm");
    c.showRow = false; c.act1Text = c.act2Text = nullptr; c.inBoat = false;

    // texto da qualidade: só aparece com `quality`
    Hud::Info noq = info; noq.quality = nullptr;
    std::vector<HudVertex> v2; Hud::build(c, noq, v2); Hud::build(c, info, v);
    CHECK(v.size() > v2.size(), "linha de qualidade");

    // altitude negativa/truncada: -3.7 -> -3 (toInt do Kotlin trunca)
    // (a conversão é feita pelo chamador: aqui só confere que o texto aceita negativos sem quebrar)
    Hud::Info neg = info; neg.altitude = -3; Hud::build(c, neg, v2); CHECK(!v2.empty(), "altitude negativa");

    c.touchDown(1, 200, 500); c.touchMove(1, 290, 470); c.poll();
    Hud::build(c, info, v);
    render(v, W, H, "/tmp/hud_jogo.ppm");
    std::printf("hud: %zu vértices parado | %zu com analógico | imagens em /tmp/hud_*.ppm\n", idle, withJoy);
    if (fails) { std::printf("%d FALHAS\n", fails); return 1; }
    std::printf("HUD: tudo OK\n");
    return 0;
}
