#include <cstdio>
#include <cstdint>
#include <cstring>
#include <cmath>
#include "../src/Sky.h"
#include "../src/Cfg.h"

static void pc(const Color& c) { std::printf(" %.9g %.9g %.9g", c.r, c.g, c.b); }
static void pv(const V3& v) { std::printf(" %.9g %.9g %.9g", v.x, v.y, v.z); }



int main(int argc, char** argv) {
    (void)argc; (void)argv;
    Sky s;
    for (int i = 0; i < Sky::NSTARS; i++)
        std::printf("%.9g %.9g %.9g %.9g %.9g %.9g %.9g %d\n", s.sdx[i], s.sdy[i], s.sdz[i], s.ssz[i], s.sbr[i], s.sph[i], s.ssp[i], s.sty[i]);
    for (int step = 0; step < 6000; step++) {
        float dt = 0.05f + (float)(step % 7) * 0.01f;
        float dx = (float)std::cos((double)((float)step * 0.011f)), dz = (float)std::sin((double)((float)step * 0.013f));
        s.update(dt, 1.0f, 2.0f, dx, dz);
        s.noteCamera(dx, dz);
        if (step % 25 == 0 || !s.meteors.empty()) {
            std::printf("%.9g", s.tod); pv(s.toSun); pv(s.toMoon); pv(s.toLight); pc(s.topC); pc(s.horC); pc(s.fog); pc(s.ambient); pc(s.lightC);
            std::printf(" %.9g", s.tw); pc(s.warm1); pc(s.warm2); pc(s.warm3); pc(s.haloCol); pc(s.sunCol);
            std::printf(" %.9g %.9g", s.sunHx, s.sunHz); pv(s.sunEv); pv(s.sunNv);
            std::printf(" %.9g %.9g %.9g", s.sunR, s.sunSquash, s.warmK); pc(s.sunGlitCol); pc(s.moonGlitCol);
            for (int c : {0, 5, 13}) std::printf(" %.9g %.9g %.9g %.9g", s.clouds[c].x, s.clouds[c].er, s.clouds[c].eg, s.clouds[c].eb);
            std::printf(" %d", (int)s.meteors.size());
            if (!s.meteors.empty()) { const auto& m = s.meteors[0]; pv(m.d0); pv(m.tv); std::printf(" %.9g %.9g %.9g", m.speed, m.life, m.age); }
            std::printf("\n");
        }
    }
}
