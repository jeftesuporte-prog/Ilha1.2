#include <cstdio>
#include <cstdint>
#include <cstring>
#include <vector>
#include "../src/ChunkManager.h"
#include "../src/JavaRandom.h"

static void w32(FILE* f, uint32_t v) { std::fwrite(&v, 4, 1, f); }   // little-endian (x86/arm64)
static uint32_t bitsOf(float x) { uint32_t u; std::memcpy(&u, &x, 4); return u; }

int main(int argc, char** argv) {
    if (argc > 1 && std::strcmp(argv[1], "terrain") == 0) {
        const int chunks[][2] = {{0,0},{1,7},{2,6},{2,5},{3,5},{5,5},{5,6},{4,4},{6,3},{8,7},{9,9},{7,2}};
        FILE* f = std::fopen("/tmp/terrain_cpp.bin", "wb");
        for (auto& c : chunks) {
            Built b = ChunkBuilder::terrain(c[0], c[1]);
            w32(f, (uint32_t)b.parts.size()); w32(f, bitsOf(b.minY)); w32(f, bitsOf(b.maxY));
            for (size_t p = 0; p < b.parts.size(); p++) {
                w32(f, (uint32_t)b.mats[p]); w32(f, (uint32_t)b.parts[p].size());
                for (float v : b.parts[p]) w32(f, bitsOf(v));
            }
        }
        std::fclose(f);
        return 0;
    }
    // colisão: mesmos dados do teste Java
    ChunkManager cm;
    JavaRandom r(5);
    for (int key = 0; key < 100; key++) {
        std::vector<float> a(24);
        for (int i = 0; i < 8; i++) {
            a[i*3]   = (float)(key % 10) * 100.0f - 500.0f + r.nextFloat() * 100.0f;
            a[i*3+1] = (float)(key / 10) * 100.0f - 500.0f + r.nextFloat() * 100.0f;
            a[i*3+2] = 0.4f + r.nextFloat();
        }
        cm.solids[key] = a;
        std::vector<float> b(15);
        for (int i = 0; i < 3; i++) {
            b[i*5]   = (float)(key % 10) * 100.0f - 500.0f + r.nextFloat() * 100.0f;
            b[i*5+1] = (float)(key / 10) * 100.0f - 500.0f + r.nextFloat() * 100.0f;
            b[i*5+2] = 2.0f + r.nextFloat() * 5.0f;
            b[i*5+3] = 1.5f + r.nextFloat() * 3.0f;
            b[i*5+4] = 1.0f + r.nextFloat() * 2.0f;
        }
        cm.rockMap[key] = b;
    }
    for (int t = 0; t < 20000; t++) {
        float x = -520.0f + r.nextFloat() * 1040.0f, z = -520.0f + r.nextFloat() * 1040.0f;
        float p[2] = {x, z};
        cm.pushOutSolids(p, 0.35f);   // só troncos/pedras: é o que a referência Java tem (as colmeias têm teste próprio no player_test)
        std::printf("%.9g %.9g %.9g\n", p[0], p[1], cm.rockFloor(x, z, 1.5f));
    }
}
