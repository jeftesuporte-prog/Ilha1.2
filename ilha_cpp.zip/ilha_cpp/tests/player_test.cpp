// Etapa 6: Player. Roda a MESMA simulação da referência em Java (4 trajetos: campo, ponte nos dois sentidos, píer) e imprime
// o estado de cada quadro para o compare.py. Com o argumento "checks" roda as verificações extras (colmeias, modelo, grades).
#include <cmath>
#include <cstdio>
#include <cstring>
#include <vector>
#include "Apiario.h"
#include "ChunkManager.h"
#include "JavaRandom.h"
#include "Player.h"
#include "World.h"

// colisão só com troncos/pedras: é o que a referência em Java tem (as colmeias são testadas à parte)
struct SolidsOnly : Colliders {
    ChunkManager& cm;
    explicit SolidsOnly(ChunkManager& c) : cm(c) {}
    void pushOut(float o[2], float pr) const override { cm.pushOutSolids(o, pr); }
    float rockFloor(float x, float z, float b) const override { return cm.rockFloor(x, z, b); }
};

static void fakeColliders(ChunkManager& cm) {
    JavaRandom r(5);
    for (int key = 0; key < 100; key++) {
        std::vector<float> a(24);
        for (int i = 0; i < 8; i++) {
            a[i*3] = (float)(key % 10) * 100.0f - 500.0f + r.nextFloat() * 100.0f;
            a[i*3+1] = (float)(key / 10) * 100.0f - 500.0f + r.nextFloat() * 100.0f;
            a[i*3+2] = 0.4f + r.nextFloat();
        }
        cm.solids[key] = a;
        std::vector<float> b(15);
        for (int i = 0; i < 3; i++) {
            b[i*5] = (float)(key % 10) * 100.0f - 500.0f + r.nextFloat() * 100.0f;
            b[i*5+1] = (float)(key / 10) * 100.0f - 500.0f + r.nextFloat() * 100.0f;
            b[i*5+2] = 2.0f + r.nextFloat() * 5.0f;
            b[i*5+3] = 1.5f + r.nextFloat() * 3.0f;
            b[i*5+4] = 1.0f + r.nextFloat() * 2.0f;
        }
        cm.rockMap[key] = b;
    }
}

static int fails = 0;
#define CHECK(c, ...) do { if (!(c)) { fails++; std::printf("FALHA: "); std::printf(__VA_ARGS__); std::printf("\n"); } } while (0)

int main(int argc, char** argv) {
    ChunkManager cm;
    fakeColliders(cm);
    SolidsOnly col(cm);

    if (argc > 1 && std::strcmp(argv[1], "checks") == 0) {
        // 1) colmeia é sólida: um ponto em cima do tronco é empurrado para fora (raio do tronco 0,35 + boneco 0,35)
        const auto& hv = Apiario::hives();
        CHECK(!hv.empty(), "sem colmeias");
        int pushed = 0;
        for (const auto& h : hv) {
            float p[2] = {h.x + 0.1f, h.z + 0.05f};
            cm.pushOut(p, Cfg::PLAYER_R);
            float d = std::hypot(p[0] - h.x, p[1] - h.z);
            if (d >= 0.35f + Cfg::PLAYER_R - 1e-3f) pushed++;
            float q[2] = {h.x + 5.0f, h.z};     // longe: não mexe
            float q0 = q[0]; cm.pushOut(q, Cfg::PLAYER_R);
            CHECK(q[0] == q0, "colmeia empurrou ponto distante");
        }
        CHECK(pushed == (int)hv.size(), "colmeia não empurrou em %zu casos", hv.size() - pushed);

        // 2) boneco andando contra uma colmeia não atravessa
        {
            const auto& h = hv[0];
            ChunkManager cm2; // sem sólidos: só as colmeias contam
            Player pl; pl.place(h.x - 4.0f, h.z, 0.0f);
            float minD = 1e9f;
            for (int i = 0; i < 400; i++) {
                bool j = false;
                pl.drive(0.0f, 0.0f, 1.0f, false, j, 1.0f / 60.0f, cm2);   // yaw 0 = anda para +X, direto na colmeia
                minD = std::fmin(minD, std::hypot(pl.pos.x - h.x, pl.pos.z - h.z));
            }
            CHECK(minD >= 0.35f + Cfg::PLAYER_R - 0.02f, "boneco atravessou a colmeia (min %.3f)", minD);
            std::printf("colmeia: distância mínima do boneco ao tronco %.3f m (esperado >= %.2f)\n", minD, 0.35f + Cfg::PLAYER_R);
        }

        // 3) modelo: 7 caixas = 252 vértices, 1,75 m de altura, finitos, normais unitárias
        {
            Player pl; pl.place(10.0f, 20.0f, 33.0f);
            std::vector<float> m; pl.buildModel(m);
            CHECK(m.size() == 7u * 36 * 7, "modelo com %zu vértices", m.size() / 7);
            float mn = 1e9f, mx = -1e9f; size_t bad = 0;
            for (size_t i = 0; i + 6 < m.size(); i += 7) {
                mn = std::fmin(mn, m[i + 1]); mx = std::fmax(mx, m[i + 1]);
                float l = std::sqrt(m[i+3]*m[i+3] + m[i+4]*m[i+4] + m[i+5]*m[i+5]);
                if (!std::isfinite(l) || std::fabs(l - 1.0f) > 1e-3f) bad++;
            }
            float g = World::groundAt(10.0f, 20.0f);
            CHECK(bad == 0, "%zu normais inválidas", bad);
            CHECK(std::fabs(mn - g) < 1e-3f && std::fabs((mx - mn) - 1.75f) < 1e-3f, "altura do boneco %.4f (pés %.3f, chão %.3f)", mx - mn, mn, g);
            std::printf("modelo: %zu vértices | altura %.3f m\n", m.size() / 7, mx - mn);
        }

        // 4) grades da ponte: andando em cima do deck na diagonal, nunca passa de (meia largura - raio) para o lado
        {
            Player pl; float bx = Bridge::x(), bz = Bridge::z(), tx = Bridge::dx(), tz = Bridge::dz();
            pl.place(bx - tx * 6.0f, bz - tz * 6.0f, 0.0f);
            float yaw = std::atan2(tz, tx) + 0.5f;   // 29 graus para o lado
            float maxAc = 0.0f;
            for (int i = 0; i < 200; i++) {
                bool j = false;
                pl.drive(yaw, 0.0f, 1.0f, false, j, 1.0f / 60.0f, col);
                if (std::fabs(Bridge::along(pl.pos.x, pl.pos.z)) < Cfg::BRIDGE_HALF_LEN - 0.5f) maxAc = std::fmax(maxAc, std::fabs(Bridge::across(pl.pos.x, pl.pos.z)));
            }
            CHECK(maxAc <= Cfg::BRIDGE_HALF_W - Cfg::PLAYER_R + 1e-3f, "passou da grade da ponte (%.3f)", maxAc);
            std::printf("ponte: afastamento máximo do eixo %.3f m (grade em %.2f)\n", maxAc, Cfg::BRIDGE_HALF_W - Cfg::PLAYER_R);
        }

        // 5) pulo: sobe ~1,2 m e volta ao chão; e não pula no ar
        {
            Player pl; pl.place(RoadNet::startX(), RoadNet::startZ(), 0.0f);
            float y0 = pl.pos.y, top = y0; bool j = true; int air = 0;
            for (int i = 0; i < 120; i++) {
                pl.drive(0.0f, 0.0f, 0.0f, false, j, 1.0f / 60.0f, col);
                top = std::fmax(top, pl.pos.y); if (!pl.grounded) air++;
                if (i == 10) j = true;                      // 2º toque no ar: ignorado
            }
            // v0=6,5 e g=18: 1,17 m na fórmula contínua; integrando quadro a quadro (dt=1/60, Euler) sai ~1,12 m
            CHECK(std::fabs(top - y0 - 1.12f) < 0.02f, "altura do pulo %.3f (esperado ~1,12)", top - y0);
            CHECK(pl.grounded && std::fabs(pl.pos.y - y0) < 1e-3f, "não voltou ao chão");
            std::printf("pulo: altura %.3f m, %d quadros no ar\n", top - y0, air);
        }
        if (fails) { std::printf("%d FALHAS\n", fails); return 1; }
        std::printf("OK: colmeias, modelo, grades da ponte e pulo.\n");
        return 0;
    }

    // ---- simulação idêntica à do RefWorld.playerSim ----
    float bx = RoadNet::bridgeX(), bz = RoadNet::bridgeZ(), btx = RoadNet::bridgeTX(), btz = RoadNet::bridgeTZ();
    const float nbx = -btz, nbz = btx;   // normal da ponte (across positivo)
    const float sc[6][7] = {   // x, z, yaw, frames, biasForward, ruidoLateral, ruidoDoGiro
        {RoadNet::startX(), RoadNet::startZ(), km::atan2(-0.6f, 0.8f), 9000.0f, 0.5f, 1.0f, 1.0f},
        {bx - btx * 20.0f, bz - btz * 20.0f, km::atan2(btz, btx), 3500.0f, 0.95f, 0.1f, 0.1f},
        {bx + btx * 20.0f, bz + btz * 20.0f, km::atan2(-btz, -btx), 3500.0f, 0.95f, 0.1f, 0.1f},
        {RoadNet::shoreX() - RoadNet::dirX * 4.0f, RoadNet::shoreZ() - RoadNet::dirZ * 4.0f, km::atan2(RoadNet::dirZ, RoadNet::dirX), 3500.0f, 0.95f, 0.1f, 0.1f},
        {bx - btx * 8.0f, bz - btz * 8.0f, km::atan2(btz, btx) + 0.5f, 1500.0f, 1.0f, 0.0f, 0.0f},
        {bx + nbx * 4.0f - btx * 2.0f, bz + nbz * 4.0f - btz * 2.0f, km::atan2(-btx, btz), 1500.0f, 1.0f, 0.0f, 0.0f}};
    for (int s = 0; s < 6; s++) {
        JavaRandom r(77 + s);
        Player p; p.place(sc[s][0], sc[s][1], 0.0f);
        float yaw = sc[s][2]; int frames = (int)sc[s][3]; float bias = sc[s][4];
        float mx = 0.0f, my = 0.0f; bool run = false; bool jf = false;
        for (int f = 0; f < frames; f++) {
            if (r.nextFloat() < 0.02f) {
                mx = (r.nextFloat() * 2.0f - 1.0f) * 0.8f * sc[s][5];
                my = r.nextFloat() < bias ? 1.0f : (r.nextFloat() * 2.0f - 1.0f);
                run = r.nextFloat() < 0.4f;
                yaw += (r.nextFloat() - 0.5f) * 0.6f * sc[s][6];
            }
            if (r.nextFloat() < 0.01f) jf = true;
            float dt = (r.nextFloat() < 0.05f) ? 0.05f : 1.0f / 60.0f;
            p.drive(yaw, mx, my, run, jf, dt, col);
            // vy não é público: o Java imprime vy, aqui repetimos o campo pelo salto observável (ver Player::vy())
            std::printf("%.9g %.9g %.9g %.9g %.9g %d\n", p.pos.x, p.pos.y, p.pos.z, p.vy(), p.heading, p.grounded ? 1 : 0);
        }
    }
    return 0;
}
