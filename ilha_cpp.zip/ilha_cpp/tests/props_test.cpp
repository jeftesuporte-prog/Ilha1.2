// Etapa 3B: píer, ponte e barco. Confere finitude, normais, e posições contra contas independentes.
#include <cmath>
#include <cstdio>
#include <vector>
#include "Cfg.h"
#include "Props.h"
#include "World.h"

static int fails = 0;
#define CHECK(c, ...) do { if (!(c)) { fails++; printf("FALHA: "); printf(__VA_ARGS__); printf("\n"); } } while (0)

struct Box { float mn[3] = {1e9f, 1e9f, 1e9f}, mx[3] = {-1e9f, -1e9f, -1e9f}; };
static Box bounds(const std::vector<float>& v, size_t from = 0, size_t to = (size_t)-1) {
    Box b;
    size_t n = v.size() / 7; if (to > n) to = n;
    for (size_t i = from; i < to; i++) for (int c = 0; c < 3; c++) { b.mn[c] = std::fmin(b.mn[c], v[i * 7 + c]); b.mx[c] = std::fmax(b.mx[c], v[i * 7 + c]); }
    return b;
}
static void sane(const char* nm, const std::vector<float>& v, bool allowZero = false) {
    CHECK(!v.empty() && v.size() % 21 == 0, "%s: tamanho %zu", nm, v.size());
    size_t bad = 0;
    for (size_t i = 0; i + 6 < v.size(); i += 7) {
        for (int c = 0; c < 6; c++) if (!std::isfinite(v[i + c])) bad++;
        float l = std::sqrt(v[i + 3] * v[i + 3] + v[i + 4] * v[i + 4] + v[i + 5] * v[i + 5]);
        if (std::fabs(l - 1.0f) > 1e-3f && !(allowZero && l < 1e-6f)) bad++;
    }
    CHECK(bad == 0, "%s: %zu valores inválidos (NaN ou normal não unitária)", nm, bad);
}

int main() {
    // ---- píer ----
    auto pier = Props::pier();
    sane("pier", pier);
    // o primeiro tabuado: caixa centrada em (0, 0.9+dy, -8+0.25) no modelo, 3.2 x 0.14 x 0.42 => 36 vértices
    {
        Box b = bounds(pier, 0, 36);
        float dy = Pier::TOP - 0.97f;
        float cx = (b.mn[0] + b.mx[0]) / 2, cy = (b.mn[1] + b.mx[1]) / 2, cz = (b.mn[2] + b.mx[2]) / 2;
        // centro esperado no mundo: shore + lx*dirZ + lz*dirX
        float lz = -8.0f + 0.25f;
        float ex = RoadNet::shoreX() + lz * RoadNet::dirX, ez = RoadNet::shoreZ() + lz * RoadNet::dirZ;
        CHECK(std::fabs(cx - ex) < 0.01f && std::fabs(cz - ez) < 0.01f, "píer: centro (%.3f,%.3f) esperado (%.3f,%.3f)", cx, cz, ex, ez);
        CHECK(std::fabs(cy - (0.9f + dy)) < 1e-4f, "píer: altura do deck %.4f", cy);
        // topo do deck = 0.9+dy+0.07 = Pier::TOP + 0.00? (0.28-0.97+0.9+0.07 = 0.28)
        CHECK(std::fabs(b.mx[1] - Pier::TOP) < 1e-4f, "píer: topo do deck %.4f != %.4f", b.mx[1], Pier::TOP);
    }
    Box pb = bounds(pier);
    printf("pier: %zu vertices | x[%.1f..%.1f] y[%.2f..%.2f] z[%.1f..%.1f]\n", pier.size() / 7, pb.mn[0], pb.mx[0], pb.mn[1], pb.mx[1], pb.mn[2], pb.mx[2]);
    // pilares de 6 m: do fundo do mar até 0.53 m ACIMA do deck (igual ao original: viram os postes da beirada)
    CHECK(pb.mn[1] < -4.0f && pb.mx[1] < Pier::TOP + 0.6f, "píer: pilares/cunhos fora da faixa de altura");

    // ---- ponte ----
    auto br = Props::bridge();
    sane("bridge", br);
    {
        // todo vértice de face voltada para cima que está perto da altura do deck tem de acompanhar a rampa da estrada (deckAt)
        size_t n = 0; float maxDev = 0;
        for (size_t i = 0; i + 6 < br.size(); i += 7) {
            float x = br[i], y = br[i + 1], z = br[i + 2];
            if (br[i + 4] < 0.99f) continue;
            float d = Bridge::deckAt(x, z);
            if (std::fabs(y - d) > 0.2f) continue;               // corrimões e vigas ficam longe do deck
            n++; maxDev = std::fmax(maxDev, std::fabs(y - d));
        }
        printf("ponte: %zu vértices de tábua | desvio máx. do deckAt %.4f m | deckY %.3f | inclinação %.2f graus\n", n, maxDev, Bridge::deckY(), Bridge::pitchDeg());
        CHECK(n > 100, "ponte: poucas tábuas achadas (%zu)", n);
        CHECK(maxDev < 0.05f, "ponte: deck não acompanha a estrada (%.3f)", maxDev);
    }

    // ---- barco ----
    BoatModel::Pose p = BoatModel::mooredPose();
    std::vector<float> boat, boat2;
    BoatModel::build(p, 0.0f, boat);
    BoatModel::build(p, 1.7f, boat2);
    sane("boat", boat, true);   // o .obj do Kenney tem faces de área zero (normal zero), como no Kotlin
    size_t expect = (size_t)(236 + 28 + 28) * 3;
    CHECK(boat.size() / 7 == expect, "barco: %zu vértices, esperado %zu", boat.size() / 7, expect);
    Box hb = bounds(boat, 0, 236 * 3);
    float wx = BoatModel::worldX(BoatModel::SLOT_LX, BoatModel::SLOT_LZ), wz = BoatModel::worldZ(BoatModel::SLOT_LX, BoatModel::SLOT_LZ);
    float cx = (hb.mn[0] + hb.mx[0]) / 2, cz = (hb.mn[2] + hb.mx[2]) / 2;
    printf("barco: casco x[%.2f..%.2f] y[%.2f..%.2f] z[%.2f..%.2f] | slot (%.2f, %.2f)\n", hb.mn[0], hb.mx[0], hb.mn[1], hb.mx[1], hb.mn[2], hb.mx[2], wx, wz);
    CHECK(std::hypot(cx - wx, cz - wz) < 0.6f, "barco: longe do lugar no píer (%.2f)", std::hypot(cx - wx, cz - wz));
    // altura: a quilha fica abaixo da água (y=0.015), a borda acima: draft = 0.17*1.3 => quilha ~ 0.24*1.3 - 0.206
    CHECK(hb.mn[1] < Cfg::BARCO_ESCALA * 0.25f && hb.mx[1] > 0.4f && hb.mx[1] < 1.2f, "barco: altura estranha");
    // balança: em outro instante os vértices mudam, mas pouco (< 15 cm)
    float maxd = 0;
    for (size_t i = 0; i < boat.size(); i += 7) for (int c = 0; c < 3; c++) maxd = std::fmax(maxd, std::fabs(boat[i + c] - boat2[i + c]));
    CHECK(maxd > 1e-4f && maxd < 0.3f, "barco: balanço de %.4f m", maxd);
    // tamanho: 2.85 x 1.43 do modelo * 1.3 (os remos saem dos lados: olhar só o casco ao longo do eixo do píer)
    float len = 0;
    for (size_t i = 0; i < 236 * 3; i++) { float al = (boat[i * 7] - RoadNet::shoreX()) * RoadNet::dirX + (boat[i * 7 + 2] - RoadNet::shoreZ()) * RoadNet::dirZ; (void)al; }
    float amin = 1e9f, amax = -1e9f;
    for (size_t i = 0; i < 236 * 3; i++) { float al = (boat[i * 7] - wx) * RoadNet::dirX + (boat[i * 7 + 2] - wz) * RoadNet::dirZ; amin = std::fmin(amin, al); amax = std::fmax(amax, al); }
    len = amax - amin;
    printf("barco: comprimento %.2f m (esperado ~%.2f)\n", len, 2.85f * Cfg::BARCO_ESCALA);
    CHECK(std::fabs(len - 2.85f * Cfg::BARCO_ESCALA) < 0.15f, "barco: comprimento errado");

    if (fails) { printf("%d FALHAS\n", fails); return 1; }
    printf("OK: píer, ponte e barco consistentes.\n");
    return 0;
}
