#include <chrono>
#include <cmath>
#include <cstdio>
#include <thread>
#include "../src/ChunkManager.h"
#include "../src/Streaming.h"

static int fails = 0;
#define CHECK(c, msg) do { if (!(c)) { std::printf("FALHOU: %s\n", msg); fails++; } } while (0)

// roda `secs` segundos de jogo a `fps` quadros por segundo; devolve quantas mudanças de nível houve
static int run(QualityController& q, float secs, float fps) {
    int changes = 0;
    int frames = static_cast<int>(secs * fps);
    for (int i = 0; i < frames; i++) if (q.frame(1.0f / fps)) changes++;
    return changes;
}

static int expectedChunks(float px, float pz, float r, bool lessEqual = false) {
    int n = 0;
    for (int k = 0; k < 100; k++) { float d = ChunkManager::distTo(k, px, pz); if (lessEqual ? d <= r : d < r) n++; }
    return n;
}

static void settle(ChunkManager& cm, float px, float pz, float dx = 0, float dz = 0) {
    for (int i = 0; i < 600; i++) { cm.update(px, pz, dx, dz); std::this_thread::sleep_for(std::chrono::milliseconds(4)); }
}

int main() {
    // ---------- qualidade automática ----------
    {
        QualityController q(2);
        CHECK(run(q, 10, 60) == 0 && q.level() == 2, "60 fps por 10 s ainda não sobe (precisa de 12 s estáveis)");
        run(q, 10, 60);
        CHECK(q.level() == 3, "60 fps por 20 s sobe de MÉDIO para ALTO");
    }
    {
        QualityController q(2);
        int ch = run(q, 3.9f, 20);
        CHECK(ch == 0 && q.level() == 2, "menos de 4 s lento ainda não desce");
        ch += run(q, 3.0f, 20);
        CHECK(q.level() == 1, "20 fps por ~7 s deve descer para BAIXO");
        run(q, 20, 20);
        CHECK(q.level() == 0, "continuando lento deve chegar ao MÍNIMO");
        run(q, 60, 20);
        CHECK(q.level() == 0, "no MÍNIMO não desce mais");
    }
    {
        QualityController q(1);
        run(q, 11, 60); CHECK(q.level() == 1, "menos de 12 s bom ainda não sobe");
        run(q, 6, 60);  CHECK(q.level() == 2, "60 fps por ~17 s deve subir para MÉDIO");
        run(q, 30, 60); CHECK(q.level() == 3, "e depois para ALTO");
        run(q, 60, 60); CHECK(q.level() == 3, "ALTO é o teto");
    }
    {
        // sobe, cai logo depois => esse nível fica proibido por 3 minutos (sem ficar subindo e descendo)
        QualityController q(1);
        run(q, 17, 60);  CHECK(q.level() == 2, "subiu para 2");
        run(q, 8, 20);   CHECK(q.level() == 1, "caiu de volta para 1");
        run(q, 100, 60); CHECK(q.level() == 1, "dentro dos 3 minutos NÃO sobe de novo");
        run(q, 100, 60); CHECK(q.level() >= 2, "depois dos 3 minutos volta a tentar subir");
    }
    {
        QualityController q(2);
        bool ch = false;
        for (int i = 0; i < 400; i++) ch |= q.frame(1.0f);          // quadros de 1 s = pausa/engasgo: ignorados
        CHECK(!ch && q.level() == 2, "quadros gigantes (app em segundo plano) não contam");
    }

    // ---------- prioridade: o que está na frente carrega antes ----------
    {
        float ahead = Streaming::priority(200, 200, 0, 1, 0);     // 200 m na frente
        float side = Streaming::priority(200, 0, 200, 1, 0);
        float behind = Streaming::priority(200, -200, 0, 1, 0);
        CHECK(ahead < side && side < behind, "frente < lado < atrás");
        CHECK(Streaming::priority(300, 300, 0, 1, 0) < Streaming::priority(160, -160, 0, 1, 0), "um chunk a 300 m na frente ganha de um a 160 m atrás");
        CHECK(std::fabs(Streaming::priority(123, 5, 5, 0, 0) - 123) < 1e-4f, "sem direção = só distância");
    }

    // ---------- carregamento real por perfil ----------
    {
        ChunkManager cm;
        const float px = 0, pz = 0;
        cm.setProfile(Streaming::profile(0));
        settle(cm, px, pz, 1, 0);
        int want0 = expectedChunks(px, pz, Streaming::profile(0).terrainR);
        std::printf("MÍNIMO: terreno=%d (esperado %d), vegetação=%d\n", cm.terrainChunks(), want0, cm.decoChunks());
        CHECK(cm.terrainChunks() == want0, "MÍNIMO carrega exatamente os chunks dentro de 220 m");

        cm.setProfile(Streaming::profile(3));
        settle(cm, px, pz, 1, 0);
        int want3 = expectedChunks(px, pz, Streaming::profile(3).terrainR);
        std::printf("ALTO:   terreno=%d (esperado %d), vegetação=%d\n", cm.terrainChunks(), want3, cm.decoChunks());
        CHECK(cm.terrainChunks() == want3, "ALTO carrega os chunks dentro de 430 m");
        CHECK(want3 > want0 * 2, "ALTO tem bem mais chunks que o MÍNIMO");

        cm.setProfile(Streaming::profile(0));
        settle(cm, px, pz, 1, 0);
        int keep = expectedChunks(px, pz, Streaming::profile(0).terrainR + Streaming::profile(0).keepExtra, true);
        std::printf("volta ao MÍNIMO: terreno=%d (esperado %d com a folga de histerese)\n", cm.terrainChunks(), keep);
        CHECK(cm.terrainChunks() == keep, "ao baixar a qualidade os chunks distantes são descarregados (com histerese)");
    }
    std::printf(fails ? "%d falha(s)\n" : "Streaming e qualidade automática: tudo OK\n", fails);
    return fails != 0;
}
