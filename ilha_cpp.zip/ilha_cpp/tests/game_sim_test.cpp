// Etapa 6: integração SEM tela. Repete o caminho do frame() do main.cpp (toques -> Controls -> Player -> Câmera -> HUD) com o
// ChunkManager de verdade (árvores, pedras e colmeias reais do mapa). Confere que o boneco não atravessa tronco, sobe em pedra,
// que a câmera nunca entra no chão, e que o HUD cabe no buffer da GPU.
#include <chrono>
#include <cmath>
#include <cstdio>
#include <thread>
#include <vector>
#include "Camera.h"
#include "ChunkManager.h"
#include "Controls.h"
#include "Hud.h"
#include "Player.h"
#include "World.h"

static int fails = 0;
#define CHECK(c, ...) do { if (!(c)) { fails++; std::printf("FALHA: "); std::printf(__VA_ARGS__); std::printf("\n"); } } while (0)

struct Sim {
    ChunkManager& cm; Controls ctl; Player pl; CameraRig cam;
    std::vector<HudVertex> hud; size_t maxHud = 0; float minCamAbove = 1e9f; bool finite = true;
    explicit Sim(ChunkManager& c) : cm(c) { ctl.setScreen(1920, 1080); }
    void frame(float dt = 1.0f / 60.0f) {
        ctl.poll();
        cam.look(ctl.lookX, ctl.lookY); ctl.consumeLook();
        pl.drive(cam.yaw, ctl.moveX, ctl.moveY, ctl.run, ctl.jump, dt, cm);
        cam.update(pl.pos, cm);
        Hud::Info hi; hi.altitude = (int)pl.pos.y; hi.fps = 60; hi.quality = "ALTO"; hi.terrainR = 430; hi.decoR = 250;
        Hud::build(ctl, hi, hud); maxHud = std::max(maxHud, hud.size());
        float g = cm.rockFloor(cam.pos[0], cam.pos[2], World::groundAt(cam.pos[0], cam.pos[2]));
        minCamAbove = std::fmin(minCamAbove, cam.pos[1] - g);
        for (float v : {pl.pos.x, pl.pos.y, pl.pos.z, cam.pos[0], cam.pos[1], cam.pos[2]}) if (!std::isfinite(v)) finite = false;
    }
    // aponta a câmera para (x,z)
    void face(float x, float z) { cam.yaw = std::atan2(z - pl.pos.z, x - pl.pos.x); }
    // empurra o analógico todo para frente (corre)
    void joyForward() { ctl.touchDown(0, 300, 800); ctl.touchMove(0, 300, 800 - 400); }
    void joyRelease() { ctl.touchUp(0); }
};

int main() {
    ChunkManager cm;
    cm.warmup(RoadNet::startX(), RoadNet::startZ(), 150.0f);   // carrega terreno e vegetação em volta do começo
    std::printf("mundo carregado: terreno %d chunks, vegetacao %d chunks, %zu chunks com troncos\n", cm.terrainChunks(), cm.decoChunks(), cm.solids.size());
    CHECK(cm.decoChunks() > 0 && !cm.solids.empty(), "warmup não carregou vegetação");

    // 1) o boneco começa no chão, de frente para a ilha, e anda sem travar (tela cheia de toques girando e correndo)
    {
        Sim s(cm); s.pl.place(RoadNet::startX(), RoadNet::startZ(), Player::headingFromDir(0.8f, -0.6f));
        float y0 = s.pl.pos.y;
        CHECK(std::fabs(y0 - World::groundAt(RoadNet::startX(), RoadNet::startZ())) < 1e-4f, "boneco não começa no chão");
        s.joyForward();
        float x0 = s.pl.pos.x, z0 = s.pl.pos.z;
        for (int i = 0; i < 120; i++) s.frame();      // 2 s correndo
        float d = std::hypot(s.pl.pos.x - x0, s.pl.pos.z - z0);
        std::printf("corrida 2 s: %.1f m (8 m/s => até 16 m; troncos/pedras/morro podem reduzir)\n", d);
        CHECK(d > 4.0f && d < 16.5f, "distância percorrida %.2f", d);
        // arrastar o dedo direito gira a câmera
        float yawBefore = s.cam.yaw;
        s.ctl.touchDown(1, 1500, 500); s.ctl.touchMove(1, 1700, 500); s.frame();
        CHECK(s.cam.yaw > yawBefore + 0.6f, "arrastar 200 px deveria girar ~0,7 rad (girou %.3f)", s.cam.yaw - yawBefore);
        s.ctl.touchUp(1); s.joyRelease();
    }

    // 2) tronco: correr direto num tronco real não atravessa (raio do tronco + raio do boneco)
    {
        float bx = 0, bz = 0, br = 0, bd = 1e9f;
        for (auto& kv : cm.solids) for (size_t i = 0; i + 2 < kv.second.size(); i += 3) {
            float d = std::hypot(kv.second[i] - RoadNet::startX(), kv.second[i + 1] - RoadNet::startZ());
            if (d > 15.0f && d < bd) { bd = d; bx = kv.second[i]; bz = kv.second[i + 1]; br = kv.second[i + 2]; }
        }
        CHECK(bd < 200.0f, "nenhum tronco perto do começo");
        Sim s(cm);
        // começa 6 m antes do tronco, na linha que vem do começo
        float dx = (RoadNet::startX() - bx), dz = (RoadNet::startZ() - bz); float l = std::hypot(dx, dz); dx /= l; dz /= l;
        s.pl.place(bx + dx * 6.0f, bz + dz * 6.0f, 0.0f); s.face(bx, bz);
        s.joyForward();
        float minD = 1e9f;
        for (int i = 0; i < 240; i++) { s.frame(); minD = std::fmin(minD, std::hypot(s.pl.pos.x - bx, s.pl.pos.z - bz)); }
        std::printf("tronco em (%.1f, %.1f) raio %.2f: menor distância do boneco %.3f (mínimo %.3f)\n", bx, bz, br, minD, br + Cfg::PLAYER_R);
        CHECK(minD >= br + Cfg::PLAYER_R - 0.03f, "boneco atravessou o tronco (%.3f < %.3f)", minD, br + Cfg::PLAYER_R);
        CHECK(s.finite, "valores inválidos");
    }

    // 3) pedra: correr para o meio de uma pedra grande sobe nela (altura do topo = cy + ry*0.85*...)
    {
        float rx = 0, rz = 0, rcy = 0, rre = 0, rry = 0, bd = 1e9f;
        for (auto& kv : cm.rockMap) for (size_t i = 0; i + 4 < kv.second.size(); i += 5) {
            float d = std::hypot(kv.second[i] - RoadNet::startX(), kv.second[i + 1] - RoadNet::startZ());
            if (d > 15.0f && d < bd) { bd = d; rx = kv.second[i]; rz = kv.second[i + 1]; rcy = kv.second[i + 2]; rre = kv.second[i + 3]; rry = kv.second[i + 4]; }
        }
        CHECK(bd < 200.0f, "nenhuma pedra perto do começo");
        Sim s(cm);
        float ground = World::groundAt(rx, rz);
        float dx = (RoadNet::startX() - rx), dz = (RoadNet::startZ() - rz); float l = std::hypot(dx, dz); dx /= l; dz /= l;
        s.pl.place(rx + dx * (rre + 3.0f), rz + dz * (rre + 3.0f), 0.0f); s.face(rx, rz);
        s.joyForward();
        float maxY = -1e9f;
        for (int i = 0; i < 240; i++) { s.frame(); maxY = std::fmax(maxY, s.pl.pos.y); }
        float top = cm.rockFloor(rx, rz, ground);
        std::printf("pedra em (%.1f, %.1f): chão %.2f, topo %.2f, boneco chegou a %.2f\n", rx, rz, ground, top, maxY);
        CHECK(top > ground + 0.5f, "topo da pedra %.2f não passa do chão %.2f", top, ground);
        CHECK(maxY > ground + 0.5f * (top - ground), "boneco não subiu na pedra (%.2f)", maxY);
        CHECK(s.minCamAbove >= 0.6f - 1e-3f, "câmera entrou no chão/pedra (%.3f)", s.minCamAbove);
    }

    // 4) HUD cabe no buffer da GPU em qualquer estado (8192 vértices) e a câmera nunca entra no chão numa caminhada longa
    {
        Sim s(cm); s.pl.place(RoadNet::startX(), RoadNet::startZ(), 0.0f);
        s.ctl.showRow = true; s.ctl.act1Text = "DESAMARRAR"; s.ctl.act2Text = "SAIR";
        s.joyForward(); s.ctl.touchDown(1, 1500, 500);
        for (int i = 0; i < 1200; i++) {
            if (i % 60 == 0) s.ctl.touchMove(1, 1500 + (i % 120) * 4, 500 - (i % 180));   // olha para os lados
            if (i % 90 == 0) s.ctl.jump = true;
            s.frame();
        }
        std::printf("caminhada 20 s: HUD máx %zu vértices (limite 8192), câmera mín %.2f m acima do chão\n", s.maxHud, s.minCamAbove);
        CHECK(s.maxHud > 0 && s.maxHud <= 8192, "HUD com %zu vértices", s.maxHud);
        CHECK(s.minCamAbove >= 0.6f - 1e-3f, "câmera entrou no chão (%.3f)", s.minCamAbove);
        CHECK(s.finite, "valores inválidos na caminhada");
    }

    if (fails) { std::printf("%d FALHAS\n", fails); return 1; }
    std::printf("OK: integração boneco + câmera + HUD no mundo real.\n");
    return 0;
}
