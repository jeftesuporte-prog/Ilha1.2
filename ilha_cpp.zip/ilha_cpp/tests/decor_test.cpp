// Etapa 3B: sanidade do decor() (vegetação) nos 100 chunks do mapa.
// NÃO compara com o Kotlin (não há kotlinc aqui): verifica determinismo, thread-safety, floats válidos,
// limites, contagens plausíveis e a regra "mesma árvore em qualquer chunk" do pomar.
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <thread>
#include <vector>
#include "Apiario.h"
#include "ChunkBuilder.h"
#include "Cfg.h"
#include "ChunkMat.h"

static uint64_t fnv(uint64_t h, const void* d, size_t n) {
    const uint8_t* p = static_cast<const uint8_t*>(d);
    for (size_t i = 0; i < n; i++) { h ^= p[i]; h *= 1099511628211ULL; }
    return h;
}
static uint64_t hashBuilt(const Built& b) {
    uint64_t h = 1469598103934665603ULL;
    for (size_t i = 0; i < b.parts.size(); i++) {
        h = fnv(h, &b.mats[i], sizeof(int));
        h = fnv(h, b.parts[i].data(), b.parts[i].size() * 4);
    }
    for (const auto* v : {&b.solids, &b.rocks, &b.palms, &b.macas, &b.laranjas, &b.bananas}) {
        size_t n = v->size(); h = fnv(h, &n, sizeof n); h = fnv(h, v->data(), n * 4);
    }
    return h;
}
static int fails = 0;
#define CHECK(c, ...) do { if (!(c)) { fails++; printf("FALHA: "); printf(__VA_ARGS__); printf("\n"); } } while (0)

int main() {
    const int N = Cfg::CHUNKS;
    std::vector<uint64_t> h1(N * N), h2(N * N);
    std::vector<Built> all(N * N);

    // 1) thread-safety: 4 threads constroem tudo ao mesmo tempo (o Apiario nasce "lazy" no meio da corrida)
    {
        std::vector<std::thread> th;
        for (int t = 0; t < 4; t++) th.emplace_back([&, t] {
            for (int k = t; k < N * N; k += 4) all[k] = ChunkBuilder::decor(k % N, k / N);
        });
        for (auto& x : th) x.join();
        for (int k = 0; k < N * N; k++) h1[k] = hashBuilt(all[k]);
    }
    // 2) determinismo: de novo, em sequência, tem de dar exatamente o mesmo
    for (int k = 0; k < N * N; k++) {
        Built b = ChunkBuilder::decor(k % N, k / N);
        h2[k] = hashBuilt(b);
        CHECK(h1[k] == h2[k], "chunk %d: resultado muda entre execuções", k);
    }

    // 3) floats válidos, múltiplo de triângulo, mats e limites
    size_t perMat[ChunkMat::COUNT] = {0}; size_t totV = 0, totSolid = 0, totRock = 0, totPalm = 0, totMaca = 0, totLar = 0, totBan = 0, nanCount = 0;
    int emptyChunks = 0;
    for (int k = 0; k < N * N; k++) {
        const Built& b = all[k];
        CHECK(b.layer == 1 && b.key == k, "chunk %d: layer/key errados", k);
        CHECK(b.parts.size() == b.mats.size(), "chunk %d: parts != mats", k);
        if (b.parts.empty()) emptyChunks++;
        for (size_t i = 0; i < b.parts.size(); i++) {
            int m = b.mats[i];
            int stride = ChunkMat::strideOf(m);
            CHECK(m >= ChunkMat::DECO && m < ChunkMat::COUNT, "chunk %d: material %d inválido", k, m);
            CHECK(b.parts[i].size() % (3 * stride) == 0, "chunk %d parte %zu: tamanho %zu não é múltiplo de 3 vértices", k, i, b.parts[i].size());
            size_t nv = b.parts[i].size() / stride;
            CHECK(nv <= (size_t)MeshAccum::MAXV, "chunk %d: parte com %zu vértices", k, nv);
            totV += nv; perMat[m] += nv;
            for (size_t v = 0; v < nv; v++) {
                const float* f = &b.parts[i][v * stride];
                for (int c = 0; c < 6; c++) if (!std::isfinite(f[c])) nanCount++;
                if (m != ChunkMat::DECO || true) {
                    // posição dentro de uma folga razoável em torno do chunk (copas e galhos passam um pouco da borda)
                    float x0 = (k % N) * Cfg::CHUNK - Cfg::HALF, z0 = (k / N) * Cfg::CHUNK - Cfg::HALF;
                    bool ok = f[0] > x0 - 25 && f[0] < x0 + Cfg::CHUNK + 25 && f[2] > z0 - 25 && f[2] < z0 + Cfg::CHUNK + 25 && f[1] > -8 && f[1] < 240;
                    CHECK(ok, "chunk %d: vértice fora dos limites (%.1f %.1f %.1f)", k, f[0], f[1], f[2]);
                    if (!ok) break;
                }
                float nl = std::sqrt(f[3] * f[3] + f[4] * f[4] + f[5] * f[5]);
                if (nl < 0.99f || nl > 1.01f) nanCount++;   // normal tem de ser unitária
            }
        }
        CHECK(b.solids.size() % 3 == 0 && b.rocks.size() % 5 == 0, "chunk %d: solids/rocks com tamanho errado", k);
        CHECK(b.palms.size() % 12 == 0 && b.macas.size() % 12 == 0 && b.laranjas.size() % 12 == 0 && b.bananas.size() % 12 == 0, "chunk %d: frutas não múltiplo de 12", k);
        for (const auto* v : {&b.solids, &b.rocks, &b.palms, &b.macas, &b.laranjas, &b.bananas})
            for (float f : *v) if (!std::isfinite(f)) nanCount++;
        totSolid += b.solids.size() / 3; totRock += b.rocks.size() / 5; totPalm += b.palms.size() / 12;
        totMaca += b.macas.size() / 12; totLar += b.laranjas.size() / 12; totBan += b.bananas.size() / 12;
    }
    CHECK(nanCount == 0, "%zu valores inválidos (NaN/Inf ou normal não unitária)", nanCount);

    // 4) colisões dentro do mapa e fora de água funda
    for (int k = 0; k < N * N; k++) {
        const Built& b = all[k];
        float x0 = (k % N) * Cfg::CHUNK - Cfg::HALF, z0 = (k / N) * Cfg::CHUNK - Cfg::HALF;
        for (size_t i = 0; i + 2 < b.solids.size(); i += 3) {
            CHECK(b.solids[i] >= x0 && b.solids[i] < x0 + Cfg::CHUNK && b.solids[i + 1] >= z0 && b.solids[i + 1] < z0 + Cfg::CHUNK,
                  "chunk %d: tronco fora do próprio chunk", k);
            CHECK(b.solids[i + 2] > 0.3f && b.solids[i + 2] < 1.0f, "chunk %d: raio de colisão %.2f estranho", k, b.solids[i + 2]);
        }
    }

    // 5) colmeias
    const auto& hv = Apiario::hives();
    const auto& md = Apiario::meadows();
    int flowersTotal = 0; for (auto& m : md) flowersTotal += m.count;
    CHECK(!hv.empty(), "nenhuma colmeia criada");
    CHECK((int)hv.size() <= Cfg::COLMEIAS, "colmeias demais");
    for (auto& h : hv) CHECK(h.meadows.size() >= 1 && h.meadows.size() <= 3, "colmeia com %zu prados", h.meadows.size());
    for (auto& m : md) CHECK(m.count >= 40, "prado com poucas flores");

    printf("chunks: %d (vazios: %d)\n", N * N, emptyChunks);
    printf("vertices: %zu (~%zu triangulos)\n", totV, totV / 3);
    static const char* nm[ChunkMat::COUNT] = {"", "", "", "", "", "arvores/arbustos", "pedras", "coqueiros+mata c/ vento", "detalhe: flores/cogumelos", "detalhe: pedrinhas"};
    for (int m = ChunkMat::DECO; m < ChunkMat::COUNT; m++) printf("  %-28s %9zu vertices (%4.1f%%)\n", nm[m], perMat[m], 100.0 * perMat[m] / totV);
    printf("troncos com colisao: %zu | pedras andaveis: %zu | cocos: %zu | macas: %zu | laranjas: %zu | bananeiras: %zu\n",
           totSolid, totRock, totPalm, totMaca, totLar, totBan);
    printf("colmeias: %zu | prados: %zu | flores nos prados: %d\n", hv.size(), md.size(), flowersTotal);
    uint64_t all_h = 1469598103934665603ULL; for (auto h : h1) all_h = fnv(all_h, &h, 8);
    printf("hash geral do decor: %016llx\n", (unsigned long long)all_h);
    if (fails) { printf("%d FALHAS\n", fails); return 1; }
    printf("OK: decor() determinístico, thread-safe, sem NaN, dentro dos limites.\n");
    return 0;
}
