// Etapa 6: controles (analógico, correr, pular, olhar, botões do barco) e câmera em 3ª pessoa.
#include <cmath>
#include <cstdio>
#include "Camera.h"
#include "Controls.h"
#include "World.h"

static int fails = 0;
#define CHECK(c, ...) do { if (!(c)) { fails++; std::printf("FALHA: "); std::printf(__VA_ARGS__); std::printf("\n"); } } while (0)
static bool near(float a, float b, float e = 1e-4f) { return std::fabs(a - b) <= e; }

struct Flat : Colliders {   // sem pedras
    void pushOut(float[2], float) const override {}
    float rockFloor(float, float, float base) const override { return base; }
};

int main() {
    // tela 2000x1000: raio = max(70, 1000*0.12) = 120
    Controls c; c.setScreen(2000, 1000);
    CHECK(near(c.radius, 120.0f), "raio do analógico %.1f", c.radius);

    // analógico flutuante: ancora onde o dedo encosta (metade esquerda)
    c.touchDown(0, 300, 700); c.touchMove(0, 300, 700 - 60); c.poll();
    CHECK(near(c.moveX, 0) && near(c.moveY, 0.5f) && !c.run && c.joyActive(), "meio analógico para cima: %.2f %.2f", c.moveX, c.moveY);
    c.touchMove(0, 300 + 120, 700); c.poll();
    CHECK(near(c.moveX, 1.0f) && near(c.moveY, 0.0f), "analógico para a direita");
    c.touchMove(0, 300, 700 - 200); c.poll();   // passou do raio: trava em 1 e corre (mx²+my² = 1 > 0.85)
    CHECK(near(c.moveY, 1.0f) && c.run, "analógico no fim = correr");
    c.touchMove(0, 300 + 60, 700 - 60); c.poll();   // 0.5,0.5 => 0.5 < 0.85: anda
    CHECK(!c.run, "diagonal fraca não corre");
    c.touchUp(0); c.poll();
    CHECK(near(c.moveX, 0) && near(c.moveY, 0) && !c.run && !c.joyActive(), "soltar zera");

    // olhar: arrastar na metade direita acumula pixels; consumeLook zera
    c.touchDown(1, 1500, 500); c.touchMove(1, 1600, 450);
    CHECK(near(c.lookX, 100) && near(c.lookY, -50), "olhar %.1f %.1f", c.lookX, c.lookY);
    c.consumeLook(); CHECK(near(c.lookX, 0) && near(c.lookY, 0), "consumeLook");
    c.touchUp(1);

    // botão PULAR (canto inferior direito): toque dispara jump e NÃO começa a olhar
    float jx = c.jumpX(), jy = c.jumpY();
    CHECK(near(jx, 2000 - 120 * 1.7f) && near(jy, 1000 - 120 * 1.7f), "posição do PULAR");
    c.touchDown(2, jx, jy);
    CHECK(c.jump && c.jumpHeld(), "tocar no PULAR");
    c.touchMove(2, jx + 50, jy); CHECK(near(c.lookX, 0), "arrastar o dedo do PULAR não olha");
    c.touchUp(2); CHECK(!c.jumpHeld(), "soltar PULAR"); c.jump = false;
    // dentro do barco o PULAR some: o toque ali vira olhar
    c.inBoat = true; c.touchDown(3, jx, jy); CHECK(!c.jump, "PULAR some no barco"); c.touchMove(3, jx + 10, jy); CHECK(near(c.lookX, 10), "vira olhar no barco"); c.touchUp(3); c.consumeLook(); c.inBoat = false;

    // botões do barco
    c.showRow = true; c.act1Text = "DESAMARRAR"; c.act2Text = "SAIR";
    c.touchDown(4, c.act1X(), c.act1Y()); CHECK(c.act1 && c.act1Held(), "ação 1"); c.touchUp(4); c.act1 = false;
    c.touchDown(5, c.act2X(), c.act2Y()); CHECK(c.act2 && c.act2Held(), "ação 2"); c.touchUp(5); c.act2 = false;
    c.touchDown(6, c.goX(), c.goY()); CHECK(c.rowGoHeld(), "REMAR"); c.touchUp(6);
    c.touchDown(7, c.leftX(), c.leftY()); CHECK(c.rowLHeld(), "ESQ"); c.touchUp(7);
    c.touchDown(8, c.rightX(), c.leftY()); CHECK(c.rowRHeld(), "DIR"); c.touchUp(8);
    c.showRow = false; c.act1Text = c.act2Text = nullptr;

    // multitoque: andar e olhar ao mesmo tempo, cada dedo no seu papel
    c.touchDown(10, 200, 800); c.touchDown(11, 1400, 300);
    c.touchMove(10, 200, 740); c.touchMove(11, 1410, 300); c.poll();
    CHECK(near(c.moveY, 0.5f) && near(c.lookX, 10), "andar + olhar juntos");
    c.cancelAll(); c.poll(); CHECK(near(c.moveY, 0) && !c.joyActive(), "cancelAll");
    c.consumeLook();

    // ---- câmera ----
    CameraRig cam; Flat flat;
    Vec3 p{RoadNet::startX(), World::groundAt(RoadNet::startX(), RoadNet::startZ()), RoadNet::startZ()};
    cam.update(p, flat);
    float dl = std::sqrt(cam.dir[0]*cam.dir[0] + cam.dir[1]*cam.dir[1] + cam.dir[2]*cam.dir[2]);
    CHECK(near(dl, 1.0f, 1e-5f), "direção unitária");
    // fica a 5,5 m do alvo (a menos que o chão a empurre para cima), olhando para o boneco
    float ex = cam.pos[0] + cam.dir[0] * 5.5f, ez = cam.pos[2] + cam.dir[2] * 5.5f;
    CHECK(near(ex, p.x, 1e-3f) && near(ez, p.z, 1e-3f), "alvo no centro da mira");
    cam.look(100.0f, -50.0f);   // arrastar para a direita/cima: gira o yaw para +, pitch sobe
    CHECK(cam.yaw > km::atan2(-0.6f, 0.8f) && cam.pitch > 0.07f, "olhar direita/cima");
    cam.look(0.0f, 100000.0f); CHECK(near(cam.pitch, -0.9f), "pitch trava em -0,9"); // arrastar muito para baixo
    cam.look(0.0f, -1000000.0f); CHECK(near(cam.pitch, 1.2f), "pitch trava em 1,2");
    // câmera nunca fica abaixo do chão + 0,6 (olhando muito de baixo para cima, atrás do boneco)
    cam.pitch = -0.9f; cam.update(p, flat);
    float g = World::groundAt(cam.pos[0], cam.pos[2]);
    CHECK(cam.pos[1] >= g + 0.6f - 1e-4f, "câmera dentro do chão (%.2f < %.2f)", cam.pos[1], g + 0.6f);
    std::printf("camera: yaw inicial %.4f | altura min ok | ", km::atan2(-0.6f, 0.8f));
    if (fails) { std::printf("%d FALHAS\n", fails); return 1; }
    std::printf("Controles e câmera: tudo OK\n");
    return 0;
}
