import struct, sys
f32 = lambda s: struct.unpack('f', struct.pack('f', float(s)))[0]
def cmp_text(a_path, b_path, name, skip_first=False, skip_last_of_first=False):
    a = [l.split() for l in open(a_path)]; b = [l.split() for l in open(b_path)]
    assert len(a) == len(b), f"{name}: número de linhas diferente"
    mx = 0.0; n = 0
    for i, (ra, rb) in enumerate(zip(a, b)):
        if i == 0 and skip_last_of_first: ra, rb = ra[:-1], rb[:-1]
        for x, y in zip(ra, rb): n += 1; mx = max(mx, abs(f32(x) - f32(y)))
    ok = mx == 0.0
    print(("OK   " if ok else "FALHOU"), f"{name}: {n} valores, diferença máxima {mx}")
    return ok
ok = True
ok &= cmp_text('/tmp/ilha_t/noise_cpp.txt', '/tmp/ilha_t/noise_java.txt', 'SimplexNoise')
ok &= cmp_text('/tmp/ilha_t/world_cpp.txt', '/tmp/ilha_t/world_java.txt', 'World (altura, rio, bioma, ponte, píer)', skip_last_of_first=True)
ok &= cmp_text('/tmp/ilha_t/wind_cpp.txt', '/tmp/ilha_t/wind_java.txt', 'Wind')
ok &= cmp_text('/tmp/ilha_t/coll_cpp.txt', '/tmp/ilha_t/coll_java.txt', 'ChunkManager.pushOut/rockFloor')
ok &= cmp_text('/tmp/ilha_t/player_cpp.txt', '/tmp/ilha_t/player_java.txt', 'Player (6 trajetos: campo, ponte nos 2 sentidos, píer, grade da ponte; 22.500 quadros)')
ok &= cmp_text('/tmp/ilha_t/sky_cpp.txt', '/tmp/ilha_t/sky_java.txt', 'Sky (dia/noite, cores, nuvens, estrelas, meteoros)')
sys.exit(0 if ok else 1)
