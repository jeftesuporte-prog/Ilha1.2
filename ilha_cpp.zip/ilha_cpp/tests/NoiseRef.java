import com.ilha.world.SimplexNoise;
public class NoiseRef {
    public static void main(String[] a) {
        SimplexNoise n = new SimplexNoise(1337L);
        for (int k = 0; k < 2000; k++) {
            double x = (k * 7.31) - 3000.0 + (k % 13) * 0.137;
            double y = (k * -3.77) + 1500.0 + (k % 7) * 0.291;
            System.out.println(String.format(java.util.Locale.ROOT, "%.9g", n.noise(x * 0.01, y * 0.01)));
        }
    }
}
