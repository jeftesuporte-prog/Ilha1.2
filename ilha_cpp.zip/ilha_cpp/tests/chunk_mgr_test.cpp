#include <chrono>
#include <cstdio>
#include <thread>
#include "../src/ChunkManager.h"
int main() {
    ChunkManager cm;
    int up = 0, down = 0; size_t verts = 0;
    cm.onUpload = [&](const Built& b) { up++; if (b.layer == 0) for (auto& p : b.parts) verts += p.size() / 9; };
    cm.onUnload = [&](int, int) { down++; };
    auto t0 = std::chrono::steady_clock::now();
    cm.warmup(0.0f, 0.0f, 120.0f);
    auto t1 = std::chrono::steady_clock::now();
    std::printf("warmup: %d chunks em %.0f ms (terreno: %d, deco: %d)\n", up, std::chrono::duration<double, std::milli>(t1 - t0).count(), cm.terrainChunks(), cm.decoChunks());
    // anda do centro até a praia: carrega e descarta chunks nas threads de fundo
    for (int step = 0; step < 600; step++) {
        float x = -step * 0.8f, z = step * 0.6f;
        cm.update(x, z);
        std::this_thread::sleep_for(std::chrono::milliseconds(5));
    }
    std::printf("após caminhada: uploads=%d unloads=%d, terreno carregado=%d, vértices de terreno enviados=%zu\n", up, down, cm.terrainChunks(), verts);
    float p[2] = {0, 0}; cm.pushOut(p, 0.35f);
    return 0;
}
