import java.util.*;
import java.io.*;

public class RefWorld {
    static final float A=430f,B=380f,BEACH=40f,MAIN_H=210f,MAIN_R=150f,ROAD_W=7.5f,RIVER_HALF=5f,RIVER_BANK=7f,RIVER_BED=-1.3f;
    static final float BRIDGE_HALF_LEN=13f,BRIDGE_HALF_W=1.7f,GROVE_X=50f,GROVE_Z=230f,GROVE_R=75f,ORCHARD_X=240f,ORCHARD_Z=-170f,ORCHARD_R=70f;
    static float smooth(float e0,float e1,float x){ float t=(x-e0)/(e1-e0); t=t<0f?0f:(t>1f?1f:t); return t*t*(3f-2f*t); }
    static float sin(float x){return (float)Math.sin(x);} static float cos(float x){return (float)Math.cos(x);}
    static float sqrt(float x){return (float)Math.sqrt(x);} static float atan2(float y,float x){return (float)Math.atan2(y,x);}
    static float hypot(float a,float b){return (float)Math.hypot(a,b);} static float pow(float a,float b){return (float)Math.pow(a,b);}
    static float abs(float x){return Math.abs(x);} static float max(float a,float b){return Math.max(a,b);} static float min(float a,float b){return Math.min(a,b);}
    static float coerce(float v,float lo,float hi){ return v<lo?lo:(v>hi?hi:v); }

    static class Base {
        static final SimplexNoise noise = new SimplexNoise(1337L);
        static final float[][] peaks = {{0f,0f,MAIN_H,MAIN_R},{-250f,-150f,85f,75f},{280f,140f,90f,75f},{-30f,-250f,75f,65f}};
        static float n(float x,float z){ return noise.noise((double)x,(double)z); }
        static float shape(float x,float z){
            float w = n(x*0.0035f, z*0.0035f)*0.075f + n(x*0.011f+40f, z*0.011f)*0.025f;
            float nx=x/A, nz=z/B; return sqrt(nx*nx+nz*nz)*(1f+w);
        }
        static float depth(float x,float z){
            float s=shape(x,z); float gx=x/(A*A), gz=z/(B*B), nx=x/A, nz=z/B;
            float r0=sqrt(nx*nx+nz*nz);
            float m = r0>1e-3f ? sqrt(gx*gx+gz*gz)/r0 : 1f/B;
            return (1f-s)/max(m,1e-4f);
        }
        static float orchard(float x,float z){ float dx=x-ORCHARD_X, dz=z-ORCHARD_Z; return 1f-smooth(ORCHARD_R*0.7f,ORCHARD_R,sqrt(dx*dx+dz*dz)); }
        static float grove(float x,float z){ float dx=x-GROVE_X, dz=z-GROVE_Z; return 1f-smooth(GROVE_R*0.7f,GROVE_R,sqrt(dx*dx+dz*dz)); }
        static float forestW(float x,float z,float d,float h){
            if(d<=0f) return 0f;
            float inland=smooth(BEACH+6f,BEACH+30f,d);
            float alt=1f-smooth(35f,60f,h);
            float clump=smooth(-0.5f,0f,n(x*0.010f+11f,z*0.010f-4f));
            return inland*alt*clump*(1f-max(grove(x,z),orchard(x,z)));
        }
        static float baseHeight(float x,float z){
            float d=depth(x,z);
            if(d<=0f) return max(-14f,d*0.12f);
            float beach=d*0.03f;
            float land=max(1f, 2.5f+2.5f*n(x*0.012f,z*0.012f)+1.2f*n(x*0.04f,z*0.04f));
            float w=smooth(BEACH-10f,BEACH+20f,d);
            float h=beach+(land-beach)*w;
            float m=0f;
            for(float[] p: peaks){
                float dx=x-p[0], dz=z-p[1];
                float warp=1f+0.16f*n(x*0.008f+p[0], z*0.008f+p[1]);
                float rr=sqrt(dx*dx+dz*dz)*warp;
                float t=coerce(1f-rr/p[3],0f,1f);
                if(t>0f){
                    float prof=pow(t,1.35f);
                    float crag=1f-abs(n(x*0.03f+p[0], z*0.03f+p[1]));
                    float hm=p[2]*0.95f*prof+crag*p[2]*0.05f*sqrt(prof);
                    if(hm>m) m=hm;
                }
            }
            h+=m; return h;
        }
    }

    static class RoadNet {
        static final float dirX=-0.8f, dirZ=0.6f;
        static final float shoreX, shoreZ, startX, startZ, bridgeX, bridgeZ, bridgeTX, bridgeTZ;
        static final float[] xs, zs, hs;
        static final HashMap<Integer,int[]> grid = new HashMap<>();
        static int key(int i,int j){ return (i+200)*1000+(j+200); }
        static float cr(float a,float b,float c,float d,float t){
            float t2=t*t, t3=t2*t;
            return 0.5f*((2f*b)+(-a+c)*t+(2f*a-5f*b+4f*c-d)*t2+(-a+3f*b-3f*c+d)*t3);
        }
        static {
            float t=0f;
            while(t<800f && Base.depth(dirX*t,dirZ*t)>0f) t+=1f;
            shoreX=dirX*t; shoreZ=dirZ*t; startX=shoreX-dirX*12f; startZ=shoreZ-dirZ*12f;
            ArrayList<float[]> ctrl=new ArrayList<>();
            ctrl.add(new float[]{startX,startZ});
            float th0=atan2(dirZ,dirX); float r0=148f;
            float ex=r0*cos(th0), ez=r0*sin(th0);
            float fx=ex-startX, fz=ez-startZ; float fl=sqrt(fx*fx+fz*fz);
            float px=-fz/fl, pz=fx/fl; int nf=12;
            for(int i=1;i<nf;i++){
                float u=i/(float)nf;
                float off=45f*sin(u*6.9f)*sin(u*3.14159f);
                ctrl.add(new float[]{startX+fx*u+px*off, startZ+fz*u+pz*off});
            }
            int steps=72; float turns=2.6f;
            for(int i=0;i<=steps;i++){
                float u=i/(float)steps;
                float ang=th0+u*turns*6.2831855f;
                float r=148f+(14f-148f)*u+5f*sin(u*17f);
                ctrl.add(new float[]{r*cos(ang), r*sin(ang)});
            }
            ArrayList<Float> sx=new ArrayList<>(), sz=new ArrayList<>(); int forestEnd=0;
            for(int i=0;i<ctrl.size()-1;i++){
                float[] p0=ctrl.get(Math.max(i-1,0)), p1=ctrl.get(i), p2=ctrl.get(i+1), p3=ctrl.get(Math.min(i+2,ctrl.size()-1));
                float len=hypot(p2[0]-p1[0],p2[1]-p1[1]);
                int st=Math.max(2,(int)(len/2.5f));
                for(int s=0;s<st;s++){
                    float tt=s/(float)st;
                    sx.add(cr(p0[0],p1[0],p2[0],p3[0],tt));
                    sz.add(cr(p0[1],p1[1],p2[1],p3[1],tt));
                }
                if(i==nf-1) forestEnd=sx.size();
            }
            float[] last=ctrl.get(ctrl.size()-1); sx.add(last[0]); sz.add(last[1]);
            int n=sx.size();
            float[] lx=new float[n], lz=new float[n], h=new float[n];
            for(int i=0;i<n;i++){ lx[i]=sx.get(i); lz[i]=sz.get(i); }
            for(int i=0;i<n;i++) h[i]=Base.baseHeight(lx[i],lz[i]);
            for(int rep=0;rep<4;rep++){
                float[] tmp=h.clone();
                for(int i=0;i<n;i++){
                    float s=0f; int c=0;
                    for(int k=-5;k<=5;k++){ int j=i+k; if(j>=0&&j<n){ s+=tmp[j]; c++; } }
                    h[i]=s/c;
                }
            }
            xs=lx; zs=lz; hs=h;
            int bi=Math.min(Math.max(forestEnd/2,4),n-5);
            bridgeX=lx[bi]; bridgeZ=lz[bi];
            float btx=lx[bi+3]-lx[bi-3], btz=lz[bi+3]-lz[bi-3]; float bl=sqrt(btx*btx+btz*btz);
            bridgeTX=btx/bl; bridgeTZ=btz/bl;
            HashMap<Integer,ArrayList<Integer>> tg=new HashMap<>();
            for(int i=0;i<n;i++){
                int k=key((int)Math.floor(lx[i]/16f),(int)Math.floor(lz[i]/16f));
                tg.computeIfAbsent(k,q->new ArrayList<>()).add(i);
            }
            for(Map.Entry<Integer,ArrayList<Integer>> e: tg.entrySet()){
                int[] a=new int[e.getValue().size()]; for(int i=0;i<a.length;i++) a[i]=e.getValue().get(i); grid.put(e.getKey(),a);
            }
        }
        static void query(float x,float z,float[] out){
            float best=1e9f, bh=0f;
            int ci=(int)Math.floor(x/16f), cj=(int)Math.floor(z/16f);
            for(int i=ci-1;i<=ci+1;i++) for(int j=cj-1;j<=cj+1;j++){
                int[] arr=grid.get(key(i,j)); if(arr==null) continue;
                for(int idx: arr){
                    float ax=xs[idx], az=zs[idx];
                    if(idx>=xs.length-1){ float d=hypot(x-ax,z-az); if(d<best){best=d;bh=hs[idx];} continue; }
                    float bx=xs[idx+1], bz=zs[idx+1]; float vx=bx-ax, vz=bz-az; float l2=vx*vx+vz*vz;
                    float u=l2>1e-6f?((x-ax)*vx+(z-az)*vz)/l2:0f; u=coerce(u,0f,1f);
                    float d=hypot(x-(ax+vx*u), z-(az+vz*u));
                    if(d<best){ best=d; bh=hs[idx]+(hs[idx+1]-hs[idx])*u; }
                }
            }
            out[0]=best; out[1]=bh;
        }
    }

    static class River {
        static final float AMP=16f, K=0.03f;
        static float dist(float x,float z){
            float tx=RoadNet.bridgeTX, tz=RoadNet.bridgeTZ;
            float rx=x-RoadNet.bridgeX, rz=z-RoadNet.bridgeZ;
            float s=-rx*tz+rz*tx, t=rx*tx+rz*tz;
            float off=AMP*(1f-cos(K*s)); float slope=AMP*K*sin(K*s);
            return abs(t-off)/sqrt(1f+slope*slope);
        }
        static float w2d(float x,float z){ return 1f-smooth(RIVER_HALF,RIVER_HALF+RIVER_BANK,dist(x,z)); }
    }

    static class Bridge {
        static final float x=RoadNet.bridgeX, z=RoadNet.bridgeZ, dx=RoadNet.bridgeTX, dz=RoadNet.bridgeTZ;
        static final float hA, hB, deckY, pitchDeg;
        static {
            float[] q=new float[2]; float hl=BRIDGE_HALF_LEN;
            RoadNet.query(x-dx*hl,z-dz*hl,q); hA=q[1];
            RoadNet.query(x+dx*hl,z+dz*hl,q); hB=q[1];
            deckY=(hA+hB)/2f+0.03f; pitchDeg=atan2(hB-hA,2f*hl)*57.29578f;
        }
        static float along(float px,float pz){ return (px-x)*dx+(pz-z)*dz; }
        static float across(float px,float pz){ return -(px-x)*dz+(pz-z)*dx; }
        static float deckAt(float px,float pz){ float hl=BRIDGE_HALF_LEN; float u=coerce((along(px,pz)+hl)/(2f*hl),0f,1f); return hA+(hB-hA)*u+0.03f; }
        static boolean onDeck(float px,float pz){ return abs(along(px,pz))<=BRIDGE_HALF_LEN && abs(across(px,pz))<=BRIDGE_HALF_W; }
    }

    static class Pier {
        static final float TOP=0.28f, HALF_W=1.6f;
        static float along(float x,float z){ return (x-RoadNet.shoreX)*RoadNet.dirX+(z-RoadNet.shoreZ)*RoadNet.dirZ; }
        static float across(float x,float z){ return -(x-RoadNet.shoreX)*RoadNet.dirZ+(z-RoadNet.shoreZ)*RoadNet.dirX; }
        static boolean onDeck(float x,float z){ float a=along(x,z); return a>=-8f&&a<=30f&&abs(across(x,z))<=HALF_W; }
    }

    static float heightAt(float x,float z){
        float b=Base.baseHeight(x,z); float[] q=new float[2]; RoadNet.query(x,z,q);
        float rd=q[0]; float outer=ROAD_W*1.6f; float h=b;
        if(rd<outer){ float w=1f-smooth(ROAD_W*0.5f,outer,rd); h=b+(q[1]-b)*w; }
        float rw=River.w2d(x,z);
        if(rw>0f){ float d=Base.depth(x,z); if(d>0f){ float wf=rw*(1f-smooth(8f,16f,b)); float bed=RIVER_BED*smooth(0f,6f,d); if(bed<h) h+=(bed-h)*wf; } }
        return h;
    }
    static float groundAt(float x,float z){ if(Bridge.onDeck(x,z)) return Bridge.deckAt(x,z); if(Pier.onDeck(x,z)) return Pier.TOP; return heightAt(x,z); }

    static void sample(float x,float z,float h,float ny,float[] o,int k){
        float d=Base.depth(x,z); o[k+9]=d;
        if(d<=0f){ float df=smooth(0f,16f,-d); o[k]=0.95f-0.50f*df; o[k+1]=0.97f-0.28f*df; o[k+2]=1f-0.10f*df; for(int i=3;i<=8;i++) o[k+i]=0f; o[k+5]=1f; return; }
        float rv=River.w2d(x,z)*(1f-smooth(8f,16f,h));
        float steep=1f-smooth(0.62f,0.86f,ny); float high=smooth(40f,95f,h);
        float rock=max(steep,high)*(1f-smooth(0f,0.25f,rv));
        float mossTop=smooth(150f,190f,h)*(0.55f+0.45f*smooth(0.4f,0.8f,ny));
        float mossPatch=smooth(0.2f,0.5f,Base.n(x*0.045f-31f,z*0.045f+5f))*smooth(30f,90f,h)*0.9f;
        float moss=max(mossTop,mossPatch);
        float sandW=max(1f-smooth(BEACH-4f,BEACH+6f,d), smooth(0f,0.15f,rv));
        float fw=Base.forestW(x,z,d,h);
        float[] q=new float[2]; RoadNet.query(x,z,q);
        float half=ROAD_W*0.5f;
        float road=(1f-smooth(half-0.3f,half+0.8f,q[0]))*(1f-smooth(0.1f,0.4f,rv));
        float roadOnLand=road*(1f-smooth(0.25f,0.6f,sandW));
        float wetK=max(1f-smooth(0f,7f,d), smooth(0f,0.2f,rv))*0.9f;
        float sn=0.97f+0.03f*Base.n(x*0.1f,z*0.1f);
        float sandR=(1f-0.30f*wetK)*sn, sandG=(1f-0.36f*wetK)*sn, sandB=(1f-0.46f*wetK)*sn;
        float grassT=(0.84f+0.16f*(0.5f+0.5f*Base.n(x*0.035f+5f,z*0.035f)))*(1f-0.12f*fw);
        float forestT=0.74f+0.26f*(0.5f+0.5f*Base.n(x*0.05f+9f,z*0.05f));
        float rockT=0.66f+0.34f*smooth(5f,190f,h)+0.05f*Base.n(x*0.08f+13f,z*0.08f);
        float w1=1f-rock, wS=w1*sandW, wRest=w1*(1f-sandW), wF=wRest*fw, wG=wRest-wF;
        float r=rock*rockT+wS*sandR+wF*forestT+wG*grassT;
        float g=rock*rockT+wS*sandG+wF*forestT+wG*grassT;
        float bb=rock*rockT+wS*sandB+wF*forestT+wG*grassT;
        r+=(1f-r)*roadOnLand*0.95f; g+=(1f-g)*roadOnLand*0.95f; bb+=(1f-bb)*roadOnLand*0.95f;
        o[k]=min(1f,r); o[k+1]=min(1f,g); o[k+2]=min(1f,bb); o[k+3]=rock; o[k+4]=moss; o[k+5]=wS; o[k+6]=fw; o[k+7]=roadOnLand; o[k+8]=rv;
    }


    // ======================= etapa 3A: MeshAccum + terrain + ChunkManager (referência) =======================
    static final int SN=10;
    static float toFloatBits(float r,float g,float b,float a){
        int c=((int)(255*a)<<24)|((int)(255*b)<<16)|((int)(255*g)<<8)|((int)(255*r));
        return Float.intBitsToFloat(c & 0xfeffffff);
    }
    static class MeshAccum {
        static final int MAXV=30000, STRIDE=9;
        ArrayList<float[]> parts=new ArrayList<>(); float[] buf=new float[MAXV*STRIDE]; int nv=0;
        void triVC(float ax,float ay,float az,float ca,float ua,float va, float bx,float by,float bz,float cb,float ub,float vb,
                   float cx,float cy,float cz,float cc,float uc,float vc, float nx,float ny,float nz){
            if(nv+3>MAXV) flush();
            put(ax,ay,az,nx,ny,nz,ca,ua,va); put(bx,by,bz,nx,ny,nz,cb,ub,vb); put(cx,cy,cz,nx,ny,nz,cc,uc,vc);
        }
        void put(float x,float y,float z,float nx,float ny,float nz,float c,float u,float v){
            int i=nv*STRIDE; buf[i++]=x; buf[i++]=y; buf[i++]=z; buf[i++]=nx; buf[i++]=ny; buf[i++]=nz; buf[i++]=c; buf[i++]=u; buf[i]=v; nv++;
        }
        void flush(){ if(nv>0){ parts.add(Arrays.copyOf(buf,nv*STRIDE)); nv=0; } }
        List<float[]> finish(){ flush(); return parts; }
    }
    static class Terrain {
        float x0,z0,inv; MeshAccum[] accs=new MeshAccum[5];
        static int matOf(float[] a,int o){
            if(a[o+9]<=0f) return 0;
            if(a[o+7]>0.5f) return 4;
            if(a[o+3]>0.5f) return a[o+4]>0.4f?3:2;
            if(a[o+5]>0.5f) return 0;
            if(a[o+6]>0.5f) return 4;
            return 1;
        }
        void put(float ax,float ay,float az,float[] ai,int ao, float bx,float by,float bz,float[] bi,int bo,
                 float cx2,float cy,float cz2,float[] ci,int co,int depth){
            float ux=bx-ax,uy=by-ay,uz=bz-az, vx=cx2-ax,vy=cy-ay,vz=cz2-az;
            float nx=uy*vz-uz*vy, ny=uz*vx-ux*vz, nz=ux*vy-uy*vx;
            float l=sqrt(nx*nx+ny*ny+nz*nz);
            if(l<1e-9f) return;
            float r0=ai[ao+7], r1=bi[bo+7], r2=ci[co+7];
            int m0=matOf(ai,ao), m1=matOf(bi,bo), m2=matOf(ci,co);
            boolean finoSand = m0==0||m1==0||m2==0;
            if(depth>0 && (m0!=m1||m1!=m2) && (depth>1 || finoSand || max(r0,max(r1,r2))>=0.5f)){
                float nyN=abs(ny/l);
                float mxab=(ax+bx)*0.5f, mzab=(az+bz)*0.5f, myab=(ay+by)*0.5f;
                float mxbc=(bx+cx2)*0.5f, mzbc=(bz+cz2)*0.5f, mybc=(by+cy)*0.5f;
                float mxca=(cx2+ax)*0.5f, mzca=(cz2+az)*0.5f, myca=(cy+ay)*0.5f;
                float[] iab=new float[SN]; sample(mxab,mzab,myab,nyN,iab,0);
                float[] ibc=new float[SN]; sample(mxbc,mzbc,mybc,nyN,ibc,0);
                float[] ica=new float[SN]; sample(mxca,mzca,myca,nyN,ica,0);
                int d1=depth-1;
                put(ax,ay,az,ai,ao, mxab,myab,mzab,iab,0, mxca,myca,mzca,ica,0, d1);
                put(mxab,myab,mzab,iab,0, bx,by,bz,bi,bo, mxbc,mybc,mzbc,ibc,0, d1);
                put(mxca,myca,mzca,ica,0, mxbc,mybc,mzbc,ibc,0, cx2,cy,cz2,ci,co, d1);
                put(mxab,myab,mzab,iab,0, mxbc,mybc,mzbc,ibc,0, mxca,myca,mzca,ica,0, d1);
                return;
            }
            float d=min(ai[ao+9],min(bi[bo+9],ci[co+9]));
            float rock=(ai[ao+3]+bi[bo+3]+ci[co+3])/3f, moss=(ai[ao+4]+bi[bo+4]+ci[co+4])/3f;
            float sand=(ai[ao+5]+bi[bo+5]+ci[co+5])/3f, fw=(ai[ao+6]+bi[bo+6]+ci[co+6])/3f, road=(r0+r1+r2)/3f;
            int mat;
            if(d<=0f) mat=0; else if(road>0.5f) mat=4; else if(rock>0.5f) mat=(moss>0.4f?3:2); else if(sand>0.5f) mat=0; else if(fw>0.5f) mat=4; else mat=1;
            accs[mat].triVC(ax,ay,az,toFloatBits(ai[ao],ai[ao+1],ai[ao+2],1f),(ax-x0)*inv,(az-z0)*inv,
                bx,by,bz,toFloatBits(bi[bo],bi[bo+1],bi[bo+2],1f),(bx-x0)*inv,(bz-z0)*inv,
                cx2,cy,cz2,toFloatBits(ci[co],ci[co+1],ci[co+2],1f),(cx2-x0)*inv,(cz2-z0)*inv, nx/l,ny/l,nz/l);
        }
    }
    static float[][] terrainParts; static int[] terrainMats; static float tMinY,tMaxY;
    static void terrain(int cx,int cz){
        int n=40; float s=100f/40; float CH=100f, HALF=500f;
        float x0=cx*CH-HALF, z0=cz*CH-HALF; int w=n+1, m=n+3;
        float[] big=new float[m*m];
        for(int j=-1;j<=n+1;j++) for(int i=-1;i<=n+1;i++) big[(j+1)*m+(i+1)]=heightAt(x0+i*s,z0+j*s);
        float[] hs=new float[w*w]; float[] inf=new float[w*w*SN]; float minY=1e9f,maxY=-1e9f;
        for(int j=0;j<=n;j++) for(int i=0;i<=n;i++){
            float h=big[(j+1)*m+(i+1)]; hs[j*w+i]=h; if(h<minY) minY=h; if(h>maxY) maxY=h;
            float gx=(big[(j+1)*m+(i+2)]-big[(j+1)*m+i])/(2f*s);
            float gz=(big[(j+2)*m+(i+1)]-big[j*m+(i+1)])/(2f*s);
            float ny=1f/sqrt(1f+gx*gx+gz*gz);
            sample(x0+i*s,z0+j*s,h,ny,inf,(j*w+i)*SN);
        }
        Terrain t=new Terrain(); t.x0=x0; t.z0=z0; t.inv=1f/6.25f; for(int k=0;k<5;k++) t.accs[k]=new MeshAccum();
        for(int j=0;j<n;j++) for(int i=0;i<n;i++){
            int i00=j*w+i, i10=i00+1, i01=i00+w, i11=i01+1;
            int[][] tr = ((i+j)%2==0) ? new int[][]{{i00,i01,i11},{i00,i11,i10}} : new int[][]{{i00,i01,i10},{i10,i01,i11}};
            for(int[] e: tr){ int a=e[0],b=e[1],c=e[2];
                t.put(x0+(a%w)*s,hs[a],z0+(a/w)*s,inf,a*SN, x0+(b%w)*s,hs[b],z0+(b/w)*s,inf,b*SN, x0+(c%w)*s,hs[c],z0+(c/w)*s,inf,c*SN, 3); }
        }
        ArrayList<float[]> parts=new ArrayList<>(); ArrayList<Integer> mats=new ArrayList<>();
        for(int k=0;k<5;k++) for(float[] p: t.accs[k].finish()){ parts.add(p); mats.add(k); }
        terrainParts=parts.toArray(new float[0][]); terrainMats=new int[mats.size()]; for(int i=0;i<mats.size();i++) terrainMats[i]=mats.get(i);
        tMinY=minY; tMaxY=maxY;
    }
    static void writeTerrain(String path,int[][] chunks) throws Exception {
        java.nio.ByteBuffer hdr;
        try(DataOutputStream o=new DataOutputStream(new BufferedOutputStream(new FileOutputStream(path)))){
            for(int[] c: chunks){
                terrain(c[0],c[1]);
                o.write(le(terrainParts.length)); o.write(le(Float.floatToRawIntBits(tMinY))); o.write(le(Float.floatToRawIntBits(tMaxY)));
                for(int p=0;p<terrainParts.length;p++){
                    o.write(le(terrainMats[p])); o.write(le(terrainParts[p].length));
                    for(float f: terrainParts[p]) o.write(le(Float.floatToRawIntBits(f)));
                }
            }
        }
    }
    static byte[] le(int v){ return new byte[]{(byte)v,(byte)(v>>8),(byte)(v>>16),(byte)(v>>24)}; }

    // ChunkManager.pushOut / rockFloor
    static HashMap<Integer,float[]> solidsMap=new HashMap<>(), rockMap=new HashMap<>();
    static void pushOut(float[] out,float pr){
        int n=10; int ccx=(int)Math.floor((out[0]+500f)/100f), ccz=(int)Math.floor((out[1]+500f)/100f);
        for(int rep=0;rep<2;rep++){
            for(int j=ccz-1;j<=ccz+1;j++) for(int i=ccx-1;i<=ccx+1;i++){
                if(i<0||j<0||i>=n||j>=n) continue;
                float[] arr=solidsMap.get(j*n+i); if(arr==null) continue;
                int k=0;
                while(k<arr.length){
                    float sx=arr[k], sz=arr[k+1], rr=arr[k+2]+pr, dx=out[0]-sx, dz=out[1]-sz, d2=dx*dx+dz*dz;
                    if(d2<rr*rr){ if(d2<1e-6f){ out[0]=sx+rr; } else { float d=sqrt(d2); out[0]=sx+dx/d*rr; out[1]=sz+dz/d*rr; } }
                    k+=3;
                }
            }
        }
    }
    static float rockFloor(float x,float z,float base){
        int n=10; float h=base; int ccx=(int)Math.floor((x+500f)/100f), ccz=(int)Math.floor((z+500f)/100f);
        for(int j=ccz-1;j<=ccz+1;j++) for(int i=ccx-1;i<=ccx+1;i++){
            if(i<0||j<0||i>=n||j>=n) continue;
            float[] arr=rockMap.get(j*n+i); if(arr==null) continue;
            int k=0;
            while(k+4<arr.length){
                float dx=x-arr[k], dz=z-arr[k+1], cy=arr[k+2], re=arr[k+3]*0.9f, ry=arr[k+4]*0.85f; k+=5;
                float d=sqrt(dx*dx+dz*dz);
                if(d<re){ float q=d/re; float top=cy+ry*sqrt(1f-q*q); if(top>h) h=top; }
                else if(d<re*1.3f){ float t=1f-(d-re)/(re*0.3f); float top=base+(cy-base)*t; if(top>h) h=top; }
            }
        }
        return h;
    }
    static void collisionTest(PrintStream out){
        Random r=new Random(5);
        for(int key=0;key<100;key++){
            float[] a=new float[3*8]; for(int i=0;i<8;i++){ a[i*3]=(key%10)*100f-500f+r.nextFloat()*100f; a[i*3+1]=(key/10)*100f-500f+r.nextFloat()*100f; a[i*3+2]=0.4f+r.nextFloat(); }
            solidsMap.put(key,a);
            float[] b=new float[5*3]; for(int i=0;i<3;i++){ b[i*5]=(key%10)*100f-500f+r.nextFloat()*100f; b[i*5+1]=(key/10)*100f-500f+r.nextFloat()*100f; b[i*5+2]=2f+r.nextFloat()*5f; b[i*5+3]=1.5f+r.nextFloat()*3f; b[i*5+4]=1f+r.nextFloat()*2f; }
            rockMap.put(key,b);
        }
        for(int t=0;t<20000;t++){
            float x=-520f+r.nextFloat()*1040f, z=-520f+r.nextFloat()*1040f;
            float[] p={x,z}; pushOut(p,0.35f);
            out.println(p[0]+" "+p[1]+" "+rockFloor(x,z,1.5f));
        }
    }


    // ======================= etapa 5A: Sky (lógica) + Water (dados) — referência =======================
static final float[] STOP_E = {0.15f, 0.0f, -0.08f, -0.20f, -0.35f};
static final float[][] HOT = {{1.00f, 0.80f, 0.45f}, {1.00f, 0.55f, 0.20f}, {1.00f, 0.36f, 0.18f}, {0.70f, 0.22f, 0.32f}, {0.10f, 0.08f, 0.20f}};
static final float[][] MID = {{1.00f, 0.66f, 0.52f}, {1.00f, 0.45f, 0.40f}, {0.88f, 0.30f, 0.45f}, {0.45f, 0.20f, 0.45f}, {0.08f, 0.06f, 0.18f}};
static final float[][] HIGH = {{0.70f, 0.62f, 0.78f}, {0.58f, 0.40f, 0.66f}, {0.42f, 0.28f, 0.60f}, {0.22f, 0.16f, 0.42f}, {0.05f, 0.05f, 0.16f}};
static final float[][] KEY = {{0.0f, 0.02f, 0.03f, 0.10f, 0.05f, 0.08f, 0.20f, 0.22f, 0.27f, 0.42f, 0.34f, 0.42f, 0.68f}, {4.5f, 0.04f, 0.06f, 0.20f, 0.22f, 0.17f, 0.38f, 0.24f, 0.28f, 0.44f, 0.34f, 0.40f, 0.64f}, {5.4f, 0.22f, 0.32f, 0.68f, 0.80f, 0.58f, 0.68f, 0.42f, 0.42f, 0.60f, 0.85f, 0.52f, 0.52f}, {6.3f, 0.36f, 0.58f, 0.90f, 0.88f, 0.76f, 0.74f, 0.50f, 0.52f, 0.66f, 1.00f, 0.72f, 0.52f}, {7.5f, 0.50f, 0.76f, 0.93f, 0.85f, 0.90f, 1.00f, 0.52f, 0.61f, 0.74f, 1.00f, 0.91f, 0.66f}, {9.0f, 0.53f, 0.81f, 0.92f, 0.78f, 0.91f, 1.00f, 0.50f, 0.60f, 0.75f, 1.00f, 0.94f, 0.69f}, {15.5f, 0.53f, 0.81f, 0.92f, 0.78f, 0.91f, 1.00f, 0.50f, 0.60f, 0.75f, 1.00f, 0.94f, 0.69f}, {17.2f, 0.45f, 0.65f, 0.90f, 0.93f, 0.84f, 0.74f, 0.55f, 0.58f, 0.68f, 1.00f, 0.85f, 0.58f}, {18.0f, 0.34f, 0.44f, 0.80f, 0.86f, 0.60f, 0.52f, 0.48f, 0.42f, 0.56f, 1.00f, 0.58f, 0.36f}, {18.6f, 0.22f, 0.24f, 0.58f, 0.60f, 0.42f, 0.58f, 0.36f, 0.34f, 0.52f, 0.62f, 0.40f, 0.52f}, {19.4f, 0.09f, 0.10f, 0.34f, 0.30f, 0.24f, 0.44f, 0.26f, 0.28f, 0.46f, 0.36f, 0.40f, 0.64f}, {20.5f, 0.03f, 0.05f, 0.14f, 0.07f, 0.11f, 0.26f, 0.22f, 0.27f, 0.42f, 0.34f, 0.42f, 0.68f}, {24.0f, 0.02f, 0.03f, 0.10f, 0.05f, 0.08f, 0.20f, 0.22f, 0.27f, 0.42f, 0.34f, 0.42f, 0.68f}};

    static class V3 {
        float x,y,z; V3(){} V3(float a,float b,float c){x=a;y=b;z=c;}
        V3 set(float a,float b,float c){x=a;y=b;z=c;return this;} V3 set(V3 o){x=o.x;y=o.y;z=o.z;return this;}
        V3 scl(float s){x*=s;y*=s;z*=s;return this;} V3 mulAdd(V3 o,float s){x+=o.x*s;y+=o.y*s;z+=o.z*s;return this;}
        float dot(V3 o){return x*o.x+y*o.y+z*o.z;}
        V3 nor(){ float l2=x*x+y*y+z*z; if(l2==0f||l2==1f) return this; return scl(1f/(float)Math.sqrt(l2)); }
    }
    static class Col { float r,g,b,a; void set(float r,float g,float b,float a){this.r=r;this.g=g;this.b=b;this.a=a;} }
    static class SkyRef {
        static float lerp(float a,float b,float t){ return a+(b-a)*t; }
        Random rnd=new Random(42);
        float tod=6.2f; V3 toSun=new V3(1f,0.3f,-0.28f).nor(), toMoon=new V3(), toLight=new V3(); float sunE=0.3f;
        Col topC=new Col(), horC=new Col(), fog=new Col(), ambient=new Col(), lightC=new Col();
        float tw=0f; Col warm1=new Col(), warm2=new Col(), warm3=new Col(), haloCol=new Col(), sunCol=new Col();
        float sunHx=1f, sunHz=0f; V3 sunEv=new V3(), sunNv=new V3(); float sunR=0.05f, sunSquash=1f, warmK=0f;
        Col sunGlitCol=new Col(), moonGlitCol=new Col();
        static class Puff { float ox,oy,oz,s; }
        static class Cloud { float x,y,z,speed; ArrayList<Puff> puffs=new ArrayList<>(); float er,eg,eb; }
        ArrayList<Cloud> clouds=new ArrayList<>();
        static final int NSTARS=760; float[] sdx=new float[NSTARS], sdy=new float[NSTARS], sdz=new float[NSTARS], ssz=new float[NSTARS], sbr=new float[NSTARS], sph=new float[NSTARS], ssp=new float[NSTARS]; int[] sty=new int[NSTARS];
        static class Meteor { V3 d0,tv; float speed,life,age=0f; }
        ArrayList<Meteor> meteors=new ArrayList<>(); float meteorTimer=14f, camAz=0f;
        SkyRef(){
            for(int c=0;c<14;c++){
                ArrayList<Puff> puffs=new ArrayList<>(); float base=45f+rnd.nextFloat()*50f;
                int np=4+rnd.nextInt(3);
                for(int k=0;k<np;k++){ Puff p=new Puff(); p.ox=(k-2)*base*0.55f+rnd.nextFloat()*20f; p.oy=rnd.nextFloat()*18f; p.oz=rnd.nextFloat()*40f-20f; p.s=base*(0.6f+rnd.nextFloat()*0.5f); puffs.add(p); }
                Cloud cl=new Cloud(); cl.x=rnd.nextFloat()*1800f-900f; cl.y=260f+rnd.nextFloat()*160f; cl.z=rnd.nextFloat()*1800f-900f; cl.speed=4f+rnd.nextFloat()*4f; cl.puffs=puffs; clouds.add(cl);
            }
            V3 band=new V3(0.30f,0.62f,-0.72f).nor();
            for(int i=0;i<NSTARS;i++){
                float x=0,y=0,z=0; boolean milky=i>=480;
                while(true){
                    float yy=rnd.nextFloat()*1.04f-0.04f; float ph=rnd.nextFloat()*6.2831855f; float rr=sqrt(max(0f,1f-yy*yy));
                    x=rr*cos(ph); y=yy; z=rr*sin(ph);
                    if(!milky) break;
                    if(abs(x*band.x+y*band.y+z*band.z)<0.07f) break;
                }
                sdx[i]=x; sdy[i]=y; sdz[i]=z; float r=rnd.nextFloat();
                if(milky){ ssz[i]=1.0f; sbr[i]=0.25f+rnd.nextFloat()*0.3f; sty[i]=1; }
                else if(r<0.80f){ ssz[i]=1.2f+rnd.nextFloat()*0.8f; sbr[i]=0.45f+rnd.nextFloat()*0.4f; sty[i]=rnd.nextInt(3); }
                else if(r<0.96f){ ssz[i]=2.2f+rnd.nextFloat()*0.8f; sbr[i]=0.75f+rnd.nextFloat()*0.25f; sty[i]=rnd.nextInt(3); }
                else { ssz[i]=3.4f+rnd.nextFloat()*1.4f; sbr[i]=1f; sty[i]=rnd.nextInt(3); }
                sph[i]=rnd.nextFloat()*6.2831855f; ssp[i]=0.8f+rnd.nextFloat()*2.6f;
            }
            // textura antiga do reflexo (como no Kotlin): sorteios com o mesmo gerador
            int rows=128; float[] rowB=new float[rows], rowW=new float[rows];
            for(int i=0;i<rows;i++) rowB[i]=0.2f+rnd.nextFloat()*0.8f;
            for(int i=0;i<rows;i++) rowW[i]=0.35f+rnd.nextFloat()*0.65f;
            for(int y=0;y<256;y++){ float far=y/255f; float fadeIn=smooth(0f,0.08f,far); float fadeOut=1f-smooth(0.7f,1f,far); float half=(0.16f+0.5f*far)*rowW[y/2];
                for(int x=0;x<64;x++){ float d=abs(x-31.5f)/32f; float a=coerce(1f-d/half,0f,1f); a=a*a*rowB[y/2]; a*=0.55f+0.45f*rnd.nextFloat(); a*=fadeIn*fadeOut; } }
            recompute();
        }
        void stopColor(float[][] arr,float e,Col out){
            if(e>=STOP_E[0]){ out.set(arr[0][0],arr[0][1],arr[0][2],1f); return; }
            for(int i=0;i<STOP_E.length-1;i++){ if(e>=STOP_E[i+1]){ float f=(e-STOP_E[i])/(STOP_E[i+1]-STOP_E[i]); out.set(lerp(arr[i][0],arr[i+1][0],f),lerp(arr[i][1],arr[i+1][1],f),lerp(arr[i][2],arr[i+1][2],f),1f); return; } }
            float[] l=arr[arr.length-1]; out.set(l[0],l[1],l[2],1f);
        }
        void recompute(){
            float a=(tod-6f)*3.1415927f/12f;
            toSun.set(cos(a),sin(a),-0.28f).nor();
            toMoon.set(-cos(a)*0.55f,0.80f,0.30f).nor();
            sunE=toSun.y;
            float k=smooth(0.10f,-0.10f,sunE);
            toLight.set(toSun).scl(1f-k).mulAdd(toMoon,k).nor();
            int i=0; while(i<KEY.length-2 && tod>=KEY[i+1][0]) i++;
            float[] p=KEY[i], q=KEY[i+1];
            float f=coerce((tod-p[0])/(q[0]-p[0]),0f,1f); float s=f*f*(3f-2f*f);
            topC.set(lerp(p[1],q[1],s),lerp(p[2],q[2],s),lerp(p[3],q[3],s),1f);
            horC.set(lerp(p[4],q[4],s),lerp(p[5],q[5],s),lerp(p[6],q[6],s),1f);
            ambient.set(lerp(p[7],q[7],s),lerp(p[8],q[8],s),lerp(p[9],q[9],s),1f);
            lightC.set(lerp(p[10],q[10],s),lerp(p[11],q[11],s),lerp(p[12],q[12],s),1f);
            fog.set(horC.r,horC.g,horC.b,horC.a);
            tw=1f-smooth(0f,0.38f,abs(sunE+0.04f));
            stopColor(HOT,sunE,warm1); stopColor(MID,sunE,warm2); stopColor(HIGH,sunE,warm3);
            warmK=1f-smooth(0f,0.4f,sunE);
            float deep=smooth(0.12f,-0.02f,sunE);
            float sdh=Math.max(sqrt(toSun.x*toSun.x+toSun.z*toSun.z),1e-4f);
            sunHx=toSun.x/sdh; sunHz=toSun.z/sdh;
            sunEv.set(toSun.z/sdh,0f,-toSun.x/sdh);
            sunNv.set(-toSun.x*toSun.y/sdh,sdh,-toSun.z*toSun.y/sdh);
            float hv=smooth(-0.25f,0.0f,sunE);
            haloCol.set(hv,lerp(0.93f,0.50f,warmK)*hv,lerp(0.70f,0.22f,warmK)*hv,1f);
            sunCol.set(1f,lerp(0.95f,0.80f,warmK)*(1f-0.12f*deep),lerp(0.70f,0.46f,warmK)*(1f-0.18f*deep),1f);
            sunR=0.048f*(1f+0.25f*warmK); sunSquash=1f+0.20f*warmK;
        }
        void horizonAt(float dx,float dz,Col out){
            float l=sqrt(dx*dx+dz*dz); float a=0.5f; if(l>1e-3f) a=0.5f+0.5f*((dx/l)*sunHx+(dz/l)*sunHz);
            float wa=(float)Math.pow((double)a,2.2); float w1=coerce(tw*wa*0.9f,0f,1f);
            float r=lerp(horC.r,warm1.r,w1), g=lerp(horC.g,warm1.g,w1), b=lerp(horC.b,warm1.b,w1);
            float wb=tw*(1f-a)*0.5f;
            r=lerp(r,lerp(warm2.r,horC.r,0.5f),wb); g=lerp(g,lerp(warm2.g,horC.g,0.5f),wb); b=lerp(b,lerp(warm2.b,horC.b,0.5f),wb);
            out.set(r,g,b,1f);
        }
        float nightK(){ return 1f-smooth(-0.22f,0f,sunE); }
        void update(float dt,float camX,float camZ,float dirX,float dirZ){
            tod=(tod+dt*24f/600f)%24f; recompute(); horizonAt(dirX,dirZ,fog);
            for(Cloud c: clouds){
                c.x+=c.speed*dt; if(c.x>900f) c.x=-900f;
                float cl=Math.max(sqrt(c.x*c.x+c.z*c.z),1f); float ca=0.5f+0.5f*(c.x/cl*sunHx+c.z/cl*sunHz); float ck=coerce(tw*ca*ca,0f,1f);
                c.er=lerp(horC.r*0.55f,warm1.r*0.85f,ck); c.eg=lerp(horC.g*0.55f,warm1.g*0.85f,ck); c.eb=lerp(horC.b*0.55f,warm1.b*0.85f,ck);
            }
            float sunG=smooth(-0.02f,0.05f,sunE)*(0.9f+0.5f*warmK);
            sunGlitCol.set(sunCol.r*sunG,sunCol.g*sunG,sunCol.b*sunG,1f);
            float moonG=0.55f*smooth(0.02f,0.25f,toMoon.y)*nightK();
            moonGlitCol.set(0.60f*moonG,0.72f*moonG,1f*moonG,1f);
            if(nightK()>0.7f){ meteorTimer-=dt; if(meteorTimer<=0f){ meteorTimer=25f+rnd.nextFloat()*45f; spawnMeteor(); } }
            java.util.Iterator<Meteor> it=meteors.iterator();
            while(it.hasNext()){ Meteor m=it.next(); m.age+=dt; if(m.age>m.life) it.remove(); }
        }
        void spawnMeteor(){
            float az=camAz+(rnd.nextFloat()-0.5f)*1.6f; float y=0.35f+rnd.nextFloat()*0.5f; float rr=sqrt(1f-y*y);
            V3 d0=new V3(rr*cos(az),y,rr*sin(az)); V3 r=new V3(rnd.nextFloat()-0.5f,rnd.nextFloat()-0.7f,rnd.nextFloat()-0.5f);
            V3 tv=new V3(r.x,r.y,r.z).mulAdd(d0,-r.dot(d0)).nor(); if(tv.y>0f) tv.scl(-1f);
            Meteor m=new Meteor(); m.d0=d0; m.tv=tv; m.speed=0.9f+rnd.nextFloat()*0.6f; m.life=0.8f+rnd.nextFloat()*0.5f; meteors.add(m);
        }
    }
    static void pc(StringBuilder sb,Col c){ sb.append(' ').append(c.r).append(' ').append(c.g).append(' ').append(c.b); }
    static void pv(StringBuilder sb,V3 v){ sb.append(' ').append(v.x).append(' ').append(v.y).append(' ').append(v.z); }
    static void skyTest(PrintStream out){
        SkyRef s=new SkyRef();
        StringBuilder sb=new StringBuilder();
        for(int i=0;i<SkyRef.NSTARS;i++) out.println(s.sdx[i]+" "+s.sdy[i]+" "+s.sdz[i]+" "+s.ssz[i]+" "+s.sbr[i]+" "+s.sph[i]+" "+s.ssp[i]+" "+s.sty[i]);
        for(int step=0;step<6000;step++){
            float dt=0.05f+(step%7)*0.01f; float dx=(float)Math.cos(step*0.011f), dz=(float)Math.sin(step*0.013f);
            s.update(dt,1f,2f,dx,dz); s.camAz=atan2(dz,dx);
            if(step%25==0 || !s.meteors.isEmpty()){
                sb.setLength(0); sb.append(s.tod); pv(sb,s.toSun); pv(sb,s.toMoon); pv(sb,s.toLight); pc(sb,s.topC); pc(sb,s.horC); pc(sb,s.fog); pc(sb,s.ambient); pc(sb,s.lightC);
                sb.append(' ').append(s.tw); pc(sb,s.warm1); pc(sb,s.warm2); pc(sb,s.warm3); pc(sb,s.haloCol); pc(sb,s.sunCol);
                sb.append(' ').append(s.sunHx).append(' ').append(s.sunHz); pv(sb,s.sunEv); pv(sb,s.sunNv);
                sb.append(' ').append(s.sunR).append(' ').append(s.sunSquash).append(' ').append(s.warmK); pc(sb,s.sunGlitCol); pc(sb,s.moonGlitCol);
                for(int c: new int[]{0,5,13}){ SkyRef.Cloud cl=s.clouds.get(c); sb.append(' ').append(cl.x).append(' ').append(cl.er).append(' ').append(cl.eg).append(' ').append(cl.eb); }
                sb.append(' ').append(s.meteors.size());
                if(!s.meteors.isEmpty()){ SkyRef.Meteor m=s.meteors.get(0); pv(sb,m.d0); pv(sb,m.tv); sb.append(' ').append(m.speed).append(' ').append(m.life).append(' ').append(m.age); }
                out.println(sb);
            }
        }
    }
    // ---- Water: texturas swash/wet/ruído, faixa de onda e anéis de espuma ----
    static float edgeAt(float u){ float tp=6.2831855f; return 0.5f+0.085f*sin(tp*3f*u+0.7f)+0.055f*sin(tp*7f*u+2.1f)+0.03f*sin(tp*13f*u+4.0f)+0.015f*sin(tp*29f*u+1.0f); }
    static int rgba8888(float r,float g,float b,float a){ return ((int)(r*255)<<24)|((int)(g*255)<<16)|((int)(b*255)<<8)|(int)(a*255); }
    static byte[] swashTex(boolean wet){
        int w=512,h=256; byte[] o=new byte[w*h*4]; Random rnd=new Random(wet?5L:9L); float[] lace=new float[w*h]; for(int i=0;i<lace.length;i++) lace[i]=rnd.nextFloat();
        for(int y=0;y<h;y++){ float v=y/(h-1f); for(int x=0;x<w;x++){
            float u=x/(float)w; float dv=edgeAt(u)-v; float ln=lace[y*w+x]; float r=1f,g=1f,b=1f,a;
            if(wet){ r=0.30f;g=0.20f;b=0.09f; if(dv>=0f) a=0.34f; else if(dv>-0.05f) a=0.34f*(1f+dv/0.05f); else a=0f; }
            else if(dv<-0.014f) a=0f; else if(dv<0f) a=0.9f*(1f+dv/0.014f); else if(dv<0.035f) a=(ln>dv/0.035f*0.7f)?0.95f:0.35f;
            else if(dv>=0.105f&&dv<=0.125f) a=(ln>0.4f)?0.55f:0.12f; else { r=0.72f;g=0.97f;b=1f; a=0.16f+0.34f*Math.min(1f,Math.max(0f,(dv-0.04f)/0.25f)); }
            int c=rgba8888(r,g,b,a); int k=(y*w+x)*4; o[k]=(byte)(c>>>24); o[k+1]=(byte)(c>>>16); o[k+2]=(byte)(c>>>8); o[k+3]=(byte)c; } }
        return o;
    }
    static float[] periodicNoise(int n,int cells,long seed){
        Random rr=new Random(seed); float[] lat=new float[cells*cells]; for(int i=0;i<lat.length;i++) lat[i]=rr.nextFloat(); float[] out=new float[n*n];
        for(int y=0;y<n;y++){ float fy=(float)y/n*cells; int y0=(int)fy; float ty=fy-y0; int y1=(y0+1)%cells; float sy=ty*ty*(3f-2f*ty);
            for(int x=0;x<n;x++){ float fx=(float)x/n*cells; int x0=(int)fx; float tx=fx-x0; int x1=(x0+1)%cells; float sx=tx*tx*(3f-2f*tx);
                float a=lat[y0*cells+x0],b=lat[y0*cells+x1],c=lat[y1*cells+x0],d=lat[y1*cells+x1];
                out[y*n+x]=SkyRef.lerp(SkyRef.lerp(a,b,sx),SkyRef.lerp(c,d,sx),sy); } }
        return out;
    }
    static byte[] noiseTex(){
        int n=256; float[] r4=periodicNoise(n,4,11L),r8=periodicNoise(n,8,12L),r16=periodicNoise(n,16,13L),g4=periodicNoise(n,4,14L),g8=periodicNoise(n,8,15L),g16=periodicNoise(n,16,16L),bb=periodicNoise(n,32,17L),aa=periodicNoise(n,24,18L);
        byte[] o=new byte[n*n*4];
        for(int y=0;y<n;y++) for(int x=0;x<n;x++){ int k=y*n+x; float vr=0.5f*r4[k]+0.3f*r8[k]+0.2f*r16[k]; float vg=0.5f*g4[k]+0.3f*g8[k]+0.2f*g16[k];
            float cr=coerce(0.5f+(vr-0.5f)*1.5f,0f,1f), cg=coerce(0.5f+(vg-0.5f)*1.5f,0f,1f); int c=rgba8888(cr,cg,bb[k],aa[k]);
            o[k*4]=(byte)(c>>>24); o[k*4+1]=(byte)(c>>>16); o[k*4+2]=(byte)(c>>>8); o[k*4+3]=(byte)c; }
        return o;
    }
    static float radiusAt(float ang,float target){ float dx=cos(ang),dz=sin(ang); float lo=0f,hi=800f; for(int i=0;i<24;i++){ float mid=(lo+hi)/2f; if(Base.depth(dx*mid,dz*mid)>target) lo=mid; else hi=mid; } return (lo+hi)/2f; }
    static void waterTest() throws Exception {
        try(FileOutputStream f=new FileOutputStream("/tmp/swash_java.bin")){ f.write(swashTex(false)); f.write(swashTex(true)); f.write(noiseTex()); }
        // faixa de onda
        ArrayList<Float> band=new ArrayList<>();
        float s=2.5f, half=500f; int nn=(int)(2f*half/s); int w=nn+1;
        float[] dd=new float[w*w], hh=new float[w*w]; Arrays.fill(dd,Float.NaN); Arrays.fill(hh,Float.NaN);
        float reps=22f, tp=6.2831855f;
        java.util.function.BiFunction<Integer,Integer,Float> dAt=(i,j)->{ int k=j*w+i; if(Float.isNaN(dd[k])) dd[k]=Base.depth(-half+i*s,-half+j*s); return dd[k]; };
        java.util.function.BiFunction<Integer,Integer,Float> hAt=(i,j)->{ int k=j*w+i; if(Float.isNaN(hh[k])) hh[k]=heightAt(-half+i*s,-half+j*s); return hh[k]; };
        for(int j=0;j<nn;j++) for(int i=0;i<nn;i++){
            float d00=dAt.apply(i,j),d10=dAt.apply(i+1,j),d01=dAt.apply(i,j+1),d11=dAt.apply(i+1,j+1);
            float dmin=Math.min(Math.min(d00,d10),Math.min(d01,d11)), dmax=Math.max(Math.max(d00,d10),Math.max(d01,d11));
            if(dmax<0f||dmin>8f+2.5f) continue;
            int[][] tr=((i+j)%2==0)? new int[][]{{i,j,i,j+1,i+1,j+1},{i,j,i+1,j+1,i+1,j}} : new int[][]{{i,j,i,j+1,i+1,j},{i+1,j,i,j+1,i+1,j+1}};
            for(int[] t: tr){
                float u0=atan2(-half+t[1]*s,-half+t[0]*s)/tp*reps, u1=atan2(-half+t[3]*s,-half+t[2]*s)/tp*reps, u2=atan2(-half+t[5]*s,-half+t[4]*s)/tp*reps;
                u1+=Math.round((u0-u1)/reps)*reps; u2+=Math.round((u0-u2)/reps)*reps;
                float[] us={u0,u1,u2};
                for(int v=0;v<3;v++){ int ii=t[v*2], jj=t[v*2+1]; float x=-half+ii*s, z=-half+jj*s; float d=dAt.apply(ii,jj);
                    band.add(x); band.add(hAt.apply(ii,jj)+0.04f); band.add(z); band.add(0f); band.add(1f); band.add(0f); band.add(toFloatBits(1f,1f,1f,smooth(0f,1.5f,d))); band.add(us[v]); band.add(d/8f); }
            }
        }
        // espuma
        float[][] ranges={{-1f,-5f},{-9f,-14f},{-19f,-24f}}; int segs=720; ArrayList<Float> foam=new ArrayList<>();
        for(int ri=0;ri<3;ri++) for(int k=0;k<segs;k++){
            float a0=k*6.2831855f/segs, a1=(k+1)*6.2831855f/segs;
            float i0=radiusAt(a0,ranges[ri][0]),o0=radiusAt(a0,ranges[ri][1]),i1=radiusAt(a1,ranges[ri][0]),o1=radiusAt(a1,ranges[ri][1]);
            foam.add(cos(a0)*i0); foam.add(sin(a0)*i0); foam.add(cos(a0)*o0); foam.add(sin(a0)*o0); foam.add(cos(a1)*o1); foam.add(sin(a1)*o1); foam.add(cos(a1)*i1); foam.add(sin(a1)*i1);
        }
        try(DataOutputStream o=new DataOutputStream(new BufferedOutputStream(new FileOutputStream("/tmp/band_java.bin")))){
            o.write(le(band.size())); for(float v: band) o.write(le(Float.floatToRawIntBits(v)));
            o.write(le(foam.size())); for(float v: foam) o.write(le(Float.floatToRawIntBits(v)));
        }
    }


    // ======================= etapa 6: Player (boneco) — referência (tradução literal de Player.kt + IlhaGame.update) =======================
    static final float PLAYER_R=0.35f, SWIM_Y=-1.3f;
    static float gdxAtan2(float y,float x){
        final float PI=3.1415927f;
        if(x==0f){ if(y>0f) return PI/2; if(y==0f) return 0f; return -PI/2; }
        final float atan, z=y/x;
        if(Math.abs(z)<1f){ atan=z/(1f+0.28f*z*z); if(x<0f) return atan+(y<0f?-PI:PI); return atan; }
        atan=PI/2-z/(z*z+0.28f);
        return y<0f?atan-PI:atan;
    }
    static class Pl {
        float px,py,pz,heading,vy=0f; boolean grounded=true;
        void place(float x,float z,float h){ px=x; pz=z; py=groundAt(x,z); heading=h; }
        float floorAt(float x,float z){ float g=rockFloor(x,z,groundAt(x,z)); return max(g,SWIM_Y); }
        void move(float dx,float dz,float dt,float speed){
            float step=speed*dt; float tx=px+dx*step, tz=pz+dz*step;
            if(!attempt(tx,tz)){ if(!attempt(tx,pz)) attempt(px,tz); }
            heading=gdxAtan2(dx,dz)*(180f/3.1415927f);
        }
        boolean attempt(float tx0,float tz0){
            float[] tmp={tx0,tz0};
            float aN=Bridge.along(tmp[0],tmp[1]);
            boolean underBridge=py<Bridge.deckAt(px,pz)-0.9f;
            if(abs(aN)<BRIDGE_HALF_LEN && !underBridge){
                float cO=Bridge.across(px,pz); float cN=Bridge.across(tmp[0],tmp[1]);
                float inner=BRIDGE_HALF_W-PLAYER_R, outer=BRIDGE_HALF_W+PLAYER_R; boolean changed=false;
                if(abs(cO)<BRIDGE_HALF_W){ if(abs(cN)>inner){ cN=cN>0f?inner:-inner; changed=true; } }
                else if(abs(cN)<outer){ cN=cO>0f?outer:-outer; changed=true; }
                if(changed){ tmp[0]=Bridge.x+Bridge.dx*aN-Bridge.dz*cN; tmp[1]=Bridge.z+Bridge.dz*aN+Bridge.dx*cN; }
            }
            pushOut(tmp,PLAYER_R);
            float nx=tmp[0], nz=tmp[1];
            float g1=floorAt(nx,nz);
            px=nx; pz=nz;
            if(py<g1){ py=g1; vy=0f; }
            return true;
        }
        void jump(){ if(grounded){ vy=6.5f; grounded=false; } }
        void physics(float dt){
            float g=floorAt(px,pz);
            if(grounded && vy<=0f && py-g<=0.35f){ py=g; }
            else { grounded=false; vy-=18f*dt; py+=vy*dt; if(py<=g && vy<=0f){ py=g; vy=0f; grounded=true; } }
        }
        void drive(float yaw,float moveX,float moveY,boolean run,boolean[] jumpFlag,float dt){
            float fx=cos(yaw), fz=sin(yaw);
            float mvx=fx*moveY+(-fz)*moveX, mvz=fz*moveY+fx*moveX;
            float len=hypot(mvx,mvz);
            if(len>0.05f){ float speed=run?8f:4.5f; float wade=py<-0.3f?0.55f:1f; move(mvx/len,mvz/len,dt,speed*min(1f,len)*wade); }
            if(jumpFlag[0]){ jump(); jumpFlag[0]=false; }
            physics(dt);
        }
    }
    static void fakeColliders(){
        Random r=new Random(5);
        for(int key=0;key<100;key++){
            float[] a=new float[3*8]; for(int i=0;i<8;i++){ a[i*3]=(key%10)*100f-500f+r.nextFloat()*100f; a[i*3+1]=(key/10)*100f-500f+r.nextFloat()*100f; a[i*3+2]=0.4f+r.nextFloat(); }
            solidsMap.put(key,a);
            float[] b=new float[5*3]; for(int i=0;i<3;i++){ b[i*5]=(key%10)*100f-500f+r.nextFloat()*100f; b[i*5+1]=(key/10)*100f-500f+r.nextFloat()*100f; b[i*5+2]=2f+r.nextFloat()*5f; b[i*5+3]=1.5f+r.nextFloat()*3f; b[i*5+4]=1f+r.nextFloat()*2f; }
            rockMap.put(key,b);
        }
    }
    static void playerSim(PrintStream out){
        fakeColliders();
        float bx=RoadNet.bridgeX, bz=RoadNet.bridgeZ, btx=RoadNet.bridgeTX, btz=RoadNet.bridgeTZ;
        float nbx=-btz, nbz=btx;   // normal da ponte (across positivo)
        float[][] sc={ // x, z, yaw, frames, biasForward, ruidoLateral, ruidoDoGiro
            {RoadNet.startX, RoadNet.startZ, atan2(-0.6f,0.8f), 9000f, 0.5f, 1f, 1f},
            {bx-btx*20f, bz-btz*20f, atan2(btz,btx), 3500f, 0.95f, 0.1f, 0.1f},
            {bx+btx*20f, bz+btz*20f, atan2(-btz,-btx), 3500f, 0.95f, 0.1f, 0.1f},
            {RoadNet.shoreX-RoadNet.dirX*4f, RoadNet.shoreZ-RoadNet.dirZ*4f, atan2(RoadNet.dirZ,RoadNet.dirX), 3500f, 0.95f, 0.1f, 0.1f},
            {bx-btx*8f, bz-btz*8f, atan2(btz,btx)+0.5f, 1500f, 1f, 0f, 0f},
            {bx+nbx*4f-btx*2f, bz+nbz*4f-btz*2f, atan2(-btx,btz), 1500f, 1f, 0f, 0f}};
        for(int s=0;s<sc.length;s++){
            Random r=new Random(77+s);
            Pl p=new Pl(); p.place(sc[s][0],sc[s][1],0f);
            float yaw=sc[s][2]; int frames=(int)sc[s][3]; float bias=sc[s][4];
            float mx=0f,my=0f; boolean run=false; boolean[] jf={false};
            for(int f=0;f<frames;f++){
                if(r.nextFloat()<0.02f){ mx=(r.nextFloat()*2f-1f)*0.8f*sc[s][5]; my=r.nextFloat()<bias?1f:(r.nextFloat()*2f-1f); run=r.nextFloat()<0.4f; yaw+=(r.nextFloat()-0.5f)*0.6f*sc[s][6]; }
                if(r.nextFloat()<0.01f) jf[0]=true;
                float dt=(r.nextFloat()<0.05f)?0.05f:1f/60f;
                p.drive(yaw,mx,my,run,jf,dt);
                out.println(p.px+" "+p.py+" "+p.pz+" "+p.vy+" "+p.heading+" "+(p.grounded?1:0));
            }
        }
    }

    public static void main(String[] a) throws Exception {
        if(a.length>0 && a[0].equals("sky")){ PrintStream o=new PrintStream(new BufferedOutputStream(System.out)); skyTest(o); o.flush(); return; }
        if(a.length>0 && a[0].equals("water")){ waterTest(); return; }

        if(a.length>0 && a[0].equals("terrain")){
            writeTerrain("/tmp/terrain_java.bin", new int[][]{{0,0},{1,7},{2,6},{2,5},{3,5},{5,5},{5,6},{4,4},{6,3},{8,7},{9,9},{7,2}});
            return;
        }
        if(a.length>0 && a[0].equals("player")){ PrintStream o=new PrintStream(new BufferedOutputStream(System.out)); playerSim(o); o.flush(); return; }
        if(a.length>0 && a[0].equals("coll")){ PrintStream o=new PrintStream(new BufferedOutputStream(System.out)); collisionTest(o); o.flush(); return; }

        PrintStream out=new PrintStream(new BufferedOutputStream(System.out));
        out.println(RoadNet.shoreX+" "+RoadNet.shoreZ+" "+RoadNet.bridgeX+" "+RoadNet.bridgeZ+" "+RoadNet.bridgeTX+" "+RoadNet.bridgeTZ+" "+Bridge.deckY+" "+Bridge.pitchDeg+" "+RoadNet.xs.length);
        float[] o=new float[10];
        int idx=0;
        for(int i=-60;i<=60;i++) for(int j=-60;j<=60;j++){
            float x=i*8.7f+0.37f*(j%5), z=j*8.3f-0.41f*(i%7);
            float h=heightAt(x,z);
            float ny=0.55f+0.45f*((idx*37%100)/100f); idx++;
            sample(x,z,h,ny,o,0);
            StringBuilder sb=new StringBuilder();
            sb.append(Base.depth(x,z)).append(' ').append(Base.baseHeight(x,z)).append(' ').append(h).append(' ').append(groundAt(x,z)).append(' ').append(River.dist(x,z));
            for(int k=0;k<10;k++) sb.append(' ').append(o[k]);
            out.println(sb);
        }
        out.flush();
    }
}
