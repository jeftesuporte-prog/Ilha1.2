import java.util.*;
import java.io.*;

public class RefTex {
    static final int S=256;
    static float sin(float x){return (float)Math.sin(x);} static float cos(float x){return (float)Math.cos(x);}
    static float sqrt(float x){return (float)Math.sqrt(x);}
    static float coerce(float v,float lo,float hi){ return v<lo?lo:(v>hi?hi:v); }
    static float hash(int i,int j,int seed){ int h=i*374761393+j*668265263+seed*362437; h=(h^(h>>>13))*1274126177; h=h^(h>>>16); return (h&0xFFFF)/65535f; }
    static int wrap(int a,int per){ return ((a%per)+per)%per; }
    static float vnoise(float u,float v,int perX,int perY,int seed){
        float x=u*perX, y=v*perY; int xi=(int)Math.floor(x), yi=(int)Math.floor(y);
        float fx=x-xi, fy=y-yi; float sx=fx*fx*(3f-2f*fx), sy=fy*fy*(3f-2f*fy);
        int x0=wrap(xi,perX), x1=wrap(xi+1,perX), y0=wrap(yi,perY), y1=wrap(yi+1,perY);
        float a=hash(x0,y0,seed), b=hash(x1,y0,seed), c=hash(x0,y1,seed), d=hash(x1,y1,seed);
        float top=a+(b-a)*sx, bot=c+(d-c)*sx; return top+(bot-top)*sy;
    }
    static float fbm(float u,float v,int per,int oct,int seed){
        float amp=0.5f,sum=0f,norm=0f; int p=per;
        for(int o=0;o<oct;o++){ sum+=vnoise(u,v,p,p,seed+o*17)*amp; norm+=amp; amp*=0.5f; p*=2; }
        return sum/norm;
    }
    static float lerp(float a,float b,float t){ return a+(b-a)*t; }
    static float sstep(float e0,float e1,float x){ float t=coerce((x-e0)/(e1-e0),0f,1f); return t*t*(3f-2f*t); }

    static class Canvas {
        float[] r=new float[S*S], g=new float[S*S], b=new float[S*S];
        void set(int x,int y,float cr,float cg,float cb){ int i=(y&(S-1))*S+(x&(S-1)); r[i]=cr; g[i]=cg; b[i]=cb; }
        void blend(int x,int y,float cr,float cg,float cb,float a){ int i=(y&(S-1))*S+(x&(S-1)); r[i]+=(cr-r[i])*a; g[i]+=(cg-g[i])*a; b[i]+=(cb-b[i])*a; }
        void ellipse(float cx,float cy,float len,float wid,float ang,float cr,float cg,float cb,float a){
            float ca=cos(ang), sa=sin(ang); int m=(int)Math.ceil(Math.max(len,wid))+1;
            for(int dy=-m;dy<=m;dy++) for(int dx=-m;dx<=m;dx++){
                float xr=dx*ca+dy*sa, yr=-dx*sa+dy*ca;
                float e=(xr*xr)/(len*len)+(yr*yr)/(wid*wid);
                if(e<=1f) blend((int)cx+dx,(int)cy+dy,cr,cg,cb,a);
            }
        }
        byte[] px(){
            byte[] o=new byte[S*S*4];
            for(int i=0;i<S*S;i++){
                o[i*4]=(byte)(int)(coerce(r[i],0f,1f)*255); o[i*4+1]=(byte)(int)(coerce(g[i],0f,1f)*255);
                o[i*4+2]=(byte)(int)(coerce(b[i],0f,1f)*255); o[i*4+3]=(byte)255;
            }
            return o;
        }
    }

    static byte[] grass(){
        Canvas c=new Canvas(); Random rnd=new Random(11);
        for(int y=0;y<S;y++) for(int x=0;x<S;x++){
            float u=(x+0.5f)/S, v=(y+0.5f)/S;
            float big=sstep(0.28f,0.72f,fbm(u,v,3,4,1)); float mid=fbm(u,v,12,3,2);
            float cr,cg,cb;
            if(big<0.5f){ float t=big*2f; cr=lerp(0.26f,0.365f,t); cg=lerp(0.63f,0.733f,t); cb=lerp(0.16f,0.208f,t); }
            else { float t=(big-0.5f)*2f; cr=lerp(0.365f,0.49f,t); cg=lerp(0.733f,0.86f,t); cb=lerp(0.208f,0.29f,t); }
            float k=0.9f+0.2f*mid+(hash(x,y,5)-0.5f)*0.10f;
            c.set(x,y,cr*k,cg*k,cb*k);
        }
        for(int it=0;it<3200;it++){
            int x0=rnd.nextInt(S), y0=rnd.nextInt(S); int len=4+rnd.nextInt(7);
            float lean=(rnd.nextFloat()-0.5f)*0.7f; boolean dark=rnd.nextFloat()<0.45f;
            for(int k=0;k<len;k++){ float a=0.9f-k*0.07f;
                if(dark) c.blend(x0+(int)(lean*k),y0+k,0.17f,0.50f,0.11f,a); else c.blend(x0+(int)(lean*k),y0+k,0.58f,0.92f,0.33f,a); }
        }
        float[][] fl={{1f,1f,0.95f},{1f,0.88f,0.2f},{1f,0.55f,0.75f}};
        for(int i=0;i<9;i++){
            int x=rnd.nextInt(S), y=rnd.nextInt(S); float[] f=fl[i%3];
            c.set(x,y,f[0],f[1],f[2]);
            c.blend(x+1,y,f[0],f[1],f[2],0.8f); c.blend(x-1,y,f[0],f[1],f[2],0.8f);
            c.blend(x,y+1,f[0],f[1],f[2],0.8f); c.blend(x,y-1,f[0],f[1],f[2],0.8f);
            c.set(x,y,1f,0.8f,0.1f);
        }
        for(int it=0;it<6;it++){
            float x=(float)rnd.nextInt(S), y=(float)rnd.nextInt(S);
            c.ellipse(x+1f,y+1f,3.2f,2.2f,0f,0.20f,0.35f,0.12f,0.6f);
            c.ellipse(x,y,3f,2f,rnd.nextFloat()*3f,0.62f,0.62f,0.60f,1f);
            c.ellipse(x-0.7f,y-0.6f,1.4f,0.9f,0f,0.82f,0.82f,0.80f,0.9f);
        }
        return c.px();
    }

    static byte[] rock(boolean moss){
        Canvas c=new Canvas(); Random rnd=new Random(moss?33:21);
        for(int y=0;y<S;y++) for(int x=0;x<S;x++){
            float u=(x+0.5f)/S, v=(y+0.5f)/S;
            float big=fbm(u,v,4,5,21); float strata=vnoise(u,v,3,22,23);
            float gr=0.30f+0.26f*big+0.12f*(strata-0.5f); gr+=(hash(x,y,9)-0.5f)*0.09f;
            float cr=gr*1.03f, cg=gr, cb=gr*0.96f;
            float dp=sstep(0.56f,0.74f,fbm(u,v,5,3,44));
            cr=lerp(cr,0.47f*(0.8f+big*0.4f),dp*0.65f); cg=lerp(cg,0.34f*(0.8f+big*0.4f),dp*0.65f); cb=lerp(cb,0.21f*(0.8f+big*0.4f),dp*0.65f);
            float mp= moss ? sstep(0.40f,0.58f,fbm(u,v,6,4,55)) : sstep(0.70f,0.80f,fbm(u,v,6,4,55))*0.7f;
            float mk=0.85f+0.3f*fbm(u,v,20,2,56);
            cr=lerp(cr,0.29f*mk,mp*0.92f); cg=lerp(cg,0.49f*mk,mp*0.92f); cb=lerp(cb,0.18f*mk,mp*0.92f);
            float ridge=Math.abs(fbm(u,v,5,4,33)-0.5f)*2f; float crack=1f-sstep(0f,0.045f,ridge);
            float ridge2=Math.abs(fbm(u,v,9,3,34)-0.5f)*2f; float crack2=1f-sstep(0f,0.03f,ridge2);
            float dk=1f-0.6f*Math.max(crack,crack2*0.7f);
            c.set(x,y,cr*dk,cg*dk,cb*dk);
        }
        for(int it=0;it<120;it++){
            int x0=rnd.nextInt(S), y0=rnd.nextInt(S); int len=6+rnd.nextInt(16);
            float dx=rnd.nextFloat()*2f-1f, dy=rnd.nextFloat()*2f-1f; float l=Math.max(0.01f,sqrt(dx*dx+dy*dy));
            boolean light=rnd.nextFloat()<0.3f;
            for(int k=0;k<len;k++){ int px=x0+(int)(dx/l*k), py=y0+(int)(dy/l*k);
                if(light) c.blend(px,py,0.7f,0.7f,0.68f,0.35f); else c.blend(px,py,0.1f,0.1f,0.1f,0.45f); }
        }
        return c.px();
    }

    static byte[] sand(){
        Canvas c=new Canvas(); Random rnd=new Random(5);
        for(int y=0;y<S;y++) for(int x=0;x<S;x++){
            float u=(x+0.5f)/S, v=(y+0.5f)/S;
            float mott=0.94f+0.10f*fbm(u,v,6,3,61); float grain=(hash(x,y,7)-0.5f)*0.07f;
            float wv=sin((v*8f+1.8f*(fbm(u,v,3,3,62)-0.5f))*6.2831855f); float ripple=0.035f*wv;
            float k=mott+grain+ripple; c.set(x,y,0.96f*k,0.87f*k,0.70f*k);
        }
        for(int it=0;it<160;it++){ int bx=rnd.nextInt(S), by=rnd.nextInt(S); c.blend(bx,by,1f,1f,0.93f,0.95f); }
        for(int it=0;it<70;it++){ int bx=rnd.nextInt(S), by=rnd.nextInt(S); c.blend(bx,by,0.74f,0.62f,0.45f,0.7f); }
        for(int it=0;it<5;it++){ float cx=(float)rnd.nextInt(S), cy=(float)rnd.nextInt(S); c.ellipse(cx,cy,2.5f,1.6f,rnd.nextFloat()*3f,0.98f,0.93f,0.86f,0.95f); }
        return c.px();
    }

    static byte[] forest(){
        Canvas c=new Canvas(); Random rnd=new Random(77);
        for(int y=0;y<S;y++) for(int x=0;x<S;x++){
            float u=(x+0.5f)/S, v=(y+0.5f)/S;
            float big=fbm(u,v,4,5,71); float damp=sstep(0.42f,0.70f,fbm(u,v,5,3,72));
            float cr=lerp(0.54f,0.40f,big), cg=lerp(0.36f,0.27f,big), cb=lerp(0.18f,0.14f,big);
            float dk=1f-0.38f*damp; float gr=(hash(x,y,13)-0.5f)*0.10f;
            cr=cr*dk+gr; cg=cg*dk+gr*0.8f; cb=cb*dk+gr*0.5f; c.set(x,y,cr,cg,cb);
        }
        for(int it=0;it<9;it++){
            float px=rnd.nextFloat()*S, py=rnd.nextFloat()*S; float ang=rnd.nextFloat()*6.2831855f;
            int steps=60+rnd.nextInt(60); float th=1.2f+rnd.nextFloat()*1.2f;
            for(int k=0;k<steps;k++){
                ang+=(rnd.nextFloat()-0.5f)*0.45f; px+=cos(ang)*1.1f; py+=sin(ang)*1.1f;
                c.ellipse(px,py,th,th,0f,0.25f,0.15f,0.07f,0.95f);
                c.ellipse(px-0.9f,py-0.9f,th*0.5f,th*0.5f,0f,0.46f,0.31f,0.16f,0.55f);
            }
        }
        float[][] leaf={{0.71f,0.40f,0.11f},{0.63f,0.32f,0.16f},{0.78f,0.56f,0.23f},{0.55f,0.41f,0.08f},{0.36f,0.22f,0.10f}};
        for(int it=0;it<260;it++){
            float[] f=leaf[rnd.nextInt(leaf.length)]; float sh=0.85f+rnd.nextFloat()*0.3f; float a=rnd.nextFloat()*3.1416f;
            float cx=(float)rnd.nextInt(S), cy=(float)rnd.nextInt(S); float len=3.5f+rnd.nextFloat()*3.5f;
            c.ellipse(cx,cy,len,len*0.45f,a,f[0]*sh,f[1]*sh,f[2]*sh,0.95f);
            c.ellipse(cx,cy,len*0.9f,0.6f,a,f[0]*sh*0.6f,f[1]*sh*0.6f,f[2]*sh*0.6f,0.7f);
        }
        for(int it=0;it<40;it++){ float cx=(float)rnd.nextInt(S), cy=(float)rnd.nextInt(S); c.ellipse(cx,cy,2.2f,1.6f,rnd.nextFloat()*3f,0.26f,0.42f,0.14f,0.85f); }
        return c.px();
    }

    static void w(String n,byte[] d) throws Exception { try(FileOutputStream f=new FileOutputStream("/tmp/tex_java_"+n+".bin")){ f.write(d); } }
    public static void main(String[] a) throws Exception {
        w("grass",grass()); w("rock",rock(false)); w("rockmoss",rock(true)); w("sand",sand()); w("forest",forest());
    }
}
