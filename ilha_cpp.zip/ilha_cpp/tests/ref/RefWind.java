import java.util.*;
public class RefWind {
    static float time=0f, gust=0f, dirX=0.82f, dirZ=0.57f, clock=0f, period=8f, dur=4.2f, peak=0.65f, side=1f; static final float baseAng=0.6f;
    static Random rnd=new Random(77);
    static float sin(float x){return (float)Math.sin(x);} static float cos(float x){return (float)Math.cos(x);}
    static void update(float dt){
        clock+=dt;
        if(clock>=period){ clock-=period; period=7f+rnd.nextFloat()*3f; dur=3.6f+rnd.nextFloat()*1.6f; peak=0.45f+rnd.nextFloat()*0.35f; side=-side;
            float ang=baseAng+side*(1.3f+rnd.nextFloat()*0.4f); dirX=cos(ang); dirZ=sin(ang); }
        if(clock<dur){ float s=sin(3.1415927f*clock/dur); gust=peak*s*s; } else gust=0f;
    }
    static float[] offset(float px,float py,float pz,float baseY,float h,float amp,float ph,float fl){
        float t=Math.min(Math.max((py-baseY)/h,0f),1f); float w=t*t*amp; float tt=time;
        float g=gust*(0.85f+0.15f*sin(tt*0.6f+px*0.05f+pz*0.04f));
        float sw=0.6f*sin(tt*0.9f+ph)+0.4f*sin(tt*1.7f+ph*1.9f+1.3f);
        float along=0.03f+0.03f*sin(tt*0.5f+ph)+g*(0.55f+0.25f*sw); float across=0.10f*g*sin(tt*1.3f+ph*2.1f);
        float dx=dirX, dz=dirZ; float ox=(dx*along-dz*across)*w, oz=(dz*along+dx*across)*w, oy=0f;
        float f=fl*Math.min(1f,w*3f); float fm=0.12f+0.88f*g;
        ox+=f*0.08f*fm*sin(tt*3.1f+ph*3f+px*0.9f+pz*0.7f); oz+=f*0.08f*fm*sin(tt*2.7f+ph*2f+pz*0.9f+px*0.6f); oy+=f*0.05f*fm*sin(tt*4.3f+ph+px*1.1f+pz*1.3f);
        return new float[]{ox,oy,oz};
    }
    public static void main(String[] a){
        for(int i=0;i<6000;i++){ update(1f/60f); time+=1f/60f;
            if(i%7==0){ float[] o=offset(12.5f+i*0.01f,9f,-30f,0f,10f,1f,0.7f+i*0.001f,1f);
                System.out.println(gust+" "+dirX+" "+dirZ+" "+o[0]+" "+o[1]+" "+o[2]); } }
    }
}
