#include <cstdio>
#include <cmath>
#include "../src/Math3D.h"
static int fails = 0;
#define CHECK(c, msg) do { if (!(c)) { std::printf("FALHOU: %s\n", msg); fails++; } } while (0)
static bool near(float a, float b, float e = 1e-4f) { return std::fabs(a - b) <= e; }
int main() {
    // câmera em (0,0,0) olhando para -Z; projeção 90° vertical, aspecto 1, near 1, far 100
    Mat4 vp = Mat4::perspective(90.0f, 1.0f, 1.0f, 100.0f) * Mat4::lookAt(0, 0, 0, 0, 0, -1);
    float c[4];
    vp.transform(0, 0, -1, c);   CHECK(near(c[2] / c[3], 0.0f), "ponto no plano near deve ter z=0");
    vp.transform(0, 0, -100, c); CHECK(near(c[2] / c[3], 1.0f), "ponto no plano far deve ter z=1");
    vp.transform(0, 1, -1, c);   CHECK(near(c[1] / c[3], -1.0f), "ponto ACIMA no mundo deve ir para y=-1 (topo da tela no Vulkan)");
    vp.transform(1, 0, -1, c);   CHECK(near(c[0] / c[3], 1.0f), "ponto à direita deve ir para x=+1");
    // frustum
    Frustum f; f.set(vp);
    CHECK(f.intersectsBox(-1, -1, -11, 1, 1, -9), "caixa na frente deve ser visível");
    CHECK(!f.intersectsBox(-1, -1, 9, 1, 1, 11), "caixa atrás deve ser descartada");
    CHECK(!f.intersectsBox(500, -1, -11, 502, 1, -9), "caixa muito à direita deve ser descartada");
    CHECK(!f.intersectsBox(-1, -1, -300, 1, 1, -200), "caixa além do far deve ser descartada");
    CHECK(f.intersectsBox(-1000, -1000, -1000, 1000, 1000, 1000), "caixa gigante que contém a câmera é visível");
    // lookAt: olhando para +X, um ponto em +X fica na frente
    Mat4 v = Mat4::lookAt(0, 0, 0, 1, 0, 0);
    v.transform(5, 0, 0, c);     CHECK(near(c[2], -5.0f), "ponto à frente da câmera tem z de vista negativo");
    // inversa: M * M^-1 = I, e desprojetar o centro da tela dá um ponto na direção da câmera
    {
        Mat4 vp2 = Mat4::perspective(67.0f, 16.0f / 9.0f, 0.4f, 1000.0f) * Mat4::lookAt(3, 5, -2, 10, 4, 20);
        Mat4 id = vp2 * vp2.inverse();
        float e = 0; for (int i = 0; i < 16; i++) e = std::fmax(e, std::fabs(id.m[i] - (i % 5 == 0 ? 1.0f : 0.0f)));
        CHECK(e < 1e-3f, "M * inversa(M) deve ser a identidade");
        Mat4 inv = vp2.inverse();
        float p4[4]; inv.transform(0, 0, 1, p4);                     // ponto do plano far no centro da tela
        float dx = p4[0] / p4[3] - 3, dy = p4[1] / p4[3] - 5, dz = p4[2] / p4[3] + 2;
        float l = std::sqrt(dx*dx + dy*dy + dz*dz);
        float fx = 7, fy = -1, fz = 22, fl = std::sqrt(fx*fx + fy*fy + fz*fz);
        CHECK(near(dx / l, fx / fl, 1e-3f) && near(dy / l, fy / fl, 1e-3f) && near(dz / l, fz / fl, 1e-3f), "centro da tela desprojetado = direção do olhar");
    }
    std::printf(fails ? "%d falha(s)\n" : "Math3D: tudo OK\n", fails);
    return fails != 0;
}
