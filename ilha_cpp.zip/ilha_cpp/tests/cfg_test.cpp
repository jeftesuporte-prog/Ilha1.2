#include "../src/Cfg.h"
#include <cstdio>
int main(){ std::printf("%g %g %lld %g\n", Cfg::CELL, Cfg::TILE, (long long)Cfg::SEED, smooth(0,10,5)); }
