#include <cstdio>
#include <cstdint>
#include <cstring>
#include <chrono>
#include "../src/Water.h"
static void w32(FILE* f, uint32_t v) { std::fwrite(&v, 4, 1, f); }
static uint32_t bitsOf(float x) { uint32_t u; std::memcpy(&u, &x, 4); return u; }
int main() {
    auto t0 = std::chrono::steady_clock::now();
    Water w;
    auto t1 = std::chrono::steady_clock::now();
    std::fprintf(stderr, "Water(): %.0f ms | plano=%zu band=%zu foam=%zu floats\n", std::chrono::duration<double, std::milli>(t1 - t0).count(),
                 w.planeVerts.size(), w.bandVerts.size(), w.foamVerts[0].size());
    Image nz = makeNoiseTexture();
    FILE* f = std::fopen("/tmp/swash_cpp.bin", "wb");
    std::fwrite(w.swashTex.rgba.data(), 1, w.swashTex.rgba.size(), f);
    std::fwrite(w.wetTex.rgba.data(), 1, w.wetTex.rgba.size(), f);
    std::fwrite(nz.rgba.data(), 1, nz.rgba.size(), f);
    std::fclose(f);
    f = std::fopen("/tmp/band_cpp.bin", "wb");
    w32(f, (uint32_t)w.bandVerts.size());
    for (float v : w.bandVerts) w32(f, bitsOf(v));
    // espuma: só as posições x,z (o Java guarda x,z de 4 cantos por segmento)
    std::vector<uint32_t> fo;
    for (int r = 0; r < 3; r++) {
        const auto& v = w.foamVerts[r];
        for (size_t q = 0; q + 54 <= v.size(); q += 54) {   // 6 vértices * 9 floats por segmento
            // ordem emitida: c00,c10,c11,c11,c01,c00
            auto X = [&](int vi) { return v[q + vi * 9 + 0]; };
            auto Z = [&](int vi) { return v[q + vi * 9 + 2]; };
            fo.push_back(bitsOf(X(0))); fo.push_back(bitsOf(Z(0)));   // c00
            fo.push_back(bitsOf(X(1))); fo.push_back(bitsOf(Z(1)));   // c10
            fo.push_back(bitsOf(X(2))); fo.push_back(bitsOf(Z(2)));   // c11
            fo.push_back(bitsOf(X(4))); fo.push_back(bitsOf(Z(4)));   // c01
        }
    }
    w32(f, (uint32_t)fo.size());
    for (uint32_t v : fo) w32(f, v);
    std::fclose(f);
}
