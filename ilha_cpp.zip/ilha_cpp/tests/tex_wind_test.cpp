#include <cstdio>
#include <string>
#include "../src/TexGen.h"
#include "../src/Wind.h"
static void w(const char* n, const TexGen::Pixels& p) {
    std::string path = std::string("/tmp/tex_cpp_") + n + ".bin";
    FILE* f = std::fopen(path.c_str(), "wb"); std::fwrite(p.data(), 1, p.size(), f); std::fclose(f);
}
int main() {
    w("grass", TexGen::grass()); w("rock", TexGen::rock(false)); w("rockmoss", TexGen::rock(true));
    w("sand", TexGen::sand()); w("forest", TexGen::forest());
    FILE* o = std::fopen("/tmp/wind_cpp.txt", "w");
    for (int i = 0; i < 6000; i++) {
        Wind::update(1.0f / 60.0f); Wind::time += 1.0f / 60.0f;
        if (i % 7 == 0) {
            Vec3 v = WindCpu::offset(12.5f + (float)i * 0.01f, 9.0f, -30.0f, 0.0f, 10.0f, 1.0f, 0.7f + (float)i * 0.001f, 1.0f);
            std::fprintf(o, "%.9g %.9g %.9g %.9g %.9g %.9g\n", Wind::gust, Wind::dirX, Wind::dirZ, v.x, v.y, v.z);
        }
    }
    std::fclose(o);
}
