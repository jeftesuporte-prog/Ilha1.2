#include <cstdio>
#include "../src/SimplexNoise.h"
int main() {
    SimplexNoise n(1337);
    for (int k = 0; k < 2000; k++) {
        double x = (k * 7.31) - 3000.0 + (k % 13) * 0.137;
        double y = (k * -3.77) + 1500.0 + (k % 7) * 0.291;
        std::printf("%.9g\n", n.noise(x * 0.01, y * 0.01));
    }
}
