// Balanço das árvores (igual ao WindGlsl.SWAY do Kotlin), versão para Vulkan GLSL 450.
// Entradas: in vec3 a_wind (x = quanto está alto na árvore, y = fase própria, z = tremor da folha)
// Uniforms: windTime, windGust, windDir. Espera `vec4 pos` já declarado. Será ligado ao pipeline na etapa 6.
{
    vec3 p0 = pos.xyz;
    float w = a_wind.x;
    float ph = a_wind.y;
    float fl = a_wind.z;
    float tt = windTime;
    float g = windGust * (0.85 + 0.15 * sin(tt * 0.6 + p0.x * 0.05 + p0.z * 0.04));
    float sw = 0.6 * sin(tt * 0.9 + ph) + 0.4 * sin(tt * 1.7 + ph * 1.9 + 1.3);
    float along = 0.03 + 0.03 * sin(tt * 0.5 + ph) + g * (0.55 + 0.25 * sw);
    float across = 0.10 * g * sin(tt * 1.3 + ph * 2.1);
    vec2 wd = windDir;
    pos.x += (wd.x * along - wd.y * across) * w;
    pos.z += (wd.y * along + wd.x * across) * w;
    float f = fl * min(1.0, w * 3.0);
    float fm = 0.12 + 0.88 * g;
    pos.x += f * 0.08 * fm * sin(tt * 3.1 + ph * 3.0 + p0.x * 0.9 + p0.z * 0.7);
    pos.z += f * 0.08 * fm * sin(tt * 2.7 + ph * 2.0 + p0.z * 0.9 + p0.x * 0.6);
    pos.y += f * 0.05 * fm * sin(tt * 4.3 + ph + p0.x * 1.1 + p0.z * 1.3);
}
