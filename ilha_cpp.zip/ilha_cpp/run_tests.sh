#!/bin/sh
# Compila o C++, roda as referências em Java (cópia fiel do Kotlin) e compara TUDO.
# Precisa de: g++, java 11+ (o "java Arquivo.java" compila sozinho), python3. Rode dentro da pasta do projeto.
set -e
ROOT=$(pwd); T=/tmp/ilha_t; mkdir -p "$T" build
CXX="g++ -std=c++17 -O2 -ffp-contract=off -pthread"
SRC="$ROOT/src/World.cpp $ROOT/src/Wind.cpp $ROOT/src/TexGen.cpp $ROOT/src/MeshAccum.cpp $ROOT/src/ChunkBuilder.cpp $ROOT/src/ChunkManager.cpp $ROOT/src/Streaming.cpp $ROOT/src/Apiario.cpp $ROOT/src/Flora.cpp $ROOT/src/Trees.cpp $ROOT/src/Props.cpp $ROOT/src/Player.cpp $ROOT/src/Hud.cpp"

# --- junta cada referência com o SimplexNoise original num arquivo só ---
join() { { echo 'import java.util.*;'; echo 'import java.io.*;'
  grep -v -e '^import ' "$1"
  sed -e '/^package/d' -e '/^import /d' -e 's/^public class SimplexNoise/class SimplexNoise/' tests/ref/SimplexNoise.java; } > "$2"; }
join tests/ref/RefWorld.java $T/RefWorld.java

echo "== compilando C++ =="
$CXX -o build/noise_test tests/noise_test.cpp
$CXX -o build/tex_wind_test tests/tex_wind_test.cpp src/TexGen.cpp src/Wind.cpp
$CXX -o build/world_test tests/world_test.cpp src/World.cpp
$CXX -o build/chunk_test tests/chunk_test.cpp $SRC
$CXX -o build/stream_test tests/stream_test.cpp $SRC
$CXX -o build/sky_test tests/sky_test.cpp src/Sky.cpp src/World.cpp
$CXX -o build/water_test tests/water_test.cpp src/Water.cpp src/World.cpp
$CXX -Isrc -o build/player_test tests/player_test.cpp $SRC
$CXX -Isrc -o build/controls_test tests/controls_test.cpp $SRC
$CXX -Isrc -o build/hud_test tests/hud_test.cpp $SRC
$CXX -Isrc -o build/game_sim_test tests/game_sim_test.cpp $SRC

echo "== rodando C++ =="
build/noise_test > $T/noise_cpp.txt
build/world_test > $T/world_cpp.txt
build/tex_wind_test; cp /tmp/wind_cpp.txt $T/wind_cpp.txt
build/chunk_test terrain
build/chunk_test > $T/coll_cpp.txt
build/sky_test > $T/sky_cpp.txt
build/water_test
build/player_test > $T/player_cpp.txt
build/player_test checks
build/controls_test
build/hud_test
build/game_sim_test

echo "== rodando referências Java =="
java $T/RefWorld.java > $T/world_java.txt
java $T/RefWorld.java terrain
java $T/RefWorld.java coll > $T/coll_java.txt
java $T/RefWorld.java sky > $T/sky_java.txt
java $T/RefWorld.java water
java $T/RefWorld.java player > $T/player_java.txt
{ echo 'import java.util.*;'; echo 'import java.io.*;'; grep -v '^import ' tests/ref/RefTex.java; } > $T/RefTex.java
java $T/RefTex.java
java tests/ref/RefWind.java > $T/wind_java.txt
{ echo 'import java.util.Random;'; sed -e '/^import com.ilha/d' tests/NoiseRef.java
  sed -e '/^package/d' -e '/^import /d' -e 's/^public class SimplexNoise/class SimplexNoise/' tests/ref/SimplexNoise.java; } > $T/NoiseRef.java
java $T/NoiseRef.java > $T/noise_java.txt

echo "== matemática 3D e controles =="
$CXX -o build/math_test tests/math_test.cpp && build/math_test

echo "== streaming e qualidade automática =="
build/stream_test

echo "== vegetação (decor, etapa 3B) =="
$CXX -Isrc -o build/decor_test tests/decor_test.cpp $SRC
build/decor_test
$CXX -Isrc -o build/props_test tests/props_test.cpp $SRC
build/props_test

echo "== comparando =="
python3 tests/compare.py
for n in grass rock rockmoss sand forest; do
  cmp /tmp/tex_java_$n.bin /tmp/tex_cpp_$n.bin && echo "OK    textura $n: idêntica byte a byte"
done
cmp /tmp/terrain_java.bin /tmp/terrain_cpp.bin && echo "OK    terreno (12 chunks): idêntico byte a byte"
cmp /tmp/swash_java.bin /tmp/swash_cpp.bin && echo "OK    texturas das ondas na praia e do reflexo: idênticas byte a byte"
cmp /tmp/band_java.bin /tmp/band_cpp.bin && echo "OK    faixa de ondas (306 mil floats) e anéis de espuma: idênticos bit a bit"
echo "TUDO IGUAL AO ORIGINAL."
