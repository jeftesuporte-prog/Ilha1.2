# Plano de portar IlhaFreeFire (Kotlin/LibGDX) -> C++ + Vulkan

Regra de fidelidade: cada módulo portado é comparado com o original (mesma entrada -> mesma saída) antes de seguir.

| Etapa | O que | Status |
|---|---|---|
| 1 | Base: Cfg, Random do Java, ruído | FEITA e verificada |
| 2 | World (ilha, rio, ponte, píer), Wind, TexGen | FEITA e verificada |
| 3A | MeshAccum, terreno por chunk, ChunkManager | FEITA e verificada |
| 4 | Android NativeActivity + Vulkan: terreno na tela, câmera, toque | escrita, NÃO compilada |
| 5A | Céu (dia/noite, sol, luz, névoa) + mar (ondas, espuma, reflexo) | lógica verificada; desenho NÃO compilado |
| S | Streaming: perfis de distância (MÍNIMO a ALTO), névoa que esconde o corte, prioridade para a frente, qualidade automática pelo FPS | FEITA e testada (lógica) |
| 3B | Vegetação (árvores, coqueiros, bananal, pomar, arbustos, pedras, cogumelos, flores) + píer, ponte e barquinho | **feita** (decor, Apiario, Flora, Trees, Props: píer, ponte e casco do barco com remos + desenho no Vulkan, ainda não compilado no NDK). Remar, amarrar e cordas do barco ficam para a etapa do boneco |
| 6 | Boneco + HUD + controles (andar, correr, colisão, subir em pedras, qualidade automática) | **feita** (Player bit a bit igual ao Java, Controls, Camera, Hud com atlas de fonte, camada 2D no Vulkan: ainda não compilada no NDK). Falta: remar/amarrar o barco |
| 7 | Frutas (cocos, maçãs, laranjas, bananas) + vento nas árvores | falta |
| 8 | Céu 5B: nuvens, estrelas, via láctea, lua, estrelas cadentes, raios do sol | falta (lógica já pronta) |
| 9 | Sombras reais do sol/lua + sombras de mancha (fallback) | falta |
| 10 | Vaga-lumes | falta |
| 11 | Sons em tempo real (folhas, grilos, mar) com AAudio/Oboe | falta |
| 12 | Desempenho, MSAA 2x, pausa/volta do app, modo imersivo | falta |
| 13 | Comparação visual lado a lado com o original e ajustes | falta |
| 14 | Acabamento: ícone, nome, assinatura, APK, GitHub Actions | falta |
| 15 | (opcional) visual melhor que o original | a combinar |

Como rodar os testes da etapa 1: ver tests/ (g++ -std=c++17).

## Etapa 2: o que foi verificado
- World: 14.641 pontos do mapa (altura, profundidade, rio, as 10 amostras de cor/bioma) + posição da ponte e do píer.
- TexGen: grama, pedra, pedra com musgo, areia e chão da floresta, 262.144 bytes cada, iguais byte a byte.
- Wind: 858 amostras de rajada/direção/deslocamento das árvores.
- Referências em tests/ref/*.java (tradução direta do Kotlin, pois não há kotlinc aqui).
- shaders/wind_sway.glsl: o balanço das árvores já em GLSL 450 para o Vulkan (entra na etapa 6).
- Não portado (era só LibGDX): WindShaderProvider/WindShader. O Vulkan terá o equivalente.

## Etapa 3A: o que foi verificado
- Terreno: 12 chunks (costa, ponte, rio, montanha, estrada...) iguais byte a byte, incluindo a subdivisão das bordas.
- ChunkManager: pushOut (colisão com troncos) e rockFloor (subir nas pedras): 20.000 pontos idênticos.
- Carregamento em 2 threads testado com detector de data race (ThreadSanitizer): sem problemas.
- O envio para a GPU é um callback (onUpload/onUnload), ligado ao Vulkan na etapa 4/5.
- Para rodar tudo: ./run_tests.sh (precisa de g++, java 11+, python3).

## Etapa 4: o que tem
- android/: projeto Gradle (Android Studio) com NativeActivity, 100% C++ (sem Kotlin/Java).
- VkEngine: instância, dispositivo, swapchain, profundidade, pipeline, 5 texturas com mipmap, descritores, 2 quadros em voo, chunks na GPU.
- main.cpp: loop do app, analógico esquerdo (andar) + arrastar à direita (olhar), câmera de 67 graus, ChunkManager ligado ao Vulkan.
- shaders/terrain.vert|frag: textura x cor do vértice x (luz do céu + sol) + névoa quadrática (igual ao libGDX).
- Testado no PC: Math3D (projeção Vulkan, lookAt, frustum) e Controls.
- NÃO testado: tudo que usa Vulkan/NDK (não há NDK nem headers do Vulkan no ambiente onde eu trabalho).

## Etapa 5A: o que foi verificado e o que não foi
- Sky: 26.018 valores (240+ instantes de um dia inteiro simulado, 760 estrelas, nuvens, estrelas cadentes) idênticos ao original.
- Water: texturas da onda na praia, areia molhada e do reflexo (ruído): idênticas byte a byte; faixa de onda (306 mil floats) e anéis de espuma: idênticos bit a bit.
- Water (textura do mar, 256x256): reproduz o Pixmap do libGDX (fillCircle e mistura em inteiros), mas não há como comparar com o libGDX aqui; deve ficar visualmente igual.
- docs/previa_ceu.png: prévia do céu em 5 horas do dia, feita com uma cópia em Python da conta do shader.
- NÃO testado: shaders (sky, water, shine) e o desenho em Vulkan.

## Streaming (distância de carregamento)
- Perfis em src/Streaming.cpp: MÍNIMO (terreno 220 m), BAIXO (290), MÉDIO (360, padrão), ALTO (430 = jogo original).
- Cada perfil também define vegetação, detalhes, sombras, vaga-lumes, névoa (menor nos níveis baixos para esconder o corte) e quantos chunks sobem por quadro.
- Qualidade automática: FPS < 32 por 4 s desce um nível; FPS > 55 por 12 s sobe um nível; se descer logo depois de subir, aquele nível fica proibido por 3 minutos.
- O que está na frente do jogador carrega antes; chunks muito distantes nem são desenhados (corte por distância no Vulkan).
- As distâncias reais do Free Fire não são públicas: os números são escolhas minhas para celular, ajustáveis na tabela.
- Ideia futura (etapa 13): terreno distante com menos triângulos (LOD).
