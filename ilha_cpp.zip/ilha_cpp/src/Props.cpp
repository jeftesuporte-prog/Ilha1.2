#include "Props.h"
#include <cmath>
#include "BarcoData.h"
#include "Cfg.h"
#include "Color.h"
#include "KMath.h"
#include "Shapes.h"
#include "World.h"

using namespace Shapes;

namespace {

float colHex(uint32_t hex) { return Pal::bits(Color::hex(hex)); }

Affine pierPlacement() {
    float theta = km::atan2(RoadNet::dirX, RoadNet::dirZ);
    Affine m;
    m.translate(RoadNet::shoreX(), 0.0f, RoadNet::shoreZ()).rotY(theta);
    return m;
}

}  // namespace

namespace Props {

std::vector<float> pier() {
    std::vector<float> out;
    const Affine m = pierPlacement();
    const float dy = Pier::TOP - 0.97f;                       // píer baixado: deck rente à areia

    const float deck = colHex(0xA9743F);
    float z = -8.0f;
    while (z < 30.0f) {
        box(out, m, deck, 0.0f, 0.9f + dy, z + 0.25f, 3.2f, 0.14f, 0.42f);
        z += 0.5f;
    }
    const float pil = colHex(0x6B3E1C);
    const float pzs[8] = {-6.0f, -1.0f, 4.0f, 9.0f, 14.0f, 19.0f, 24.0f, 29.0f};
    for (float pz : pzs) {
        for (float px : {-1.5f, 1.5f}) cylinder(out, m, pil, px, -1.5f + dy, pz, 0.4f, 6.0f, 0.4f, 8);
        box(out, m, pil, 0.0f, 0.7f + dy, pz, 3.4f, 0.15f, 0.25f);
    }
    // cunhos de madeira onde as cordas do barco amarram
    const float boll = colHex(0x5C3A1E);
    for (float lz : {BoatModel::BOLL_STERN_LZ, BoatModel::BOLL_BOW_LZ}) {
        cylinder(out, m, boll, BoatModel::BOLL_LX, Pier::TOP + 0.20f, lz, 0.20f, 0.40f, 0.20f, 10);
        cylinder(out, m, boll, BoatModel::BOLL_LX, Pier::TOP + 0.42f, lz, 0.30f, 0.07f, 0.30f, 10);   // cabeça do cunho
    }
    return out;
}

std::vector<float> bridge() {
    std::vector<float> out;
    const float theta = km::atan2(Bridge::dx(), Bridge::dz());
    const float pitch = -Bridge::pitchDeg() * 0.017453292f;   // graus -> rad (libGDX rotate(axis, graus))
    Affine m;
    m.translate(Bridge::x(), Bridge::deckY(), Bridge::z()).rotY(theta).rotX(pitch);
    const float hl = Cfg::BRIDGE_HALF_LEN, hw = Cfg::BRIDGE_HALF_W;

    const float planks = colHex(0xB07F45);
    float z = -hl + 0.25f;
    int k = 0;
    while (z < hl) {
        float tone = (k % 2 == 0) ? 0.0f : -0.05f;
        box(out, m, planks, 0.0f, -0.07f + tone * 0.2f, z, hw * 2.0f + 0.3f, 0.14f, 0.46f);
        z += 0.5f;
        k++;
    }

    const float frame = colHex(0x6B3E1C);
    for (float sx : {-1.2f, 1.2f}) box(out, m, frame, sx, -0.38f, 0.0f, 0.22f, 0.3f, hl * 2.0f);   // vigas longas por baixo
    for (float pz : {-8.0f, -2.7f, 2.7f, 8.0f})                                                      // pilares até o fundo do rio
        for (float px : {-1.4f, 1.4f}) cylinder(out, m, frame, px, -2.2f, pz, 0.38f, 4.4f, 0.38f, 8);
    float pz = -hl + 0.3f;                                                                           // postes da grade
    while (pz <= hl) {
        for (float px : {-hw, hw}) box(out, m, frame, px, 0.55f, pz, 0.16f, 1.1f, 0.16f);
        pz += 2.2f;
    }
    for (float px : {-hw, hw}) {                                                                     // corrimão e travessa do meio
        box(out, m, frame, px, 1.08f, 0.0f, 0.12f, 0.1f, hl * 2.0f);
        box(out, m, frame, px, 0.55f, 0.0f, 0.08f, 0.08f, hl * 2.0f);
    }
    return out;
}

}  // namespace Props

namespace BoatModel {

float worldX(float lx, float lz) { return RoadNet::shoreX() + lx * RoadNet::dirZ + lz * RoadNet::dirX; }
float worldZ(float lx, float lz) { return RoadNet::shoreZ() - lx * RoadNet::dirX + lz * RoadNet::dirZ; }

namespace {
// cores do barco (o número de cada face está no BarcoData.h)
const float PALETA[19][3] = {
    {0.80f, 0.58f, 0.34f}, {0.88f, 0.68f, 0.42f}, {0.66f, 0.46f, 0.27f},
    {0.72f, 0.52f, 0.31f}, {0.69f, 0.49f, 0.29f}, {0.47f, 0.31f, 0.18f},
    {0.62f, 0.42f, 0.24f}, {0.58f, 0.39f, 0.22f}, {0.55f, 0.37f, 0.21f},
    {0.52f, 0.34f, 0.19f}, {0.33f, 0.21f, 0.12f},
    // remos
    {0.62f, 0.45f, 0.28f}, {0.58f, 0.42f, 0.26f}, {0.60f, 0.43f, 0.27f},
    {0.84f, 0.68f, 0.44f}, {0.80f, 0.64f, 0.42f}, {0.50f, 0.36f, 0.22f},
    {0.55f, 0.40f, 0.25f}, {0.30f, 0.22f, 0.15f}};
constexpr float WATER_Y = 0.015f;

// um grupo de faces do modelo (casco, remo E ou remo D) transformado por m
void faces(std::vector<float>& out, const Affine& m, int first, int count) {
    for (int f = first; f < first + count; f++) {
        const int* fs = &BarcoData::FACES[f * 5];
        int k = fs[1];
        int a = fs[2] * 3, b = fs[3] * 3, c = fs[4] * 3;
        const float* vs = BarcoData::VERTICES;
        float ux = vs[b] - vs[a], uy = vs[b + 1] - vs[a + 1], uz = vs[b + 2] - vs[a + 2];
        float wx = vs[c] - vs[a], wy = vs[c + 1] - vs[a + 1], wz = vs[c + 2] - vs[a + 2];
        float nx = uy * wz - uz * wy;
        float ny = uz * wx - ux * wz;
        float nz = ux * wy - uy * wx;
        float l = km::max(km::sqrt(nx * nx + ny * ny + nz * nz), 1e-6f);
        nx /= l; ny /= l; nz /= l;
        const float* p = PALETA[km::coerceIn(k, 0, 18)];
        float cb = toFloatBits(p[0], p[1], p[2], 1.0f);
        for (int v : {a, b, c}) emit(out, m, vs[v], vs[v + 1], vs[v + 2], nx, ny, nz, cb);
    }
}
}  // namespace

Pose mooredPose() {
    Pose p;
    p.x = worldX(SLOT_LX, SLOT_LZ);
    p.z = worldZ(SLOT_LX, SLOT_LZ);
    p.yaw = km::atan2(RoadNet::dirX, RoadNet::dirZ);      // proa do barco = para o mar, como o píer
    return p;
}

void build(const Pose& p, float t, std::vector<float>& out) {
    out.clear();
    const float esc = Cfg::BARCO_ESCALA;
    const float draft = 0.17f * esc;
    // balanço nas ondas (Barco.buildPose)
    const float amp = p.moored ? 1.0f : 0.8f;
    const float heave = (0.035f * km::sin(1.35f * t + 0.6f) + 0.02f * km::sin(2.3f * t + 1.9f) + 0.012f * km::sin(3.7f * t)) * amp;
    float roll = (0.045f * km::sin(1.05f * t + 1.2f) + 0.022f * km::sin(1.9f * t + 0.3f)) * amp;
    float pitch = (0.028f * km::sin(0.95f * t + 2.2f) + 0.015f * km::sin(1.7f * t + 0.4f)) * amp;
    roll += -p.w * 0.08f * km::min(1.0f, km::abs(p.v));      // inclina um pouco na curva
    pitch += -0.012f * p.v;                                   // proa sobe um pouco com a velocidade
    const float y = WATER_Y - draft + heave;

    Affine body;
    body.translate(p.x, y, p.z).rotY(p.yaw).rotZ(roll).rotX(pitch);
    Affine hull = body;
    hull.scale(esc);
    faces(out, hull, 0, BarcoData::FACES_CASCO);

    // remos (Barco.oar): balançam em torno do encaixe no casco
    auto oar = [&](float side, float ef, int first, int count) {
        float u = p.phase;
        float sweepStroke = -0.42f * km::cos(6.2831855f * u);
        float liftStroke = (u < 0.5f ? 0.0f : 0.38f * km::sin(3.1415927f * (u - 0.5f) / 0.5f)) - 0.08f;
        float sw = 0.0f + (sweepStroke - 0.0f) * ef;
        float lf = 0.25f + (liftStroke - 0.25f) * ef;
        Affine o = body;
        o.scale(esc);
        o.translate(side * 0.70f, 0.60f, -0.42f);
        o.rotY(side * sw);
        o.rotZ(side * lf);
        o.translate(-side * 0.70f, -0.60f, 0.42f);
        faces(out, o, first, count);
    };
    oar(-1.0f, p.efNeg, BarcoData::FACES_CASCO, BarcoData::FACES_REMO_E);
    oar(1.0f, p.efPos, BarcoData::FACES_CASCO + BarcoData::FACES_REMO_E, BarcoData::FACES_REMO_D);
}

}  // namespace BoatModel
