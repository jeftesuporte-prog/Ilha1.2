#pragma once
// Port 1:1 de MeshAccum.kt. Acumula triângulos "soltos" (3 vértices por triângulo => flat shading low-poly).
// Vértice: x y z | nx ny nz | cor empacotada | u v  (9 floats). stride 7 = sem UV; stride 10 = com dados de vento.
// Quebra em várias partes de no máximo MAXV vértices.
#include <vector>

class MeshAccum {
public:
    static constexpr int MAXV = 30000;
    static constexpr int STRIDE = 9;

    explicit MeshAccum(int stride = STRIDE) : stride_(stride), buf_(static_cast<size_t>(MAXV) * stride) {}

    // vento (só quando stride == 10)
    float windBaseY = 0.0f;
    float windH = 1.0f;
    float windPhase = 0.0f;
    float windFlutter = 0.0f;
    float windAmp = 1.0f;

    void tri(float ax, float ay, float az, float bx, float by, float bz, float cx, float cy, float cz, float col);
    void triOut(float ax, float ay, float az, float bx, float by, float bz, float cx, float cy, float cz,
                float ox, float oy, float oz, float col);
    void triOutUV(float ax, float ay, float az, float bx, float by, float bz, float cx, float cy, float cz,
                  float ox, float oy, float oz, float col, bool uv);
    void triN(float ax, float ay, float az, float bx, float by, float bz, float cx, float cy, float cz,
              float nx, float ny, float nz, float col);
    void triVC(float ax, float ay, float az, float ca, float ua, float va,
               float bx, float by, float bz, float cb, float ub, float vb,
               float cx, float cy, float cz, float cc, float uc, float vc,
               float nx, float ny, float nz);

    std::vector<std::vector<float>> finish();

private:
    void put(float x, float y, float z, float nx, float ny, float nz, float c, float u, float v);
    void flush();

    int stride_;
    std::vector<std::vector<float>> parts_;
    std::vector<float> buf_;
    int nv_ = 0;
};
