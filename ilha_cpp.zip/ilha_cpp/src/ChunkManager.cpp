#include "ChunkManager.h"
#include "Apiario.h"
#include <algorithm>
#include "Cfg.h"
#include "KMath.h"

ChunkManager::ChunkManager() : n_(Cfg::CHUNKS) {
    for (int t = 0; t < 2; t++) {
        pool_.emplace_back([this] {
            for (;;) {
                std::pair<int, int> job;
                {
                    std::unique_lock<std::mutex> lk(workMu_);
                    workCv_.wait(lk, [this] { return stop_ || !work_.empty(); });
                    if (stop_) return;
                    job = work_.front();
                    work_.pop_front();
                }
                Built b = build(job.first, job.second);
                std::lock_guard<std::mutex> lk(mu_);
                ready_.push_back(std::move(b));
            }
        });
    }
}

ChunkManager::~ChunkManager() {
    {
        std::lock_guard<std::mutex> lk(workMu_);
        stop_ = true;
    }
    workCv_.notify_all();
    for (auto& t : pool_) t.join();
}

float ChunkManager::distTo(int key, float px, float pz) {
    const int n = Cfg::CHUNKS;
    int cx = key % n;
    int cz = key / n;
    float mx = static_cast<float>(cx) * Cfg::CHUNK - Cfg::HALF + Cfg::CHUNK / 2.0f;
    float mz = static_cast<float>(cz) * Cfg::CHUNK - Cfg::HALF + Cfg::CHUNK / 2.0f;
    return km::hypot(mx - px, mz - pz);
}

Built ChunkManager::build(int layer, int key) {
    const int n = Cfg::CHUNKS;
    return layer == 0 ? ChunkBuilder::terrain(key % n, key / n) : ChunkBuilder::decor(key % n, key / n);
}

void ChunkManager::warmup(float px, float pz, float radius) {
    for (int layer = 0; layer <= 1; layer++) for (int key = 0; key < n_ * n_; key++) {
        if (distTo(key, px, pz) < radius && !loaded_[layer].count(key)) upload(build(layer, key));
    }
}

void ChunkManager::update(float px, float pz, float dirX, float dirZ) {
    for (int layer = 0; layer <= 1; layer++) {
        float rLoad = layer == 0 ? profile_.terrainR : profile_.decoR;
        float rKeep = rLoad + profile_.keepExtra;
        const size_t cap = static_cast<size_t>(layer == 0 ? profile_.maxTerrainChunks : profile_.maxDecoChunks);

        std::vector<std::pair<float, int>> want;
        for (int key = 0; key < n_ * n_; key++) {
            float d = distTo(key, px, pz);
            if (d < rLoad && !loaded_[layer].count(key) && !pending_[layer].count(key)) {
                float mx = static_cast<float>(key % n_) * Cfg::CHUNK - Cfg::HALF + Cfg::CHUNK / 2.0f;
                float mz = static_cast<float>(key / n_) * Cfg::CHUNK - Cfg::HALF + Cfg::CHUNK / 2.0f;
                want.emplace_back(Streaming::priority(d, mx - px, mz - pz, dirX, dirZ), key);
            }
        }
        std::stable_sort(want.begin(), want.end(), [](const auto& a, const auto& b) { return a.first < b.first; });
        for (const auto& w : want) {
            if (pending_[layer].size() >= static_cast<size_t>(profile_.maxPending)) break;
            if (loaded_[layer].size() + pending_[layer].size() >= cap) break;        // teto de memória
            int key = w.second;
            pending_[layer].insert(key);
            {
                std::lock_guard<std::mutex> lk(workMu_);
                work_.emplace_back(layer, key);
            }
            workCv_.notify_one();
        }

        for (auto it = loaded_[layer].begin(); it != loaded_[layer].end();) {
            if (distTo(*it, px, pz) > rKeep) {
                int key = *it;
                if (onUnload) onUnload(layer, key);
                if (layer == 1) { solids.erase(key); rockMap.erase(key); }
                it = loaded_[layer].erase(it);
            } else {
                ++it;
            }
        }
    }

    int budget = profile_.uploadsPerFrame;               // uploads por quadro (limita o engasgo)
    while (budget > 0) {
        Built b;
        {
            std::lock_guard<std::mutex> lk(mu_);
            if (ready_.empty()) break;
            b = std::move(ready_.front());
            ready_.pop_front();
        }
        float rKeep = (b.layer == 0 ? profile_.terrainR : profile_.decoR) + profile_.keepExtra;
        pending_[b.layer].erase(b.key);
        if (distTo(b.key, px, pz) <= rKeep) upload(b);
        budget--;
    }
}

void ChunkManager::upload(const Built& b) {
    int layer = b.layer;
    if (loaded_[layer].count(b.key)) return;
    if (onUpload) onUpload(b);
    loaded_[layer].insert(b.key);
    if (!b.solids.empty() || layer == 1) solids[b.key] = b.solids;
    if (!b.rocks.empty()) rockMap[b.key] = b.rocks;
}

void ChunkManager::pushOutSolids(float out[2], float pr) const {
    const int n = n_;
    int ccx = static_cast<int>(std::floor((out[0] + Cfg::HALF) / Cfg::CHUNK));
    int ccz = static_cast<int>(std::floor((out[1] + Cfg::HALF) / Cfg::CHUNK));
    for (int pass = 0; pass < 2; pass++) {
        for (int j = ccz - 1; j <= ccz + 1; j++) for (int i = ccx - 1; i <= ccx + 1; i++) {
            if (i < 0 || j < 0 || i >= n || j >= n) continue;
            auto it = solids.find(j * n + i);
            if (it == solids.end()) continue;
            const std::vector<float>& arr = it->second;
            size_t k = 0;
            while (k < arr.size()) {
                float sx = arr[k];
                float sz = arr[k + 1];
                float rr = arr[k + 2] + pr;
                float dx = out[0] - sx;
                float dz = out[1] - sz;
                float d2 = dx * dx + dz * dz;
                if (d2 < rr * rr) {
                    if (d2 < 1e-6f) {
                        out[0] = sx + rr;
                    } else {
                        float d = km::sqrt(d2);
                        out[0] = sx + dx / d * rr;
                        out[1] = sz + dz / d * rr;
                    }
                }
                k += 3;
            }
        }
    }
}

void ChunkManager::pushOut(float out[2], float pr) const {
    pushOutSolids(out, pr);
    Apiario::pushOut(out, pr);                         // colmeias também são sólidas
}

float ChunkManager::rockFloor(float x, float z, float base) const {
    const int n = n_;
    float h = base;
    int ccx = static_cast<int>(std::floor((x + Cfg::HALF) / Cfg::CHUNK));
    int ccz = static_cast<int>(std::floor((z + Cfg::HALF) / Cfg::CHUNK));
    for (int j = ccz - 1; j <= ccz + 1; j++) for (int i = ccx - 1; i <= ccx + 1; i++) {
        if (i < 0 || j < 0 || i >= n || j >= n) continue;
        auto it = rockMap.find(j * n + i);
        if (it == rockMap.end()) continue;
        const std::vector<float>& arr = it->second;
        size_t k = 0;
        while (k + 4 < arr.size()) {
            float dx = x - arr[k];
            float dz = z - arr[k + 1];
            float cy = arr[k + 2];
            float re = arr[k + 3] * 0.9f;
            float ry = arr[k + 4] * 0.85f;
            k += 5;
            float d = km::sqrt(dx * dx + dz * dz);
            if (d < re) {
                float q = d / re;
                float top = cy + ry * km::sqrt(1.0f - q * q);
                if (top > h) h = top;
            } else if (d < re * 1.3f) {
                float t = 1.0f - (d - re) / (re * 0.3f);          // rampa da beirada até o "equador" da pedra
                float top = base + (cy - base) * t;
                if (top > h) h = top;
            }
        }
    }
    return h;
}
