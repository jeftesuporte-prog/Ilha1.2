#pragma once
// Port de ChunkManager.kt (parte lógica). Chunk loading estilo battle royale: o mundo de 1 km² é cortado em 10x10 chunks
// de 100 m. Camada 0 = terreno (raio grande), camada 1 = árvores/pedras/flores (raio menor).
// Os vértices são montados em threads de fundo; só o "upload" roda na thread principal.
// O upload para a GPU (Vulkan) e os sistemas de frutas ficam em callbacks (etapas 4 a 6): a lógica daqui não depende de GPU.
#include <condition_variable>
#include <deque>
#include <functional>
#include <mutex>
#include <thread>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include "ChunkBuilder.h"
#include "Streaming.h"

// O que o boneco (e as frutas) precisa saber do mundo sólido: troncos, pedras, colmeias.
struct Colliders {
    virtual ~Colliders() = default;
    virtual void pushOut(float out[2], float pr) const = 0;
    virtual float rockFloor(float x, float z, float base) const = 0;
};

class ChunkManager : public Colliders {
public:
    ChunkManager();
    ~ChunkManager();
    ChunkManager(const ChunkManager&) = delete;
    ChunkManager& operator=(const ChunkManager&) = delete;

    // Chamado na thread principal quando um chunk fica pronto (cria os buffers do Vulkan, registra frutas etc.).
    std::function<void(const Built&)> onUpload;
    // Chamado na thread principal quando um chunk sai de perto do jogador (libera buffers, remove frutas etc.).
    std::function<void(int layer, int key)> onUnload;

    // círculos de colisão (troncos e pedras) por chunk de vegetação: x,z,raio
    std::unordered_map<int, std::vector<float>> solids;
    // pedras grandes por chunk de vegetação: x,z,yCentro,raio,meiaAltura (o boneco anda em cima delas)
    std::unordered_map<int, std::vector<float>> rockMap;

    int terrainChunks() const { return static_cast<int>(loaded_[0].size()); }
    int decoChunks() const { return static_cast<int>(loaded_[1].size()); }

    // Carrega na hora (thread principal) tudo perto do jogador, pra não abrir o jogo com mundo vazio.
    void warmup(float px, float pz, float radius);
    // (dirX,dirZ) = para onde o jogador olha: o que está na frente carrega primeiro (0,0 = só distância).
    void update(float px, float pz, float dirX = 0.0f, float dirZ = 0.0f);

    // Troca os raios de carregamento (qualidade automática). Chunks fora do novo raio saem no próximo update.
    void setProfile(const StreamProfile& p) { profile_ = p; }
    const StreamProfile& profile() const { return profile_; }

    // Empurra o ponto out[0],out[1] (x,z) para fora de qualquer tronco/pedra a menos de `pr` metros (2 passadas)
    // e das colmeias (Apiario.pushOut): é o pushOut do original.
    void pushOut(float out[2], float pr) const override;
    // Só a parte dos troncos e pedras (sem as colmeias): o que a referência em Java compara byte a byte.
    void pushOutSolids(float out[2], float pr) const;
    // Altura do chão em (x,z) contando as pedras grandes (sem parede invisível: o boneco sobe em QUALQUER pedra).
    float rockFloor(float x, float z, float base) const override;

    static float distTo(int key, float px, float pz);

private:
    static Built build(int layer, int key);
    void upload(const Built& b);

    int n_;
    StreamProfile profile_ = Streaming::profile(3);   // padrão = valores do jogo original
    std::unordered_set<int> loaded_[2];
    std::unordered_set<int> pending_[2];

    // fila de chunks prontos (preenchida pelas threads de fundo)
    std::mutex mu_;
    std::deque<Built> ready_;
    // fila de trabalho + 2 threads
    std::mutex workMu_;
    std::condition_variable workCv_;
    std::deque<std::pair<int, int>> work_;   // (layer, key)
    std::vector<std::thread> pool_;
    bool stop_ = false;
};
