#pragma once
// Port 1:1 de Cfg.kt. 1 unidade do mundo = 1 METRO. O boneco tem 1.75 m e é a régua de tudo.
#include <algorithm>
#include <cstdint>

namespace Cfg {

constexpr float WORLD = 1000.0f;  // mapa 1000 x 1000 m (1 km²)
constexpr float HALF = 500.0f;
constexpr float CHUNK = 100.0f;  // cada chunk = 100 x 100 m  -> 10 x 10 chunks
constexpr int CHUNKS = 10;
constexpr int CELLS = 40;  // células por chunk (2.5 m cada)
constexpr float CELL = CHUNK / CELLS;

constexpr float PLAYER_H = 1.75f;
constexpr float BEACH = 40.0f;  // praia larga de 40 m em volta toda

// ilha oval (semi-eixos em metros, antes do ruído que deixa a costa orgânica)
constexpr float A = 430.0f;
constexpr float B = 380.0f;

constexpr float MAIN_H = 210.0f;  // montanha principal (180-220 m)
constexpr float MAIN_R = 150.0f;  // raio da base = 150 m  -> 300 m de largura

constexpr float ROAD_W = 7.5f;  // estrada de 7,5 m (passa carro; era 6 m)
constexpr float TREE_SPACING = 6.5f;  // 1 árvore grande (copa ~7 m) a cada ~9 m; menor = floresta mais cheia (e mais pesada)
constexpr bool FOLHAS_SOLTAS = false;  // false = copas lisinhas (sem as folhinhas/quadradinhos verdes saindo, mais leve); true = folhinhas de volta
constexpr float FLORES = 1.0f;  // quantidade de flores (1 = normal, 0.5 = metade, 0 = sem flores)
constexpr float COGUMELOS = 1.0f;  // quantidade de cogumelos (1 = normal, 0 = sem)
constexpr float LEAF_DETAIL = 1.0f;  // 1 = todas as folhas (igual às imagens); 0.5 = metade das folhas (celular fraco)

constexpr float TERRAIN_R = 430.0f;  // raio de carregamento do terreno
constexpr float DECO_R = 250.0f;  // raio de carregamento de árvores/pedras/flores

constexpr float DAY_SECONDS = 600.0f;  // 24 h do jogo = 10 min reais
constexpr float START_HOUR = 6.2f;  // começa no amanhecer rosa
constexpr bool SHADOWS = false;  // sombras do sol: DESLIGADAS (causavam as listras rosa/amarelas nas árvores)
constexpr float TILE = 6.25f;  // 1 repetição de textura = 6.25 m (100 m / 16, emenda perfeita entre chunks)

// rio + ponte (a ponte fica na estrada, no meio da floresta)
constexpr float RIVER_HALF = 5.0f;  // rio com 10 m de largura
constexpr float RIVER_BANK = 7.0f;  // barranco suave de 7 m (dá para sair andando)
constexpr float RIVER_BED = -1.3f;  // fundo do rio (abaixo do nível do mar = tem água)
constexpr float BRIDGE_HALF_LEN = 13.0f;  // ponte com 26 m de comprimento
constexpr float BRIDGE_HALF_W = 1.7f;  // 3.4 m de largura (grade nas bordas)
constexpr bool PAREDES_INVISIVEIS = false;  // false = SEM paredes invisíveis: sem limite de mapa, nada de barreira em água funda/rio, sobe qualquer encosta (true = como era antes)
constexpr bool VENTO = true;  // false = desliga o balanco das arvores (shader de vento): use para testar se algo fecha o jogo
constexpr bool SOM_MATA = true;  // false = desliga os sons da mata (folhas, vento nos galhos, grilos)
constexpr float SEA_SOUND_REF = 15.0f;  // som do mar: a esta distância (m) da água o volume cai pela metade (quanto maior, mais longe se ouve)
constexpr float SEA_SOUND_MAX = 60.0f;  // som do mar: some por completo a esta distância (m) da água
constexpr float SWIM_Y = -1.3f;  // altura dos pés ao nadar em água funda (cabeça fica fora d'água)
constexpr float WADE_LIMIT = -1.9f;  // fundo mais fundo que isso = boneco (1.75 m) some debaixo d'água: não passa mais
constexpr float GROVE_X = 50.0f;  // bananal: onde ficava a menor das 6 montanhas
constexpr float GROVE_Z = 230.0f;
constexpr float GROVE_R = 75.0f;
constexpr float ORCHARD_X = 240.0f;  // pomar de maçã/laranja: onde ficava a montanha de 70 m
constexpr float ORCHARD_Z = -170.0f;
constexpr float ORCHARD_R = 70.0f;
constexpr float PLAYER_R = 0.35f;  // raio do boneco para colisão

// ---- ciclo do coco (7 dias): dias 1-3 crescem, dia 4-5 verde maduro, dia 6 marrom, dia 7 cai; dia 8 = dia 1 de novo ----
constexpr float COCO_DIA_SEGUNDOS = 600.0f;  // segundos REAIS de 1 dia do coco (600 = igual ao dia do jogo; use 30 para testar rapido)
constexpr bool COCO_SINCRONIZADO = false;  // false = cada coqueiro numa fase diferente (sempre tem coco em todas as fases); true = todos comecam no dia 1
constexpr float COCO_RAIO = 130.0f;  // so anima/desenha coco a ate esta distancia (m): poupa o celular
constexpr bool SOM_COCO = true;  // som do coco batendo na areia

// ---- macas (ver Frutas.kt): ciclo de 5 dias do jogo (verde 2 dias -> vermelha dia 3 -> podre e cai no dia 5 -> some do chao em 9 dias)
constexpr float MACA_DIA_SEGUNDOS = 600.0f;  // segundos REAIS de 1 dia da maca (600 = igual ao dia do jogo; use 30 para testar rapido)
constexpr float MACA_RAIO = 110.0f;  // so anima/desenha maca a ate esta distancia (m): poupa o celular
constexpr bool SOM_MACA = true;  // som da maca batendo na grama

// ---- laranjas (ver Frutas.kt / FrutaSpec.LARANJA): nasce grande e verde, amadurece no dia 5, apodrece e cai no meio do dia 7, some do chao no meio do dia 9
constexpr float LARANJA_DIA_SEGUNDOS = 600.0f;  // segundos REAIS de 1 dia da laranja (use 30 para testar rapido)
constexpr float LARANJA_RAIO = 100.0f;  // so anima/desenha laranja a ate esta distancia (m)

// ---- bananeiras (ver Bananas.kt): coracao nos dias 1-2, cacho sai no dia 3, coracao cai no dia 5, bananas amarelas no dia 7
constexpr float BANANA_DIA_SEGUNDOS = 600.0f;  // segundos REAIS de 1 dia da bananeira (use 30 para testar rapido)
constexpr float BANANA_RAIO = 80.0f;  // so anima/desenha bananeira a ate esta distancia (m)

// ---- sombras suaves no chao (BlobShadows.kt): manchas macias sob arvores, pedras e boneco (a sombra "de verdade" SHADOWS segue desligada)
constexpr float SOMBRA_RAIO = 75.0f;  // so desenha sombra a ate esta distancia (m)

// ---- SOMBRAS REAIS (RealShadows.kt): sombra com o formato do objeto, que acompanha o sol (e a lua de noite)
constexpr bool SOMBRA_REAL = true;  // false = volta para as manchas redondas (BlobShadows)
constexpr int SOMBRA_MAPA = 2048;  // resolucao do mapa de sombra (2048 = nitida; 1024 = mais leve). Se o FPS cair, baixa sozinho
constexpr float SOMBRA_RAIO_MAPA = 55.0f;  // metros em volta do boneco que recebem sombra (area = 2x isso). Maior = sombra mais longe, mais serrilhada
constexpr float SOMBRA_PROF = 260.0f;  // faixa de profundidade (m) do mapa: cobre morro e arvore alta
constexpr float SOMBRA_FORCA = 1.0f;  // 1 = sombra natural; 0.6 = mais suave; 1.3 = mais escura
constexpr float SOMBRA_ELEV_MIN = 0.20f;  // sol muito baixo estica a sombra; trava em ~11 graus (sombra de ~5x a altura)
constexpr float SOMBRA_SUAVE = 1.4f;  // maciez da borda da sombra (em texels). Maior = borda mais borrada
constexpr float SOMBRA_BIAS = 0.12f;  // folga (m) contra falha na base do tronco/pes do boneco

// ---- vaga-lumes (Fireflies.kt): so de noite, muitos na mata, medio no campo, quase nenhum na praia
constexpr bool VAGALUME = true;  // false = desliga os vaga-lumes (teste se algo fecha o jogo)
constexpr float VAGALUME_RAIO = 70.0f;  // so existem a ate esta distancia (m) do boneco (menor = mais leve)
constexpr float VAGALUME_DENS = 1.0f;  // quantidade geral: 1 = normal, 0.5 = metade, 1.5 = mais cheio
constexpr float VAGALUME_TAMANHO = 1.5f;  // 1 = tamanho real (1,3 cm); 1.5 = um pouco maior para dar para ver o bichinho de perto

// ---- borboletas (Butterflies.kt): so de dia, 8 cores, pousam e voam sozinhas
constexpr bool BORBOLETA = true;
constexpr int BORBOLETA_MAX = 28;
constexpr float BORBOLETA_RAIO = 60.0f;
constexpr float BORBOLETA_TAMANHO = 3.3f;

// ---- colmeias e abelhas (Apiario.kt, Colmeias.kt, Abelhas.kt) ----
constexpr int COLMEIAS = 25;  // quantas colmeias no mapa (0 = nenhuma: tambem some os prados de flores delas)
constexpr int ABELHAS_POR_COLMEIA = 14;
constexpr float ABELHA_TAMANHO = 6.5f;
constexpr bool ABELHAS = true;

// ---- barco do pier (Barco.kt) ----
constexpr float BARCO_VELOCIDADE = 2.0f;
constexpr float BARCO_ESCALA = 1.3f;

// ---- NÃO existe no Kotlin: interruptor do port ----
// O original tem um bug: na ponta da folha de bananeira, sin(pi) em float dá -8.7e-8 e pow(negativo, 0.65) = NaN,
// então o último pedaço de CADA folha some (a folha fica com a ponta cortada). false = igual ao original (ponta cortada);
// true = corrige: a ponta é desenhada (afinando, como o autor provavelmente queria).
constexpr bool BANANA_PONTA_CORRIGIDA = false;

constexpr int64_t SEED = 1337;

}  // namespace Cfg

inline float smooth(float e0, float e1, float x) {
    float t = std::min(std::max((x - e0) / (e1 - e0), 0.0f), 1.0f);
    return t * t * (3.0f - 2.0f * t);
}
