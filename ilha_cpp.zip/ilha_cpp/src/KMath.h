#pragma once
// Funções com a MESMA semântica do kotlin.math para Float: calculam em double e arredondam para float
// (é o que a JVM faz). Evita diferenças de 1 ulp entre sinf/cosf do C++ e o Math.sin do Java.
#include <cmath>

struct Vec3 { float x, y, z; };

namespace km {
inline float sin(float x)   { return static_cast<float>(std::sin(static_cast<double>(x))); }
inline float cos(float x)   { return static_cast<float>(std::cos(static_cast<double>(x))); }
inline float sqrt(float x)  { return static_cast<float>(std::sqrt(static_cast<double>(x))); }
inline float atan2(float y, float x) { return static_cast<float>(std::atan2(static_cast<double>(y), static_cast<double>(x))); }
inline float hypot(float a, float b) { return static_cast<float>(std::hypot(static_cast<double>(a), static_cast<double>(b))); }
inline float pow(float a, float b)   { return static_cast<float>(std::pow(static_cast<double>(a), static_cast<double>(b))); }
inline float abs(float x)   { return std::fabs(x); }
inline float floor(float x) { return static_cast<float>(std::floor(static_cast<double>(x))); }
inline float ceil(float x)  { return static_cast<float>(std::ceil(static_cast<double>(x))); }
inline float max(float a, float b) { return a >= b ? a : b; }   // (sem NaN no jogo)
inline float min(float a, float b) { return a <= b ? a : b; }
// Float.coerceIn(lo, hi) do Kotlin
inline float coerceIn(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline int   coerceIn(int v, int lo, int hi)       { return v < lo ? lo : (v > hi ? hi : v); }
}  // namespace km
