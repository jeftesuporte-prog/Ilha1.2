#pragma once
// Vértice da camada 2D (HUD): posição em pixels (y para baixo), UV no atlas de fonte e cor RGBA8.
#include <cstdint>
struct HudVertex {
    float x, y, u, v;
    uint32_t rgba;   // R no byte baixo (R8G8B8A8_UNORM)
};
static_assert(sizeof(HudVertex) == 20, "HudVertex precisa ter 20 bytes");
