#pragma once
// Reimplementação exata do java.util.Random (LCG de 48 bits), para o ruído sair idêntico ao do Kotlin/Java.
#include <cstdint>

class JavaRandom {
public:
    explicit JavaRandom(int64_t seed) { setSeed(seed); }

    void setSeed(int64_t seed) {
        seed_ = (static_cast<uint64_t>(seed) ^ 0x5DEECE66DULL) & MASK;
    }

    int32_t next(int bits) {
        seed_ = (seed_ * 0x5DEECE66DULL + 0xBULL) & MASK;
        return static_cast<int32_t>(static_cast<int64_t>(seed_) >> (48 - bits));
    }

    // java.util.Random.nextLong(): (next(32) << 32) + next(32)
    int64_t nextLong() {
        int64_t hi = static_cast<int64_t>(next(32));
        int64_t lo = static_cast<int64_t>(next(32));
        return static_cast<int64_t>(static_cast<uint64_t>(hi) << 32) + lo;
    }

    // java.util.Random.nextFloat() (JDK 17+): next(24) / 2^24
    float nextFloat() { return static_cast<float>(next(24)) / static_cast<float>(1 << 24); }

    int32_t nextInt(int32_t bound) {
        int32_t r = next(31);
        int32_t m = bound - 1;
        if ((bound & m) == 0) {
            r = static_cast<int32_t>((static_cast<int64_t>(bound) * static_cast<int64_t>(r)) >> 31);
        } else {
            for (int32_t u = r; u - (r = u % bound) + m < 0; u = next(31)) {}
        }
        return r;
    }

private:
    static constexpr uint64_t MASK = (1ULL << 48) - 1;
    uint64_t seed_;
};
