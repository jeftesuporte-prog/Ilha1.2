#pragma once
// Port de ChunkBuilder.kt. Constrói os dados de vértices de um chunk (roda em thread de fundo; só funções puras).
#include <vector>
#include "MeshAccum.h"

// mats[i] = índice do material da parte i (ver ChunkMat). solids = círculos de colisão (x,z,raio).
struct Built {
    int layer = 0;
    int key = 0;
    std::vector<std::vector<float>> parts;
    std::vector<int> mats;
    float minY = 0.0f, maxY = 0.0f;
    std::vector<float> solids;     // círculos de colisão: x, z, raio
    std::vector<float> rocks;      // pedras grandes andáveis: x, z, y do centro, raio, meia-altura (5 floats cada)
    std::vector<float> palms;      // cocos (12 floats cada, ver Coconuts.kt)
    std::vector<float> macas;      // maçãs (12 floats cada, ver Frutas.kt)
    std::vector<float> laranjas;   // laranjas (12 floats cada)
    std::vector<float> bananas;    // cachos de banana (12 floats cada, ver Bananas.kt)
};

namespace ChunkBuilder {
// Terreno do chunk (cx, cz): 5 materiais (areia, grama, pedra, pedra c/ musgo, chão de floresta).
Built terrain(int cx, int cz);
// Vegetação, pedras, flores e frutas do chunk. (etapa 3B: por enquanto devolve um chunk vazio)
Built decor(int cx, int cz);
}
