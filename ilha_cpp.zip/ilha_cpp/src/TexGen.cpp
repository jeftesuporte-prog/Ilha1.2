#include "TexGen.h"
#include "JavaRandom.h"
#include "KMath.h"

using km::coerceIn;

namespace TexGen {
namespace {
// ---------------- ruído periódico (tileável) ----------------
// Aritmética de 32 bits com "wrap", igual ao Int do Kotlin (feita em uint32 para não ter comportamento indefinido).
float hash(int i, int j, int seed) {
    uint32_t h = static_cast<uint32_t>(i) * 374761393u + static_cast<uint32_t>(j) * 668265263u + static_cast<uint32_t>(seed) * 362437u;
    h = (h ^ (h >> 13)) * 1274126177u;
    h = h ^ (h >> 16);
    return static_cast<float>(h & 0xFFFFu) / 65535.0f;
}

int wrap(int a, int per) { return ((a % per) + per) % per; }

float vnoise(float u, float v, int perX, int perY, int seed) {
    float x = u * static_cast<float>(perX);
    float y = v * static_cast<float>(perY);
    int xi = static_cast<int>(km::floor(x));
    int yi = static_cast<int>(km::floor(y));
    float fx = x - static_cast<float>(xi);
    float fy = y - static_cast<float>(yi);
    float sx = fx * fx * (3.0f - 2.0f * fx);
    float sy = fy * fy * (3.0f - 2.0f * fy);
    int x0 = wrap(xi, perX), x1 = wrap(xi + 1, perX);
    int y0 = wrap(yi, perY), y1 = wrap(yi + 1, perY);
    float a = hash(x0, y0, seed);
    float b = hash(x1, y0, seed);
    float c = hash(x0, y1, seed);
    float d = hash(x1, y1, seed);
    float top = a + (b - a) * sx;
    float bot = c + (d - c) * sx;
    return top + (bot - top) * sy;
}

float fbm(float u, float v, int per, int oct, int seed) {
    float amp = 0.5f, sum = 0.0f, norm = 0.0f;
    int p = per;
    for (int o = 0; o < oct; o++) {
        sum += vnoise(u, v, p, p, seed + o * 17) * amp;
        norm += amp;
        amp *= 0.5f;
        p *= 2;
    }
    return sum / norm;
}

float lerp(float a, float b, float t) { return a + (b - a) * t; }
float sstep(float e0, float e1, float x) {
    float t = coerceIn((x - e0) / (e1 - e0), 0.0f, 1.0f);
    return t * t * (3.0f - 2.0f * t);
}

// ---------------- "tela" de pixels ----------------
struct Canvas {
    std::vector<float> r, g, b;
    Canvas() : r(S * S), g(S * S), b(S * S) {}

    void set(int x, int y, float cr, float cg, float cb) {
        int i = (y & (S - 1)) * S + (x & (S - 1));
        r[i] = cr; g[i] = cg; b[i] = cb;
    }
    void blend(int x, int y, float cr, float cg, float cb, float a) {
        int i = (y & (S - 1)) * S + (x & (S - 1));
        r[i] += (cr - r[i]) * a;
        g[i] += (cg - g[i]) * a;
        b[i] += (cb - b[i]) * a;
    }
    // elipse girada (folhas, pedrinhas, manchas)
    void ellipse(float cx, float cy, float len, float wid, float ang, float cr, float cg, float cb, float a) {
        float ca = km::cos(ang);
        float sa = km::sin(ang);
        int m = static_cast<int>(km::ceil(km::max(len, wid))) + 1;
        for (int dy = -m; dy <= m; dy++) for (int dx = -m; dx <= m; dx++) {
            float xr = static_cast<float>(dx) * ca + static_cast<float>(dy) * sa;
            float yr = -static_cast<float>(dx) * sa + static_cast<float>(dy) * ca;
            float e = (xr * xr) / (len * len) + (yr * yr) / (wid * wid);
            if (e <= 1.0f) blend(static_cast<int>(cx) + dx, static_cast<int>(cy) + dy, cr, cg, cb, a);
        }
    }
    // Color.rgba8888 do libGDX: (int)(c*255) com truncamento
    Pixels toPixels() const {
        Pixels out(static_cast<size_t>(S) * S * 4);
        for (int i = 0; i < S * S; i++) {
            out[i * 4 + 0] = static_cast<uint8_t>(static_cast<int>(coerceIn(r[i], 0.0f, 1.0f) * 255.0f));
            out[i * 4 + 1] = static_cast<uint8_t>(static_cast<int>(coerceIn(g[i], 0.0f, 1.0f) * 255.0f));
            out[i * 4 + 2] = static_cast<uint8_t>(static_cast<int>(coerceIn(b[i], 0.0f, 1.0f) * 255.0f));
            out[i * 4 + 3] = 255;
        }
        return out;
    }
};
}  // namespace

// =====================================================================
//  GRAMA  #5DBB35
// =====================================================================
Pixels grass() {
    Canvas c;
    JavaRandom rnd(11);
    for (int y = 0; y < S; y++) for (int x = 0; x < S; x++) {
        float u = (static_cast<float>(x) + 0.5f) / static_cast<float>(S);
        float v = (static_cast<float>(y) + 0.5f) / static_cast<float>(S);
        float big = sstep(0.28f, 0.72f, fbm(u, v, 3, 4, 1));
        float mid = fbm(u, v, 12, 3, 2);
        float cr, cg, cb;
        if (big < 0.5f) {
            float t = big * 2.0f;
            cr = lerp(0.26f, 0.365f, t); cg = lerp(0.63f, 0.733f, t); cb = lerp(0.16f, 0.208f, t);
        } else {
            float t = (big - 0.5f) * 2.0f;
            cr = lerp(0.365f, 0.49f, t); cg = lerp(0.733f, 0.86f, t); cb = lerp(0.208f, 0.29f, t);
        }
        float k = 0.9f + 0.2f * mid + (hash(x, y, 5) - 0.5f) * 0.10f;
        c.set(x, y, cr * k, cg * k, cb * k);
    }
    // pelinhos de grama
    for (int it = 0; it < 3200; it++) {
        int x0 = rnd.nextInt(S);
        int y0 = rnd.nextInt(S);
        int len = 4 + rnd.nextInt(7);
        float lean = (rnd.nextFloat() - 0.5f) * 0.7f;
        bool dark = rnd.nextFloat() < 0.45f;
        for (int k = 0; k < len; k++) {
            float a = 0.9f - static_cast<float>(k) * 0.07f;
            int px = x0 + static_cast<int>(lean * static_cast<float>(k));
            if (dark) c.blend(px, y0 + k, 0.17f, 0.50f, 0.11f, a);
            else      c.blend(px, y0 + k, 0.58f, 0.92f, 0.33f, a);
        }
    }
    // florzinhas minúsculas (branca, amarela, rosa)
    static const float fl[3][3] = {{1.0f, 1.0f, 0.95f}, {1.0f, 0.88f, 0.2f}, {1.0f, 0.55f, 0.75f}};
    for (int i = 0; i < 9; i++) {
        int x = rnd.nextInt(S);
        int y = rnd.nextInt(S);
        const float* f = fl[i % 3];
        c.set(x, y, f[0], f[1], f[2]);
        c.blend(x + 1, y, f[0], f[1], f[2], 0.8f); c.blend(x - 1, y, f[0], f[1], f[2], 0.8f);
        c.blend(x, y + 1, f[0], f[1], f[2], 0.8f); c.blend(x, y - 1, f[0], f[1], f[2], 0.8f);
        c.set(x, y, 1.0f, 0.8f, 0.1f);
    }
    // pedrinhas
    for (int it = 0; it < 6; it++) {
        float x = static_cast<float>(rnd.nextInt(S));
        float y = static_cast<float>(rnd.nextInt(S));
        c.ellipse(x + 1.0f, y + 1.0f, 3.2f, 2.2f, 0.0f, 0.20f, 0.35f, 0.12f, 0.6f);
        float ang = rnd.nextFloat() * 3.0f;
        c.ellipse(x, y, 3.0f, 2.0f, ang, 0.62f, 0.62f, 0.60f, 1.0f);
        c.ellipse(x - 0.7f, y - 0.6f, 1.4f, 0.9f, 0.0f, 0.82f, 0.82f, 0.80f, 0.9f);
    }
    return c.toPixels();
}

// =====================================================================
//  PEDRA  #5A5A5A  (moss=true: com musgo #4A7C2E)
// =====================================================================
Pixels rock(bool moss) {
    Canvas c;
    JavaRandom rnd(moss ? 33 : 21);
    for (int y = 0; y < S; y++) for (int x = 0; x < S; x++) {
        float u = (static_cast<float>(x) + 0.5f) / static_cast<float>(S);
        float v = (static_cast<float>(y) + 0.5f) / static_cast<float>(S);
        float big = fbm(u, v, 4, 5, 21);
        float strata = vnoise(u, v, 3, 22, 23);
        float gr = 0.30f + 0.26f * big + 0.12f * (strata - 0.5f);
        gr += (hash(x, y, 9) - 0.5f) * 0.09f;
        float cr = gr * 1.03f;
        float cg = gr;
        float cb = gr * 0.96f;
        // terra marrom
        float dp = sstep(0.56f, 0.74f, fbm(u, v, 5, 3, 44));
        cr = lerp(cr, 0.47f * (0.8f + big * 0.4f), dp * 0.65f);
        cg = lerp(cg, 0.34f * (0.8f + big * 0.4f), dp * 0.65f);
        cb = lerp(cb, 0.21f * (0.8f + big * 0.4f), dp * 0.65f);
        // musgo verde
        float mp = moss ? sstep(0.40f, 0.58f, fbm(u, v, 6, 4, 55))
                        : sstep(0.70f, 0.80f, fbm(u, v, 6, 4, 55)) * 0.7f;
        float mk = 0.85f + 0.3f * fbm(u, v, 20, 2, 56);
        cr = lerp(cr, 0.29f * mk, mp * 0.92f);
        cg = lerp(cg, 0.49f * mk, mp * 0.92f);
        cb = lerp(cb, 0.18f * mk, mp * 0.92f);
        // rachaduras
        float ridge = km::abs(fbm(u, v, 5, 4, 33) - 0.5f) * 2.0f;
        float crack = 1.0f - sstep(0.0f, 0.045f, ridge);
        float ridge2 = km::abs(fbm(u, v, 9, 3, 34) - 0.5f) * 2.0f;
        float crack2 = 1.0f - sstep(0.0f, 0.03f, ridge2);
        float dk = 1.0f - 0.6f * km::max(crack, crack2 * 0.7f);
        c.set(x, y, cr * dk, cg * dk, cb * dk);
    }
    // riscos finos de arranhão
    for (int it = 0; it < 120; it++) {
        int x0 = rnd.nextInt(S);
        int y0 = rnd.nextInt(S);
        int len = 6 + rnd.nextInt(16);
        float dx = rnd.nextFloat() * 2.0f - 1.0f;
        float dy = rnd.nextFloat() * 2.0f - 1.0f;
        float l = km::max(0.01f, km::sqrt(dx * dx + dy * dy));
        bool light = rnd.nextFloat() < 0.3f;
        for (int k = 0; k < len; k++) {
            int px = x0 + static_cast<int>(dx / l * static_cast<float>(k));
            int py = y0 + static_cast<int>(dy / l * static_cast<float>(k));
            if (light) c.blend(px, py, 0.7f, 0.7f, 0.68f, 0.35f);
            else       c.blend(px, py, 0.1f, 0.1f, 0.1f, 0.45f);
        }
    }
    return c.toPixels();
}

// =====================================================================
//  AREIA  #F5DEB3
// =====================================================================
Pixels sand() {
    Canvas c;
    JavaRandom rnd(5);
    for (int y = 0; y < S; y++) for (int x = 0; x < S; x++) {
        float u = (static_cast<float>(x) + 0.5f) / static_cast<float>(S);
        float v = (static_cast<float>(y) + 0.5f) / static_cast<float>(S);
        float mott = 0.94f + 0.10f * fbm(u, v, 6, 3, 61);
        float grain = (hash(x, y, 7) - 0.5f) * 0.07f;
        float wv = km::sin((v * 8.0f + 1.8f * (fbm(u, v, 3, 3, 62) - 0.5f)) * 6.2831855f);
        float ripple = 0.035f * wv;
        float k = mott + grain + ripple;
        c.set(x, y, 0.96f * k, 0.87f * k, 0.70f * k);
    }
    // brilhinhos (grãos de quartzo)
    for (int it = 0; it < 160; it++) {
        int bx = rnd.nextInt(S);
        int by = rnd.nextInt(S);
        c.blend(bx, by, 1.0f, 1.0f, 0.93f, 0.95f);
    }
    // grãos escuros / pedacinhos de concha
    for (int it = 0; it < 70; it++) {
        int bx = rnd.nextInt(S);
        int by = rnd.nextInt(S);
        c.blend(bx, by, 0.74f, 0.62f, 0.45f, 0.7f);
    }
    for (int it = 0; it < 5; it++) {
        float cx = static_cast<float>(rnd.nextInt(S));
        float cy = static_cast<float>(rnd.nextInt(S));
        float ang = rnd.nextFloat() * 3.0f;
        c.ellipse(cx, cy, 2.5f, 1.6f, ang, 0.98f, 0.93f, 0.86f, 0.95f);
    }
    return c.toPixels();
}

// =====================================================================
//  CHÃO DA FLORESTA  #8B5A2B
// =====================================================================
Pixels forest() {
    Canvas c;
    JavaRandom rnd(77);
    for (int y = 0; y < S; y++) for (int x = 0; x < S; x++) {
        float u = (static_cast<float>(x) + 0.5f) / static_cast<float>(S);
        float v = (static_cast<float>(y) + 0.5f) / static_cast<float>(S);
        float big = fbm(u, v, 4, 5, 71);
        float damp = sstep(0.42f, 0.70f, fbm(u, v, 5, 3, 72));
        float cr = lerp(0.54f, 0.40f, big);
        float cg = lerp(0.36f, 0.27f, big);
        float cb = lerp(0.18f, 0.14f, big);
        float dk = 1.0f - 0.38f * damp;
        float gr = (hash(x, y, 13) - 0.5f) * 0.10f;
        cr = cr * dk + gr; cg = cg * dk + gr * 0.8f; cb = cb * dk + gr * 0.5f;
        c.set(x, y, cr, cg, cb);
    }
    // raízes aparecendo
    for (int it = 0; it < 9; it++) {
        float px = rnd.nextFloat() * static_cast<float>(S);
        float py = rnd.nextFloat() * static_cast<float>(S);
        float ang = rnd.nextFloat() * 6.2831855f;
        int steps = 60 + rnd.nextInt(60);
        float th = 1.2f + rnd.nextFloat() * 1.2f;
        for (int k = 0; k < steps; k++) {
            ang += (rnd.nextFloat() - 0.5f) * 0.45f;
            px += km::cos(ang) * 1.1f;
            py += km::sin(ang) * 1.1f;
            c.ellipse(px, py, th, th, 0.0f, 0.25f, 0.15f, 0.07f, 0.95f);
            c.ellipse(px - 0.9f, py - 0.9f, th * 0.5f, th * 0.5f, 0.0f, 0.46f, 0.31f, 0.16f, 0.55f);
        }
    }
    // folhas secas caídas
    static const float leaf[5][3] = {
        {0.71f, 0.40f, 0.11f}, {0.63f, 0.32f, 0.16f}, {0.78f, 0.56f, 0.23f}, {0.55f, 0.41f, 0.08f}, {0.36f, 0.22f, 0.10f}};
    for (int it = 0; it < 260; it++) {
        const float* f = leaf[rnd.nextInt(5)];
        float sh = 0.85f + rnd.nextFloat() * 0.3f;
        float a = rnd.nextFloat() * 3.1416f;
        float cx = static_cast<float>(rnd.nextInt(S));
        float cy = static_cast<float>(rnd.nextInt(S));
        float len = 3.5f + rnd.nextFloat() * 3.5f;
        c.ellipse(cx, cy, len, len * 0.45f, a, f[0] * sh, f[1] * sh, f[2] * sh, 0.95f);
        c.ellipse(cx, cy, len * 0.9f, 0.6f, a, f[0] * sh * 0.6f, f[1] * sh * 0.6f, f[2] * sh * 0.6f, 0.7f);
    }
    // pontinhos de musgo/folhinha verde
    for (int it = 0; it < 40; it++) {
        float cx = static_cast<float>(rnd.nextInt(S));
        float cy = static_cast<float>(rnd.nextInt(S));
        float ang = rnd.nextFloat() * 3.0f;
        c.ellipse(cx, cy, 2.2f, 1.6f, ang, 0.26f, 0.42f, 0.14f, 0.85f);
    }
    return c.toPixels();
}
}  // namespace TexGen
