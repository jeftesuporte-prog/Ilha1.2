#include "Player.h"
#include <cmath>
#include "Cfg.h"
#include "Color.h"
#include "KMath.h"
#include "Shapes.h"
#include "World.h"

namespace {
// MathUtils.atan2 do libGDX (aproximação, NÃO é o atan2 exato): é ela que dá o rumo do boneco no original.
constexpr float GDX_PI = 3.1415927f;
float gdxAtan2(float y, float x) {
    if (x == 0.0f) {
        if (y > 0.0f) return GDX_PI / 2;
        if (y == 0.0f) return 0.0f;
        return -GDX_PI / 2;
    }
    float atan;
    const float z = y / x;
    if (km::abs(z) < 1.0f) {
        atan = z / (1.0f + 0.28f * z * z);
        if (x < 0.0f) return atan + (y < 0.0f ? -GDX_PI : GDX_PI);
        return atan;
    }
    atan = GDX_PI / 2 - z / (z * z + 0.28f);
    return y < 0.0f ? atan - GDX_PI : atan;
}
constexpr float RAD_TO_DEG = 180.0f / GDX_PI;   // MathUtils.radiansToDegrees
}  // namespace

float Player::headingFromDir(float dx, float dz) { return gdxAtan2(dx, dz) * RAD_TO_DEG; }

void Player::place(float x, float z, float headingDegrees) {
    pos = {x, World::groundAt(x, z), z};
    setHeading(headingDegrees);
}

float Player::floorAt(float x, float z, const Colliders& c) const {
    const float g = c.rockFloor(x, z, World::groundAt(x, z));   // terreno + topo das pedras (dá para subir nelas)
    return Cfg::PAREDES_INVISIVEIS ? g : km::max(g, Cfg::SWIM_Y);
}

void Player::move(float dx, float dz, float dt, float speed, const Colliders& c) {
    const float step = speed * dt;
    const float tx = pos.x + dx * step;
    const float tz = pos.z + dz * step;
    if (!attempt(tx, tz, c)) {
        if (!attempt(tx, pos.z, c)) attempt(pos.x, tz, c);
    }
    setHeading(headingFromDir(dx, dz));
}

bool Player::attempt(float tx0, float tz0, const Colliders& c) {
    float tmp[2];
    if (Cfg::PAREDES_INVISIVEIS) {
        tmp[0] = km::coerceIn(tx0, -Cfg::HALF + 5.0f, Cfg::HALF - 5.0f);   // limite do mapa
        tmp[1] = km::coerceIn(tz0, -Cfg::HALF + 5.0f, Cfg::HALF - 5.0f);
    } else {
        tmp[0] = tx0;                                                       // mar aberto: dá para nadar para qualquer lado
        tmp[1] = tz0;
    }

    // 1) grades da ponte: quem está no deck fica no deck, quem está fora não entra pelo lado
    const float aN = Bridge::along(tmp[0], tmp[1]);
    // quem nada no rio, por BAIXO da ponte, passa livre (a grade só vale em cima/ao lado do deck)
    const bool underBridge = pos.y < Bridge::deckAt(pos.x, pos.z) - 0.9f;
    if (km::abs(aN) < Cfg::BRIDGE_HALF_LEN && !underBridge) {
        const float cO = Bridge::across(pos.x, pos.z);
        float cN = Bridge::across(tmp[0], tmp[1]);
        const float inner = Cfg::BRIDGE_HALF_W - Cfg::PLAYER_R;
        const float outer = Cfg::BRIDGE_HALF_W + Cfg::PLAYER_R;
        bool changed = false;
        if (km::abs(cO) < Cfg::BRIDGE_HALF_W) {
            if (km::abs(cN) > inner) { cN = cN > 0.0f ? inner : -inner; changed = true; }
        } else if (km::abs(cN) < outer) {
            cN = cO > 0.0f ? outer : -outer; changed = true;
        }
        if (changed) {
            tmp[0] = Bridge::x() + Bridge::dx() * aN - Bridge::dz() * cN;
            tmp[1] = Bridge::z() + Bridge::dz() * aN + Bridge::dx() * cN;
        }
    }

    // 2) troncos, pedras e colmeias
    c.pushOut(tmp, Cfg::PLAYER_R);
    const float nx = tmp[0];
    const float nz = tmp[1];

    // 3) terreno: água funda, rio sem ponte, parede íngreme (tudo isso só vale com PAREDES_INVISIVEIS)
    const bool deckTarget = World::onDeck(nx, nz);
    const float g1 = floorAt(nx, nz, c);
    if (Cfg::PAREDES_INVISIVEIS && g1 < Cfg::WADE_LIMIT) return false;
    const float rise = g1 - pos.y;
    if (Cfg::PAREDES_INVISIVEIS && rise > 0.05f) {
        const float moved = km::hypot(nx - pos.x, nz - pos.z);
        const bool ok = deckTarget ? rise <= 1.2f : (moved > 1e-4f && rise / moved <= 1.15f);
        if (!ok) return false;
    }
    pos.x = nx;
    pos.z = nz;
    if (pos.y < g1) { pos.y = g1; vy_ = 0.0f; }
    return true;
}

void Player::jump() {
    if (grounded) {
        vy_ = 6.5f;                 // ~1,2 m de altura (boneco tem 1,75 m)
        grounded = false;
    }
}

void Player::physics(float dt, const Colliders& c) {
    const float g = floorAt(pos.x, pos.z, c);
    if (grounded && vy_ <= 0.0f && pos.y - g <= 0.35f) {
        pos.y = g;
    } else {
        grounded = false;
        vy_ -= 18.0f * dt;
        pos.y += vy_ * dt;
        if (pos.y <= g && vy_ <= 0.0f) {
            pos.y = g;
            vy_ = 0.0f;
            grounded = true;
        }
    }
}

void Player::drive(float yaw, float moveX, float moveY, bool run, bool& jumpPressed, float dt, const Colliders& c) {
    const float fx = km::cos(yaw);
    const float fz = km::sin(yaw);
    const float mvx = fx * moveY + (-fz) * moveX;
    const float mvz = fz * moveY + fx * moveX;
    const float len = km::hypot(mvx, mvz);
    if (len > 0.05f) {
        const float speed = run ? 8.0f : 4.5f;
        const float wade = pos.y < -0.3f ? 0.55f : 1.0f;     // dentro d'água anda mais devagar
        move(mvx / len, mvz / len, dt, speed * km::min(1.0f, len) * wade, c);
    }
    if (jumpPressed) {
        jump();
        jumpPressed = false;
    }
    physics(dt, c);
}

void Player::buildModel(std::vector<float>& out) const {
    out.clear();
    Shapes::Affine m;
    m.translate(pos.x, pos.y, pos.z).rotY(heading * 0.017453292f);   // Matrix4.rotate(Y, graus)
    auto box = [&](uint32_t hex, float x, float y, float z, float w, float h, float d) {
        Shapes::box(out, m, Pal::bits(Color::hex(hex)), x, y, z, w, h, d);
    };
    box(0x1D3557, -0.12f, 0.425f, 0.0f, 0.2f, 0.85f, 0.22f);    // perna E
    box(0x1D3557, 0.12f, 0.425f, 0.0f, 0.2f, 0.85f, 0.22f);     // perna D
    box(0xE63946, 0.0f, 1.15f, 0.0f, 0.5f, 0.6f, 0.28f);        // tronco (camiseta vermelha)
    box(0xF1C27D, -0.31f, 1.15f, 0.0f, 0.12f, 0.6f, 0.14f);     // braço E
    box(0xF1C27D, 0.31f, 1.15f, 0.0f, 0.12f, 0.6f, 0.14f);      // braço D
    box(0xF1C27D, 0.0f, 1.60f, 0.0f, 0.3f, 0.3f, 0.3f);         // cabeça
    box(0x222222, 0.0f, 1.63f, 0.151f, 0.2f, 0.05f, 0.02f);     // olhos
}
