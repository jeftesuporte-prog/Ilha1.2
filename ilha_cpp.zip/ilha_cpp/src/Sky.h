#pragma once
// Port de Sky.kt (parte lógica, sem desenho): relógio do dia, posição do sol/lua, cores do céu/luz/névoa,
// nuvens, estrelas e estrelas cadentes. O DESENHO (shader do céu, reflexo na água) está no VkEngine.
#include <vector>
#include "Color.h"
#include "JavaRandom.h"
#include "KMath.h"

// Vector3 do libGDX (mesma aritmética: nor() multiplica por 1/sqrt(len2))
struct V3 {
    float x = 0, y = 0, z = 0;
    V3() = default;
    V3(float x_, float y_, float z_) : x(x_), y(y_), z(z_) {}
    V3& set(float x_, float y_, float z_) { x = x_; y = y_; z = z_; return *this; }
    V3& set(const V3& o) { x = o.x; y = o.y; z = o.z; return *this; }
    V3& scl(float s) { x *= s; y *= s; z *= s; return *this; }
    V3& mulAdd(const V3& o, float s) { x += o.x * s; y += o.y * s; z += o.z * s; return *this; }
    float dot(const V3& o) const { return x * o.x + y * o.y + z * o.z; }
    float len2() const { return x * x + y * y + z * z; }
    V3& nor() {
        float l2 = len2();
        if (l2 == 0.0f || l2 == 1.0f) return *this;
        return scl(1.0f / static_cast<float>(std::sqrt(static_cast<double>(l2))));
    }
};

// Tudo que o desenho do céu e da água precisa saber, num pacote simples.
struct SkyFrame {
    float top[3], hor[3], sun[3], moon[3];
    float sunH[2];
    float warm1[3], warm2[3], warm3[3], halo[3];
    float tw;
    float sunE[3], sunN[3], sunR, squash, sunCol[3];
    float sunGlit[3], moonGlit[3];
    float refl;
};

class Sky {
public:
    static constexpr int NSTARS = 760;

    Sky();

    // Avança o relógio; (camX,camZ) = câmera; (dirX,dirZ) = para onde ela olha (a névoa tem a cor do horizonte ali).
    void update(float dt, float camX, float camZ, float dirX, float dirZ);
    // Equivalente ao início de drawBackground(): guarda para onde a câmera olha (usado ao sortear estrelas cadentes).
    void noteCamera(float dirX, float dirZ) { camAz = km::atan2(dirZ, dirX); }
    float nightK() const;                 // 0 = dia, 1 = noite fechada
    void fillFrame(SkyFrame& f) const;

    float tod = Cfg_START_HOUR();
    V3 toSun{1.0f, 0.3f, -0.28f}, toMoon, toLight;
    float sunE = 0.3f;
    Color topC{}, horC{}, fog{}, ambient{}, lightC{};
    float tw = 0.0f;
    Color warm1{}, warm2{}, warm3{}, haloCol{}, sunCol{};
    float sunHx = 1.0f, sunHz = 0.0f;
    V3 sunEv, sunNv;
    float sunR = 0.05f, sunSquash = 1.0f, warmK = 0.0f;
    Color sunGlitCol{}, moonGlitCol{};

    struct Puff { float ox, oy, oz, s; };
    struct Cloud { float x, y, z, speed; std::vector<Puff> puffs; float er = 0, eg = 0, eb = 0; };
    std::vector<Cloud> clouds;

    float sdx[NSTARS], sdy[NSTARS], sdz[NSTARS], ssz[NSTARS], sbr[NSTARS], sph[NSTARS], ssp[NSTARS];
    int sty[NSTARS];                      // 0 branca, 1 azulada, 2 amarelada

    struct Meteor { V3 d0, tv; float speed, life, age = 0.0f; };
    std::vector<Meteor> meteors;

private:
    static float Cfg_START_HOUR();
    void recompute();
    void spawnMeteor();
    static void stopColor(const float arr[5][3], float e, Color& out);
    void horizonAt(float dx, float dz, Color& out) const;

    JavaRandom rnd{42};
    float meteorTimer = 14.0f;
    float camAz = 0.0f;
};
