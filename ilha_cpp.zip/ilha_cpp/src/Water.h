#pragma once
// Port de Water.kt: dados do mar (texturas, malhas, animação). O desenho está no VkEngine.
#include <cstdint>
#include <vector>

struct Image {
    int w = 0, h = 0;
    std::vector<uint8_t> rgba;      // bytes R,G,B,A
};

// Tudo que o desenho da água precisa a cada quadro.
struct WaterFrame {
    float planeX = 0, planeZ = 0;   // o mar acompanha o jogador em saltos de 100 m
    float uv1[4] = {0, 0, 1, 1};    // camada 1: offsetU, offsetV, scaleU, scaleV
    float uv2[4] = {0, 0, 0.6f, 0.6f};
    float swashOffU = 0, swashOffV = 0.45f, wetOffV = 0.45f;
    float foamAlpha[3] = {0.5f, 0.5f, 0.5f};
};

class Water {
public:
    Water();                        // monta texturas e malhas (usa o mundo: chame com o mundo já pronto)

    // texturas
    Image waterTex;                 // 256x256, tileável (mipmaps no upload)
    Image swashTex, wetTex;         // 512x256: onda subindo a praia / areia molhada
    // malhas (vértices de 9 floats: x y z | nx ny nz | cor | u v), triângulos soltos
    std::vector<float> planeVerts;  // grade 36x36 do mar (3 km), centrada na origem
    std::vector<float> bandVerts;   // faixa de ondas deitada na malha do terreno (swash e wet usam a mesma)
    std::vector<float> foamVerts[3];

    void follow(float px, float pz);
    void update(float dt, float t);                 // t = tempo de jogo em segundos
    void fillFrame(WaterFrame& f) const;
    static float phase(float t);                    // posição (0..1) na onda atual: o som do mar usa o mesmo relógio

    // exposto para teste
    static float edgeAt(float u);
    static float swashF(float p);

private:
    void applySwash(float t, float dt);

    float planeX_ = 0, planeZ_ = 0;
    float off1U_ = 0, off1V_ = 0, off2U_ = 0, off2V_ = 0;
    float swashOffU_ = 0, swashOffV_ = 0, wetOffV_ = 0, wetF_ = 0;
    float foamAlpha_[3] = {0.5f, 0.5f, 0.5f};
};

// Textura de ruído (R,G = inclinação das ondas; B,A = pontinhos de brilho) usada no reflexo do céu na água.
Image makeNoiseTexture();
