#include "Trees.h"
#include <array>
#include <cmath>
#include "Cfg.h"
#include "Color.h"
#include "KMath.h"
#include "World.h"   // Pal

using km::cos; using km::sin; using km::sqrt; using km::abs; using km::min; using km::max;

namespace {
constexpr float TP = 6.2831855f;

// ---------- icosaedro unitário (copas, arbustos, pedras) ----------
const int FACES[60] = {
    0, 11, 5, 0, 5, 1, 0, 1, 7, 0, 7, 10, 0, 10, 11,
    1, 5, 9, 5, 11, 4, 11, 10, 2, 10, 7, 6, 7, 1, 8,
    3, 9, 4, 3, 4, 2, 3, 2, 6, 3, 6, 8, 3, 8, 9,
    4, 9, 5, 2, 4, 11, 6, 2, 10, 8, 6, 7, 9, 8, 1};

struct Ico {
    float v[36];
    Ico() {
        float t = (1.0f + sqrt(5.0f)) / 2.0f;
        const float raw[36] = {
            -1.0f, t, 0.0f, 1.0f, t, 0.0f, -1.0f, -t, 0.0f, 1.0f, -t, 0.0f,
            0.0f, -1.0f, t, 0.0f, 1.0f, t, 0.0f, -1.0f, -t, 0.0f, 1.0f, -t,
            t, 0.0f, -1.0f, t, 0.0f, 1.0f, -t, 0.0f, -1.0f, -t, 0.0f, 1.0f};
        for (int i = 0; i < 12; i++) {
            float x = raw[i * 3], y = raw[i * 3 + 1], z = raw[i * 3 + 2];
            float l = sqrt(x * x + y * y + z * z);
            v[i * 3] = x / l; v[i * 3 + 1] = y / l; v[i * 3 + 2] = z / l;
        }
    }
};
const float* ICO() { static const Ico I; return I.v; }

float bcol(float r, float g, float b, float k) { return toFloatBits(min(1.0f, r * k), min(1.0f, g * k), min(1.0f, b * k), 1.0f); }

// quantidade de folhas respeitando Cfg.LEAF_DETAIL
int nL(int n) { return std::max(1, static_cast<int>(n * Cfg::LEAF_DETAIL)); }

void prism(MeshAccum& acc, float x0, float y0, float z0, float r0, float x1, float y1, float z1, float r1, int sides, float col) {
    float da = TP / sides;
    float mx = (x0 + x1) / 2.0f, my = (y0 + y1) / 2.0f, mz = (z0 + z1) / 2.0f;
    for (int k = 0; k < sides; k++) {
        float a0 = k * da;
        float a1 = (k + 1) * da;
        float bx0 = x0 + cos(a0) * r0, bz0 = z0 + sin(a0) * r0;
        float bx1 = x0 + cos(a1) * r0, bz1 = z0 + sin(a1) * r0;
        float tx0 = x1 + cos(a0) * r1, tz0 = z1 + sin(a0) * r1;
        float tx1 = x1 + cos(a1) * r1, tz1 = z1 + sin(a1) * r1;
        acc.triOut(bx0, y0, bz0, bx1, y0, bz1, tx1, y1, tz1, mx, my, mz, col);
        acc.triOut(bx0, y0, bz0, tx1, y1, tz1, tx0, y1, tz0, mx, my, mz, col);
    }
}

// Tronco: segmento entre dois anéis, com giro (a0 -> a1) e cada face com um tom de marrom (cor base opcional).
void trunkSeg(MeshAccum& acc, float x0, float y0, float z0, float r0, float a0,
              float x1, float y1, float z1, float r1, float a1,
              int sides, JavaRandom& rng, float k,
              float cr = 0.50f, float cg = 0.34f, float cb = 0.20f, int marks = 0, float markCol = 0.0f) {
    float da = TP / sides;
    float mx = (x0 + x1) / 2.0f, my = (y0 + y1) / 2.0f, mz = (z0 + z1) / 2.0f;
    // faces que ganham uma marca escura (losango) feita NA PRÓPRIA face do tronco
    int markMask = 0;
    for (int i = 0; i < marks; i++) markMask = markMask | (1 << rng.nextInt(sides));
    for (int s = 0; s < sides; s++) {
        float col = bcol(cr, cg, cb, k * (0.8f + rng.nextFloat() * 0.55f));
        float ax = x0 + cos(a0 + s * da) * r0, az = z0 + sin(a0 + s * da) * r0;
        float bx = x0 + cos(a0 + (s + 1) * da) * r0, bz = z0 + sin(a0 + (s + 1) * da) * r0;
        float dx = x1 + cos(a1 + s * da) * r1, dz = z1 + sin(a1 + s * da) * r1;
        float ex = x1 + cos(a1 + (s + 1) * da) * r1, ez = z1 + sin(a1 + (s + 1) * da) * r1;
        if (((markMask >> s) & 1) == 0) {
            acc.triOut(ax, y0, az, bx, y0, bz, ex, y1, ez, mx, my, mz, col);
            acc.triOut(ax, y0, az, ex, y1, ez, dx, y1, dz, mx, my, mz, col);
            continue;
        }
        // face com losango: A,B = base; D,E = topo
        float cxF = (ax + bx + dx + ex) / 4.0f, cyF = (y0 + y0 + y1 + y1) / 4.0f, czF = (az + bz + dz + ez) / 4.0f;
        float kw = 0.45f + rng.nextFloat() * 0.35f;
        float kh = 0.30f + rng.nextFloat() * 0.30f;
        float pbx = cxF + ((ax + bx) / 2.0f - cxF) * kh, pby = cyF + (y0 - cyF) * kh, pbz = czF + ((az + bz) / 2.0f - czF) * kh;
        float prx = cxF + ((bx + ex) / 2.0f - cxF) * kw, pry = cyF + ((y0 + y1) / 2.0f - cyF) * kw, prz = czF + ((bz + ez) / 2.0f - czF) * kw;
        float ptx = cxF + ((ex + dx) / 2.0f - cxF) * kh, pty = cyF + (y1 - cyF) * kh, ptz = czF + ((ez + dz) / 2.0f - czF) * kh;
        float plx = cxF + ((dx + ax) / 2.0f - cxF) * kw, ply = cyF + ((y0 + y1) / 2.0f - cyF) * kw, plz = czF + ((dz + az) / 2.0f - czF) * kw;
        acc.triOut(ax, y0, az, bx, y0, bz, pbx, pby, pbz, mx, my, mz, col);
        acc.triOut(bx, y0, bz, ex, y1, ez, prx, pry, prz, mx, my, mz, col);
        acc.triOut(ex, y1, ez, dx, y1, dz, ptx, pty, ptz, mx, my, mz, col);
        acc.triOut(dx, y1, dz, ax, y0, az, plx, ply, plz, mx, my, mz, col);
        acc.triOut(ax, y0, az, pbx, pby, pbz, plx, ply, plz, mx, my, mz, col);
        acc.triOut(bx, y0, bz, prx, pry, prz, pbx, pby, pbz, mx, my, mz, col);
        acc.triOut(ex, y1, ez, ptx, pty, ptz, prx, pry, prz, mx, my, mz, col);
        acc.triOut(dx, y1, dz, plx, ply, plz, ptx, pty, ptz, mx, my, mz, col);
        acc.triOut(pbx, pby, pbz, prx, pry, prz, ptx, pty, ptz, mx, my, mz, markCol);
        acc.triOut(pbx, pby, pbz, ptx, pty, ptz, plx, ply, plz, mx, my, mz, markCol);
    }
}

// FOLHA em losango (2 triângulos) colada na superfície de um elipsoide de centro (cx,cy,cz).
void leafOn(MeshAccum& acc, float cx, float cy, float cz, float rx, float ry, float rz,
            float dx, float dy, float dz, float len, float wid, float phi, float col, float lift) {
    float lh = max(sqrt(dx * dx + dz * dz), 1e-4f);
    bool flat = abs(dy) > 0.95f;
    float t1x = flat ? 1.0f : dz / lh;
    float t1z = flat ? 0.0f : -dx / lh;
    float t2x = dy * t1z;
    float t2y = dz * t1x - dx * t1z;
    float t2z = -dy * t1x;
    float cph = cos(phi), sph = sin(phi);
    float ux = t1x * cph + t2x * sph, uy = t2y * sph, uz = t1z * cph + t2z * sph;
    float vx = -t1x * sph + t2x * cph, vy = t2y * cph, vz = -t1z * sph + t2z * cph;
    float px = cx + dx * rx, py = cy + dy * ry, pz = cz + dz * rz;
    float tipX = px + ux * len + dx * len * lift;
    float tipY = py + uy * len + dy * len * lift;
    float tipZ = pz + uz * len + dz * len * lift;
    float mx = px + ux * len * 0.5f + dx * (len * lift * 0.5f + wid * 0.4f);
    float my = py + uy * len * 0.5f + dy * (len * lift * 0.5f + wid * 0.4f);
    float mz = pz + uz * len * 0.5f + dz * (len * lift * 0.5f + wid * 0.4f);
    acc.triOut(px, py, pz, mx + vx * wid, my + vy * wid, mz + vz * wid, tipX, tipY, tipZ, cx, cy, cz, col);
    acc.triOut(px, py, pz, tipX, tipY, tipZ, mx - vx * wid, my - vy * wid, mz - vz * wid, cx, cy, cz, col);
}

// Fruta REDONDA (esfera facetada de 20 faces, levemente achatada/alongada).
void fruit(MeshAccum& acc, float x, float y, float z, float r, float ry, float col, JavaRandom& rng) {
    Trees::blob(acc, x, y, z, r, ry, r, col, 0.04f, rng);
}

// Bolota de folhas (modelo TREE_01): esfera low-poly verde-escura coberta de placas-folha mais claras.
void leafBall(MeshAccum& acc, float cx, float cy, float cz, float r, float t, JavaRandom& rng, int plates = 7) {
    float tt = km::coerceIn(t, 0.0f, 1.0f);
    Trees::blob(acc, cx, cy, cz, r, r * 0.92f, r, bcol(0.09f + 0.14f * tt, 0.30f + 0.20f * tt, 0.10f + 0.06f * tt, 1.0f), 0.3f, rng);
    if (!Cfg::FOLHAS_SOLTAS) return;   // copa lisinha: só a bolota, sem as placas-folha saindo
    int cnt = nL(plates);
    for (int i = 0; i < cnt; i++) {
        float dx = rng.nextFloat() * 2.0f - 1.0f;
        float dz = rng.nextFloat() * 2.0f - 1.0f;
        float dy = rng.nextFloat() * 1.4f - 0.25f;
        float l = max(sqrt(dx * dx + dy * dy + dz * dz), 0.1f);
        float q = rng.nextFloat();
        float col = bcol(0.12f + 0.20f * q + 0.08f * tt, 0.42f + 0.30f * q, 0.12f + 0.10f * q, 1.0f);
        float phi = rng.nextFloat() * TP;
        leafOn(acc, cx, cy, cz, r, r * 0.92f, r, dx / l, dy / l, dz / l, r * 0.5f + 0.18f, r * 0.2f + 0.07f, phi, col, 0.25f);
    }
}

// Mancha (losango) colada na superfície: (cx,cy,cz)=centro do objeto, n=normal unitária, dist=distância até a superfície.
void spotOn(MeshAccum& acc, float cx, float cy, float cz, float nx, float ny, float nz, float dist, float size, float col) {
    float l = max(sqrt(nx * nx + nz * nz), 1e-4f);
    bool flat = abs(ny) > 0.95f;
    float t1x = flat ? 1.0f : nz / l;
    float t1z = flat ? 0.0f : -nx / l;
    float t2x = ny * t1z;
    float t2y = nz * t1x - nx * t1z;
    float px = cx + nx * dist, py = cy + ny * dist, pz = cz + nz * dist;
    float w = size;
    float h = size * 1.25f;
    float ax = px + t1x * w, ay = py, az = pz + t1z * w;
    float bx = px + t2x * h, by = py + t2y * h, bz = pz + (-ny * t1x) * h;
    float cx2 = px - t1x * w, cz2 = pz - t1z * w;
    float dx = px - t2x * h, dy = py - t2y * h, dz = pz - (-ny * t1x) * h;
    acc.triOut(ax, ay, az, bx, by, bz, cx2, ay, cz2, cx, cy, cz, col);
    acc.triOut(ax, ay, az, cx2, ay, cz2, dx, dy, dz, cx, cy, cz, col);
}

// Folha de palmeira (RETO: eixo grosso, folíolos longos e finos; TORTO: eixo fino, folíolos largos em pares).
void frond(MeshAccum& acc, float bx, float by, float bz, float a, float len, bool steep, bool curved, JavaRandom& rng) {
    float dx = cos(a), dz = sin(a);
    float sx = -dz, sz = dx;
    float kU = steep ? 1.7f : (curved ? 0.95f : 0.8f);
    float reach = steep ? 0.5f : 1.0f;
    float droop = curved ? 1.0f : 1.1f;
    float gr = rng.nextFloat();
    float baseR = curved ? 0.18f + 0.30f * gr : 0.08f + 0.12f * gr;
    float baseG = curved ? 0.62f + 0.22f * gr : 0.50f + 0.22f * gr;
    float baseB = curved ? 0.14f + 0.08f * gr : 0.08f + 0.06f * gr;
    float rachis = curved ? bcol(0.12f, 0.50f, 0.12f, 1.0f) : bcol(0.14f, 0.62f, 0.14f, 1.0f);
    float rw = curved ? 0.055f : 0.10f;

    const int n = 7;
    for (int j = 0; j < n; j++) {
        float u0 = j / static_cast<float>(n), u1 = (j + 1) / static_cast<float>(n);
        float x0 = bx + dx * len * reach * u0, z0 = bz + dz * len * reach * u0, y0 = by + len * (kU * u0 - droop * u0 * u0);
        float x1 = bx + dx * len * reach * u1, z1 = bz + dz * len * reach * u1, y1 = by + len * (kU * u1 - droop * u1 * u1);
        float w0 = rw * (1.0f - 0.5f * u0);
        float w1 = rw * (1.0f - 0.5f * u1);
        acc.triN(x0 - sx * w0, y0, z0 - sz * w0, x0 + sx * w0, y0, z0 + sz * w0, x1 + sx * w1, y1, z1 + sz * w1, 0.0f, 1.0f, 0.0f, rachis);
        acc.triN(x0 - sx * w0, y0, z0 - sz * w0, x1 + sx * w1, y1, z1 + sz * w1, x1 - sx * w1, y1, z1 - sz * w1, 0.0f, 1.0f, 0.0f, rachis);
    }

    int m = curved ? 11 : 12;   // reto: menos folíolos, porém mais largos
    for (int j = 0; j < m; j++) {
        float u = 0.12f + 0.86f * j / static_cast<float>(m - 1);
        float px = bx + dx * len * reach * u;
        float pz = bz + dz * len * reach * u;
        float py = by + len * (kU * u - droop * u * u);
        float tx = dx * len * reach;
        float ty = len * (kU - 2.0f * droop * u);
        float tz = dz * len * reach;
        float tl = sqrt(tx * tx + ty * ty + tz * tz);
        tx /= tl; ty /= tl; tz /= tl;
        float ll = curved ? 0.95f * (1.0f - 0.5f * u) + 0.3f : 1.55f * (1.0f - 0.55f * u) + 0.25f;
        float dn = steep ? 0.12f : (curved ? 0.30f : 0.50f);
        for (int si = 0; si < 2; si++) {
            int side = si == 0 ? -1 : 1;
            float k = 0.85f + rng.nextFloat() * 0.3f;
            float tint = curved ? 0.8f + 0.5f * u : 1.0f;           // torto: pontas mais claras
            float col = bcol(baseR * tint, baseG * (0.9f + 0.1f * tint), baseB, k);
            float spread = curved ? 0.85f : 0.72f;
            float tipX = px + sx * side * ll * spread + tx * ll * (curved ? 0.5f : 0.38f);
            float tipY = py + ty * ll * 0.4f - ll * dn;
            float tipZ = pz + sz * side * ll * spread + tz * ll * (curved ? 0.5f : 0.38f);
            if (curved) {
                float mx = px + (tipX - px) * 0.5f, my = py + (tipY - py) * 0.5f, mz = pz + (tipZ - pz) * 0.5f;
                float wd = 0.14f + 0.12f * (1.0f - u);
                acc.triN(px, py, pz, mx + tx * wd, my + ty * wd, mz + tz * wd, tipX, tipY, tipZ, 0.0f, 1.0f, 0.0f, col);
                acc.triN(px, py, pz, tipX, tipY, tipZ, mx - tx * wd, my - ty * wd, mz - tz * wd, 0.0f, 1.0f, 0.0f, col);
            } else {
                float w0 = 0.26f;   // largura na base do folíolo
                float w1 = 0.07f;   // largura na ponta
                acc.triN(px + tx * w0, py + ty * w0, pz + tz * w0, px - tx * w0, py - ty * w0, pz - tz * w0, tipX - tx * w1, tipY - ty * w1, tipZ - tz * w1, 0.0f, 1.0f, 0.0f, col);
                acc.triN(px + tx * w0, py + ty * w0, pz + tz * w0, tipX - tx * w1, tipY - ty * w1, tipZ - tz * w1, tipX + tx * w1, tipY + ty * w1, tipZ + tz * w1, 0.0f, 1.0f, 0.0f, col);
            }
        }
    }
}

// Triângulo com a normal sempre virada para cima (folhas ficam iluminadas dos dois lados).
void triUp(MeshAccum& acc, float ax, float ay, float az, float bx, float by, float bz, float cx, float cy, float cz, float col) {
    float ux = bx - ax, uy = by - ay, uz = bz - az;
    float vx = cx - ax, vy = cy - ay, vz = cz - az;
    float nx = uy * vz - uz * vy;
    float ny = uz * vx - ux * vz;
    float nz = ux * vy - uy * vx;
    float l = sqrt(nx * nx + ny * ny + nz * nz);
    if (l < 1e-9f) return;
    if (std::isnan(l)) return;   // ponta da folha de bananeira (NaN no original, a GPU descarta): não manda NaN para a GPU
    if (ny < 0.0f) { nx = -nx; ny = -ny; nz = -nz; }
    acc.triN(ax, ay, az, bx, by, bz, cx, cy, cz, nx / l, ny / l, nz / l, col);
}

// Folha de bananeira: lâmina larga que sobe e arqueia, pontas caindo, dobrada no meio.
void bananaLeaf(MeshAccum& acc, float bx, float by, float bz, float a, float len, float hw, bool steep, JavaRandom& rng) {
    float dx = cos(a), dz = sin(a);
    float sx = -dz, sz = dx;
    float kU = steep ? 2.0f : 1.25f;
    float droop = steep ? 1.2f : 1.35f;
    float reach = steep ? 0.45f : 0.85f;
    float g = rng.nextFloat();
    float r = 0.28f + 0.14f * g;
    float gg = 0.78f + 0.14f * g;
    float b = 0.20f;
    const int n = 5;
    float px[n + 1], py[n + 1], pz[n + 1], ww[n + 1];
    for (int j = 0; j <= n; j++) {
        float u = j / static_cast<float>(n);
        px[j] = bx + dx * len * reach * u;
        pz[j] = bz + dz * len * reach * u;
        py[j] = by + len * (kU * u - droop * u * u);
        float sv = sin(3.1415927f * (0.08f + 0.92f * u));
        if (Cfg::BANANA_PONTA_CORRIGIDA && sv < 0.0f) sv = 0.0f;   // (o original deixa -8.7e-8 aqui => NaN na ponta)
        ww[j] = hw * (0.12f + 0.88f * km::pow(sv, 0.65f));
    }
    float rib = bcol(0.12f, 0.46f, 0.11f, 1.0f);
    for (int j = 0; j < n; j++) {
        float kk = 0.88f + 0.22f * ((j * 37 + static_cast<int>(g * 10.0f)) % 5) / 4.0f;
        float colL = bcol(r, gg, b, kk);
        float colR = bcol(r, gg, b, kk * 0.82f);
        float w0 = ww[j], w1 = ww[j + 1];
        float c0x = px[j], c0y = py[j] + 0.14f * w0, c0z = pz[j];
        float c1x = px[j + 1], c1y = py[j + 1] + 0.14f * w1, c1z = pz[j + 1];
        float l0x = px[j] + sx * w0, l0y = py[j] - 0.22f * w0, l0z = pz[j] + sz * w0;
        float l1x = px[j + 1] + sx * w1, l1y = py[j + 1] - 0.22f * w1, l1z = pz[j + 1] + sz * w1;
        float r0x = px[j] - sx * w0, r0z = pz[j] - sz * w0;
        float r1x = px[j + 1] - sx * w1, r1z = pz[j + 1] - sz * w1;
        triUp(acc, c0x, c0y, c0z, l0x, l0y, l0z, l1x, l1y, l1z, colL);
        triUp(acc, c0x, c0y, c0z, l1x, l1y, l1z, c1x, c1y, c1z, colL);
        triUp(acc, c0x, c0y, c0z, r0x, l0y, r0z, r1x, l1y, r1z, colR);
        triUp(acc, c0x, c0y, c0z, r1x, l1y, r1z, c1x, c1y, c1z, colR);
        triUp(acc, c0x - sx * 0.05f, c0y + 0.02f, c0z - sz * 0.05f, c0x + sx * 0.05f, c0y + 0.02f, c0z + sz * 0.05f, c1x + sx * 0.05f, c1y + 0.02f, c1z + sz * 0.05f, rib);
        triUp(acc, c0x - sx * 0.05f, c0y + 0.02f, c0z - sz * 0.05f, c1x + sx * 0.05f, c1y + 0.02f, c1z + sz * 0.05f, c1x - sx * 0.05f, c1y + 0.02f, c1z - sz * 0.05f, rib);
    }
}

// Fruta PENDURADA por um cordãozinho: o cordão nasce DENTRO da copa, sai pela parte de baixo.
void hangFruit(MeshAccum& acc, float cx, float cy, float cz, float rx, float ry,
               float ang, float dyN, float drop, float fr, float fry, float fcol, float cordCol, JavaRandom& rng,
               std::vector<float>* out = nullptr, float phaseDays = 0.0f) {
    float ch = sqrt(max(1.0f - dyN * dyN, 0.0f));
    float ax = cx + cos(ang) * ch * rx * 0.78f;
    float az = cz + sin(ang) * ch * rx * 0.78f;
    float ay = cy + dyN * ry * 0.78f;
    float ph = km::coerceIn(sqrt((ax - cx) * (ax - cx) + (az - cz) * (az - cz)) / rx, 0.0f, 0.97f);
    float ye = cy - ry * 0.80f * sqrt(max(1.0f - ph * ph, 0.01f));   // onde a casca facetada acaba, embaixo
    if (ye > ay) ye = ay;
    float fy = ye - drop - fry;
    float cordEnd = fy + fry * 0.85f;
    if (out == nullptr) {
        fruit(acc, ax, fy, az, fr, fry, fcol, rng);
    } else {
        // fruta DINAMICA (Frutas.kt): aqui so fica o cordao; guardamos onde ele termina (12 floats, igual aos cocos)
        float la = rng.nextFloat() * TP;
        float ld = 0.25f + rng.nextFloat() * 0.9f;
        out->push_back(ax); out->push_back(cordEnd); out->push_back(az); out->push_back(fr);
        out->push_back(acc.windBaseY); out->push_back(acc.windH); out->push_back(acc.windAmp); out->push_back(acc.windPhase);
        out->push_back(phaseDays); out->push_back(rng.nextFloat()); out->push_back(cos(la) * ld); out->push_back(sin(la) * ld);
    }
    // cordão: da dentro da copa até o topo da fruta
    prism(acc, ax, ay, az, 0.035f, ax, cordEnd, az, 0.025f, 4, cordCol);
}

// Folhas-losango densas sobre um elipsoide (copa de macieira/laranjeira).
void leafShell(MeshAccum& acc, float cx, float cy, float cz, float rx, float ry, float rz,
               int n, float len, float wid, float dr, float dg, float db, float lr, float lg, float lb,
               JavaRandom& rng, float yMin = -0.5f) {
    if (!Cfg::FOLHAS_SOLTAS) return;   // copa lisinha: sem as folhas-losango saindo
    int cnt = nL(n);
    for (int i = 0; i < cnt; i++) {
        float dx = rng.nextFloat() * 2.0f - 1.0f;
        float dz = rng.nextFloat() * 2.0f - 1.0f;
        float dy = yMin + rng.nextFloat() * (1.0f - yMin);
        float l = sqrt(dx * dx + dy * dy + dz * dz);
        if (l < 0.1f) continue;
        float q = rng.nextFloat();
        float col = bcol(dr + (lr - dr) * q, dg + (lg - dg) * q, db + (lb - db) * q, 1.0f);
        float s = 0.75f + rng.nextFloat() * 0.5f;
        float phi = rng.nextFloat() * TP;
        leafOn(acc, cx, cy, cz, rx, ry, rz, dx / l, dy / l, dz / l, len * s, wid * s, phi, col, 0.3f);
    }
}
}  // namespace

namespace Trees {

void windTree(MeshAccum& a, float baseY, float h, int64_t seed, float amp) {
    a.windBaseY = baseY;
    a.windH = h;
    a.windAmp = amp;
    a.windPhase = static_cast<int>(seed & 0xffffLL) / 65535.0f * 6.2831855f;
}

void blob(MeshAccum& acc, float cx, float cy, float cz, float rx, float ry, float rz, float col, float jit, JavaRandom& rng) {
    const float* ico = ICO();
    float v[36];
    for (int k = 0; k < 12; k++) {
        float j = 1.0f + (rng.nextFloat() - 0.5f) * jit;
        v[k * 3] = cx + ico[k * 3] * rx * j;
        v[k * 3 + 1] = cy + ico[k * 3 + 1] * ry * j;
        v[k * 3 + 2] = cz + ico[k * 3 + 2] * rz * j;
    }
    // degradê vertical: faces viradas para cima ficam mais claras (e levemente mais quentes), as de baixo mais escuras
    uint32_t ic = floatToIntColor(col);
    float cr = (ic & 0xFF) / 255.0f;
    float cg = ((ic >> 8) & 0xFF) / 255.0f;
    float cbb = ((ic >> 16) & 0xFF) / 255.0f;
    for (int f = 0; f < 20; f++) {
        int a = FACES[f * 3] * 3;
        int b = FACES[f * 3 + 1] * 3;
        int c = FACES[f * 3 + 2] * 3;
        float ox = (v[a] + v[b] + v[c]) / 3.0f - cx;
        float oy = (v[a + 1] + v[b + 1] + v[c + 1]) / 3.0f - cy;
        float oz = (v[a + 2] + v[b + 2] + v[c + 2]) / 3.0f - cz;
        float ol = max(sqrt(ox * ox + oy * oy + oz * oz), 1e-4f);
        float ny = oy / ol;
        float k = 0.86f + 0.24f * ny;
        float fcol = toFloatBits(min(1.0f, cr * k * (1.0f + 0.05f * ny)), min(1.0f, cg * k), min(1.0f, cbb * k * (1.0f - 0.06f * ny)), 1.0f);
        acc.triOut(v[a], v[a + 1], v[a + 2], v[b], v[b + 1], v[b + 2], v[c], v[c + 1], v[c + 2], cx, cy, cz, fcol);
    }
}

void blobRock(MeshAccum& acc, float cx, float cy, float cz, float rx, float ry, float rz, float col, float jit, JavaRandom& rng) {
    const float* ico = ICO();
    float v[36];
    for (int k = 0; k < 12; k++) {
        float j = 1.0f + (rng.nextFloat() - 0.5f) * jit;
        v[k * 3] = cx + ico[k * 3] * rx * j;
        v[k * 3 + 1] = cy + ico[k * 3 + 1] * ry * j;
        v[k * 3 + 2] = cz + ico[k * 3 + 2] * rz * j;
    }
    for (int f = 0; f < 20; f++) {
        int a = FACES[f * 3] * 3;
        int b = FACES[f * 3 + 1] * 3;
        int c = FACES[f * 3 + 2] * 3;
        acc.triOutUV(v[a], v[a + 1], v[a + 2], v[b], v[b + 1], v[b + 2], v[c], v[c + 1], v[c + 2], cx, cy, cz, col, true);
    }
}

// Árvore grande "TREE_01": base larga (raízes), tronco que afina e gira, galhos grossos, copa de ~15 bolotas
// cobertas de folhas e moitas na base. Altura = hh (7-9 m).
void bigTree(MeshAccum& acc, float x, float y, float z, float hh, JavaRandom& rng, const Apiario::Hive* hive) {
    acc.windFlutter = 0.0f;
    float sc = hh / 8.0f;
    float la = rng.nextFloat() * TP;
    float leanK = hive != nullptr ? 0.0f : 0.5f * sc;      // arvore da colmeia: tronco reto (o ninho tem posicao fixa)
    float lx = cos(la) * leanK;
    float lz = sin(la) * leanK;
    const float ts[6] = {-0.05f, 0.05f, 0.18f, 0.38f, 0.60f, 0.78f};
    const float rs[6] = {1.25f, 0.82f, 0.62f, 0.52f, 0.44f, 0.38f};
    float twist = (0.7f + rng.nextFloat() * 0.5f) * 3.0f;
    float a0 = rng.nextFloat() * TP;
    for (int i = 0; i < 5; i++) {
        float t0 = ts[i], t1 = ts[i + 1];
        trunkSeg(acc,
                 x + lx * t0 * t0, y + hh * t0, z + lz * t0 * t0, rs[i] * sc, a0 + twist * t0,
                 x + lx * t1 * t1, y + hh * t1, z + lz * t1 * t1, rs[i + 1] * sc, a0 + twist * t1,
                 8, rng, 1.0f, 0.46f, 0.30f, 0.17f);
    }
    float tx = x + lx * 0.78f * 0.78f;
    float tz = z + lz * 0.78f * 0.78f;
    float ty = y + hh * 0.78f;
    (void)ty;

    const int nb = 4;
    float tipX[nb], tipY[nb], tipZ[nb];
    for (int i = 0; i < nb; i++) {
        float ba = i * TP / nb + rng.nextFloat() * 0.8f;
        float bt = 0.5f + rng.nextFloat() * 0.2f;
        float bx0 = x + lx * bt * bt + cos(ba) * 0.3f * sc;
        float by0 = y + hh * bt;
        float bz0 = z + lz * bt * bt + sin(ba) * 0.3f * sc;
        float len = (1.9f + rng.nextFloat() * 1.0f) * sc;
        float bx1 = bx0 + cos(ba) * len * 0.55f, by1 = by0 + 0.9f * sc, bz1 = bz0 + sin(ba) * len * 0.55f;
        float bx2 = bx0 + cos(ba) * len, by2 = by1 + 0.9f * sc, bz2 = bz0 + sin(ba) * len;
        trunkSeg(acc, bx0, by0, bz0, 0.26f * sc, 0.0f, bx1, by1, bz1, 0.17f * sc, 0.0f, 5, rng, 1.05f, 0.46f, 0.30f, 0.17f);
        trunkSeg(acc, bx1, by1, bz1, 0.17f * sc, 0.0f, bx2, by2, bz2, 0.10f * sc, 0.0f, 5, rng, 1.05f, 0.46f, 0.30f, 0.17f);
        tipX[i] = bx2; tipY[i] = by2; tipZ[i] = bz2;
    }

    std::vector<std::array<float, 3>> extra;
    if (hive != nullptr) {
        // galho comprido do NINHO (aponta para onde a colmeia olha), a ~2,8 m do chao: o ninho pende da ponta (Colmeias.kt)
        float hx0 = hive->wx(0.0f, 0.0f), hz0 = hive->wz(0.0f, 0.0f);
        float hx1 = hive->wx(0.0f, 0.95f), hz1 = hive->wz(0.0f, 0.95f);
        float hx2 = hive->wx(0.0f, 1.75f), hz2 = hive->wz(0.0f, 1.75f);
        trunkSeg(acc, hx0, y + 2.62f, hz0, 0.30f, 0.0f, hx1, y + 2.86f, hz1, 0.20f, 0.0f, 6, rng, 1.05f, 0.46f, 0.30f, 0.17f);
        trunkSeg(acc, hx1, y + 2.86f, hz1, 0.20f, 0.0f, hx2, y + 2.84f, hz2, 0.12f, 0.0f, 6, rng, 1.05f, 0.46f, 0.30f, 0.17f);
        // mais 2 galhos grossos para o outro lado, com copa na ponta
        float fa = km::atan2(cos(hive->yaw), sin(hive->yaw));
        for (int k = 0; k < 2; k++) {
            float ba = fa + (k == 0 ? 2.1f : -2.2f);
            float ex0 = x + cos(ba) * 0.3f * sc;
            float ey0 = y + hh * (0.34f + 0.05f * k);
            float ez0 = z + sin(ba) * 0.3f * sc;
            float elen = 2.8f * sc;
            float ex1 = ex0 + cos(ba) * elen * 0.55f, ey1 = ey0 + 0.9f * sc, ez1 = ez0 + sin(ba) * elen * 0.55f;
            float ex2 = ex0 + cos(ba) * elen, ey2 = ey1 + 0.9f * sc, ez2 = ez0 + sin(ba) * elen;
            trunkSeg(acc, ex0, ey0, ez0, 0.30f * sc, 0.0f, ex1, ey1, ez1, 0.19f * sc, 0.0f, 5, rng, 1.05f, 0.46f, 0.30f, 0.17f);
            trunkSeg(acc, ex1, ey1, ez1, 0.19f * sc, 0.0f, ex2, ey2, ez2, 0.11f * sc, 0.0f, 5, rng, 1.05f, 0.46f, 0.30f, 0.17f);
            extra.push_back({ex2, ey2, ez2});
        }
    }

    acc.windFlutter = 1.0f;
    // copa: cume, anel interno, anel externo (mais baixo/escuro), pontas dos galhos
    float cy = y + hh * 0.70f;
    {
        float t = 0.85f + rng.nextFloat() * 0.15f;
        leafBall(acc, tx, cy + 1.0f * sc, tz, 1.4f * sc, t, rng);
    }
    float off1 = rng.nextFloat() * TP;
    for (int i = 0; i < 5; i++) {
        float a = off1 + i * TP / 5.0f;
        float dy = (rng.nextFloat() * 0.6f - 0.1f) * sc;
        float r = (1.15f + rng.nextFloat() * 0.3f) * sc;
        float t = 0.5f + dy * 0.4f + rng.nextFloat() * 0.25f;
        leafBall(acc, tx + cos(a) * 1.8f * sc, cy + dy, tz + sin(a) * 1.8f * sc, r, t, rng);
    }
    float off2 = rng.nextFloat() * TP;
    for (int i = 0; i < 5; i++) {
        float a = off2 + i * TP / 5.0f;
        float r = (1.0f + rng.nextFloat() * 0.3f) * sc;
        float t = 0.2f + rng.nextFloat() * 0.3f;
        leafBall(acc, tx + cos(a) * 3.1f * sc, cy - 0.9f * sc, tz + sin(a) * 3.1f * sc, r, t, rng);
    }
    for (int i = 0; i < nb; i++) {
        float t = 0.3f + rng.nextFloat() * 0.4f;
        leafBall(acc, tipX[i], tipY[i] + 0.5f * sc, tipZ[i], 1.05f * sc, t, rng);
    }
    if (hive != nullptr) {                  // arvore da colmeia: bem mais cheia de folhas
        for (const auto& e : extra) {
            float t = 0.3f + rng.nextFloat() * 0.4f;
            leafBall(acc, e[0], e[1] + 0.5f * sc, e[2], 1.2f * sc, t, rng);
        }
        float off3 = rng.nextFloat() * TP;
        for (int i = 0; i < 7; i++) {
            float a = off3 + i * TP / 7.0f;
            float r = (1.1f + rng.nextFloat() * 0.3f) * sc;
            float t = 0.4f + rng.nextFloat() * 0.4f;
            leafBall(acc, tx + cos(a) * 2.5f * sc, cy + 0.5f * sc, tz + sin(a) * 2.5f * sc, r, t, rng);
        }
        leafBall(acc, tx + 0.7f * sc, cy + 2.0f * sc, tz - 0.5f * sc, 1.1f * sc, 0.9f, rng);
        leafBall(acc, tx - 0.8f * sc, cy + 1.7f * sc, tz + 0.6f * sc, 1.0f * sc, 0.85f, rng);
    }

    // moitas de folhas na base
    int nm = 2 + rng.nextInt(2);
    for (int i = 0; i < nm; i++) {
        float a = rng.nextFloat() * TP;
        float d = (1.4f + rng.nextFloat() * 0.9f) * sc;
        float r = (0.4f + rng.nextFloat() * 0.35f) * sc;
        float t = 0.55f + rng.nextFloat() * 0.4f;
        leafBall(acc, x + cos(a) * d, y + 0.35f * sc, z + sin(a) * d, r, t, rng, 5);
    }
}

// Coqueiro: 70% RETOS e 30% TORTOS. Cocos REDONDOS pendurados embaixo das folhas.
void palm(MeshAccum& acc, float x, float y, float z, float hh0, JavaRandom& rng, std::vector<float>& cocoOut) {
    bool curved = rng.nextFloat() < 0.3f;
    float hh = curved ? hh0 * 0.85f : hh0;
    float lean = curved ? 2.6f + rng.nextFloat() * 1.6f : (rng.nextFloat() - 0.5f) * 0.5f;
    float ang = rng.nextFloat() * TP;
    float lx = cos(ang) * lean;
    float lz = sin(ang) * lean;
    float rBase = curved ? 0.50f : 0.32f;
    float rTop = curved ? 0.34f : 0.20f;
    const int sides = 8;
    int nseg = std::max(8, static_cast<int>(hh / (curved ? 0.72f : 0.62f)));
    float spotCol = curved ? bcol(0.33f, 0.19f, 0.10f, 1.0f) : bcol(0.07f, 0.05f, 0.04f, 1.0f);

    acc.windFlutter = 0.0f;                                   // tronco: só dobra com o vento
    for (int i = 0; i < nseg; i++) {
        float t0 = i / static_cast<float>(nseg);
        float t1 = (i + 1) / static_cast<float>(nseg);
        float r0 = (rBase + (rTop - rBase) * t0) * 0.85f;
        float r1 = (rBase + (rTop - rBase) * t1) * 1.04f;
        float x0 = x + lx * t0 * t0, z0 = z + lz * t0 * t0, y0 = y + hh * t0 - (i == 0 ? 0.2f : 0.0f);
        float x1 = x + lx * t1 * t1, z1 = z + lz * t1 * t1, y1 = y + hh * t1;
        int ns = curved ? 1 : 1 + rng.nextInt(2);
        trunkSeg(acc, x0, y0, z0, r0, i * 0.35f, x1, y1, z1, r1, i * 0.35f, sides, rng, 1.0f, 0.47f, 0.32f, 0.19f, ns, spotCol);
        // TAMPA o degrau entre este gomo (topo largo, r1) e o proximo (base estreita)
        float capCol = bcol(0.47f, 0.32f, 0.19f, 0.85f);
        if (i < nseg - 1) {
            float rn = (rBase + (rTop - rBase) * t1) * 0.85f;      // raio da base do proximo gomo
            float an = (i + 1) * 0.35f;
            float da = TP / sides;
            for (int s = 0; s < sides; s++) {
                float oax = x1 + cos(i * 0.35f + s * da) * r1,       oaz = z1 + sin(i * 0.35f + s * da) * r1;
                float obx = x1 + cos(i * 0.35f + (s + 1) * da) * r1, obz = z1 + sin(i * 0.35f + (s + 1) * da) * r1;
                float iax = x1 + cos(an + s * da) * rn,              iaz = z1 + sin(an + s * da) * rn;
                float ibx = x1 + cos(an + (s + 1) * da) * rn,        ibz = z1 + sin(an + (s + 1) * da) * rn;
                acc.triOut(oax, y1, oaz, obx, y1, obz, ibx, y1, ibz, x1, y1 - 1.0f, z1, capCol);
                acc.triOut(oax, y1, oaz, ibx, y1, ibz, iax, y1, iaz, x1, y1 - 1.0f, z1, capCol);
            }
        } else {
            // topo do tronco fechado (tampa)
            float da = TP / sides;
            for (int s = 0; s < sides; s++) {
                float ax2 = x1 + cos(i * 0.35f + s * da) * r1,       az2 = z1 + sin(i * 0.35f + s * da) * r1;
                float bx2 = x1 + cos(i * 0.35f + (s + 1) * da) * r1, bz2 = z1 + sin(i * 0.35f + (s + 1) * da) * r1;
                acc.triOut(ax2, y1, az2, bx2, y1, bz2, x1, y1, z1, x1, y1 - 1.0f, z1, capCol);
            }
        }
    }

    float tx = x + lx;
    float tz = z + lz;
    float ty = y + hh;

    acc.windFlutter = 1.0f;                                   // folhas: dobram e tremulam
    int nf = curved ? 8 : 10;
    float off = rng.nextFloat() * TP;
    for (int i = 0; i < nf; i++) {
        float a = off + i * TP / nf + (rng.nextFloat() - 0.5f) * 0.3f;
        float len = curved ? 3.6f + rng.nextFloat() * 0.7f : 4.2f + rng.nextFloat() * 0.9f;
        frond(acc, tx, ty + 0.1f, tz, a, len, i % 4 == 0, curved, rng);
    }

    // cocos: o CACHO (cabo + cordoes) fica desenhado no coqueiro; os COCOS em si sao dinamicos (Coconuts.kt)
    float cr = curved ? 0.38f : 0.28f;
    int nc = 4 + rng.nextInt(2);
    float strandCol = bcol(0.40f, 0.31f, 0.13f, 1.0f);
    float ha = rng.nextFloat() * TP;
    float hubX = tx + cos(ha) * 0.22f;
    float hubZ = tz + sin(ha) * 0.22f;
    float hubY = ty - 0.40f;
    float palmOff = rng.nextFloat() * 7.0f;
    acc.windFlutter = 0.3f;
    prism(acc, tx, ty - 0.02f, tz, 0.07f, hubX, hubY, hubZ, 0.05f, 5, strandCol);
    for (int k = 0; k < nc; k++) {
        float ca = rng.nextFloat() * TP;
        float rad = 0.28f + rng.nextFloat() * 0.30f;
        float ccx = hubX + cos(ca) * rad;
        float ccy = hubY - cr * 1.15f - 0.12f - rng.nextFloat() * 0.25f;
        float ccz = hubZ + sin(ca) * rad;
        acc.windFlutter = 0.9f;
        prism(acc, hubX, hubY, hubZ, 0.032f, ccx, ccy + cr, ccz, 0.028f, 4, strandCol);   // cordao do coco
        float la = rng.nextFloat() * TP;
        float ld = 0.35f + rng.nextFloat() * 1.0f;
        float offc = Cfg::COCO_SINCRONIZADO ? rng.nextFloat() * 0.3f : palmOff + (rng.nextFloat() - 0.5f) * 0.5f;
        float sd = rng.nextFloat();
        cocoOut.push_back(ccx); cocoOut.push_back(ccy + cr); cocoOut.push_back(ccz); cocoOut.push_back(cr);
        cocoOut.push_back(acc.windBaseY); cocoOut.push_back(acc.windH); cocoOut.push_back(acc.windAmp); cocoOut.push_back(acc.windPhase);
        cocoOut.push_back(offc); cocoOut.push_back(sd); cocoOut.push_back(cos(la) * ld); cocoOut.push_back(sin(la) * ld);
    }
}

// Bananeira: tronco reto em gomos cobertos de manchas de musgo, 8 folhas largas e 1 cacho (dinâmico, Bananas.kt).
void banana(MeshAccum& acc, float x, float y, float z, float hh, JavaRandom& rng, std::vector<float>& bananaOut) {
    acc.windFlutter = 0.0f;
    float rBase = 0.36f;
    float rTop = 0.27f;
    int nseg = std::max(6, static_cast<int>(hh / 0.62f));
    for (int i = 0; i < nseg; i++) {
        float t0 = i / static_cast<float>(nseg);
        float t1 = (i + 1) / static_cast<float>(nseg);
        float r0 = (rBase + (rTop - rBase) * t0) * 0.86f;
        float r1 = (rBase + (rTop - rBase) * t1) * 1.03f;
        float y0 = y + hh * t0 - (i == 0 ? 0.2f : 0.0f);
        float y1 = y + hh * t1;
        trunkSeg(acc, x, y0, z, r0, i * 0.4f, x, y1, z, r1, i * 0.4f, 8, rng, 1.0f, 0.53f, 0.42f, 0.32f);
        int ns = 3 + rng.nextInt(2);
        for (int q = 0; q < ns; q++) {
            float sa = rng.nextFloat() * TP;
            float tt = 0.12f + rng.nextFloat() * 0.76f;
            float rr = r0 + (r1 - r0) * tt;
            float size = 0.12f + rng.nextFloat() * 0.14f;
            float kc = 0.8f + rng.nextFloat() * 0.4f;
            spotOn(acc, x, y0 + (y1 - y0) * tt, z, cos(sa), 0.0f, sin(sa), rr + 0.02f, size, bcol(0.30f, 0.42f, 0.10f, kc));
        }
    }
    float ty = y + hh;
    acc.windFlutter = 1.0f;
    const int nl = 8;
    float off = rng.nextFloat() * TP;
    for (int i = 0; i < nl; i++) {
        float a = off + i * TP / nl + (rng.nextFloat() - 0.5f) * 0.3f;
        float len = 3.0f + rng.nextFloat() * 0.6f;
        float hw = 0.68f + rng.nextFloat() * 0.15f;
        bananaLeaf(acc, x, ty + 0.05f, z, a, len, hw, i % 4 == 0, rng);
    }
    // o talo, o coracao e o cacho sao DINAMICOS (Bananas.kt): aqui so guardamos onde o talo nasce
    if (rng.nextFloat() < 0.9f) {
        float la = rng.nextFloat() * TP;
        float ld = 0.3f + rng.nextFloat() * 0.6f;
        bananaOut.push_back(x); bananaOut.push_back(ty - 0.15f); bananaOut.push_back(z);
        bananaOut.push_back(acc.windBaseY); bananaOut.push_back(acc.windH); bananaOut.push_back(acc.windAmp); bananaOut.push_back(acc.windPhase);
        bananaOut.push_back(rng.nextFloat() * 9.5f);                 // fase propria (dias) dentro do ciclo de 9,5 dias
        bananaOut.push_back(rng.nextFloat());                        // semente
        bananaOut.push_back(rng.nextFloat() * TP);                   // direcao do talo
        bananaOut.push_back(cos(la) * ld); bananaOut.push_back(sin(la) * ld);
    }
}

// Macieira: base larga, tronco grosso que abre em 3 galhos em "V" + 2 laterais, copa enorme e ~5-9 maçãs. 5-6 m.
void appleTree(MeshAccum& acc, float x, float y, float z, float hh, JavaRandom& rng, std::vector<float>& macaOut) {
    acc.windFlutter = 0.0f;
    float sc = hh / 6.0f;
    const float ys[5] = {-0.25f, 0.15f, 0.9f, 1.8f, 2.5f};
    const float rs[5] = {1.7f, 1.2f, 0.98f, 0.88f, 0.80f};
    float a0 = rng.nextFloat() * TP;
    for (int i = 0; i < 4; i++) {
        trunkSeg(acc, x, y + ys[i] * sc, z, rs[i] * sc, a0 + i * 0.2f, x, y + ys[i + 1] * sc, z, rs[i + 1] * sc, a0 + (i + 1) * 0.2f, 7, rng, 0.95f, 0.42f, 0.27f, 0.15f);
    }
    // nós do tronco
    for (int q = 0; q < 4; q++) {
        float sa = rng.nextFloat() * TP;
        float yy = y + (0.6f + rng.nextFloat() * 1.6f) * sc;
        spotOn(acc, x, yy, z, cos(sa), 0.0f, sin(sa), 0.92f * sc, 0.16f * sc, bcol(0.50f, 0.33f, 0.18f, 1.0f));
    }
    float top = y + 2.5f * sc;
    float tipX[5], tipY[5], tipZ[5];
    float bo = rng.nextFloat() * TP;
    for (int i = 0; i < 3; i++) {                                   // galhos principais em V
        float ba = bo + i * TP / 3.0f + (rng.nextFloat() - 0.5f) * 0.4f;
        float sx0 = x + cos(ba) * 0.35f * sc, sz0 = z + sin(ba) * 0.35f * sc, sy0 = top - 0.1f * sc;
        float mx = sx0 + cos(ba) * 1.3f * sc, my = sy0 + 1.5f * sc, mz = sz0 + sin(ba) * 1.3f * sc;
        float ex = sx0 + cos(ba) * 2.4f * sc, ey = sy0 + 2.6f * sc, ez = sz0 + sin(ba) * 2.4f * sc;
        trunkSeg(acc, sx0, sy0, sz0, 0.45f * sc, 0.0f, mx, my, mz, 0.32f * sc, 0.0f, 5, rng, 0.95f, 0.42f, 0.27f, 0.15f);
        trunkSeg(acc, mx, my, mz, 0.32f * sc, 0.0f, ex, ey, ez, 0.18f * sc, 0.0f, 5, rng, 0.95f, 0.42f, 0.27f, 0.15f);
        tipX[i] = ex; tipY[i] = ey; tipZ[i] = ez;
    }
    for (int i = 0; i < 2; i++) {                                   // galhos laterais mais baixos
        float ba = bo + 0.9f + i * 3.1f + rng.nextFloat() * 0.5f;
        float sx0 = x + cos(ba) * 0.7f * sc, sz0 = z + sin(ba) * 0.7f * sc;
        float sy0 = y + (1.5f + rng.nextFloat() * 0.4f) * sc;
        float ex = sx0 + cos(ba) * 2.3f * sc, ey = sy0 + 0.9f * sc, ez = sz0 + sin(ba) * 2.3f * sc;
        trunkSeg(acc, sx0, sy0, sz0, 0.3f * sc, 0.0f, ex, ey, ez, 0.12f * sc, 0.0f, 5, rng, 0.95f, 0.42f, 0.27f, 0.15f);
        tipX[3 + i] = ex; tipY[3 + i] = ey; tipZ[3 + i] = ez;
    }
    // prolonga o tronco para dentro da copa (sem fresta entre o tronco e as folhas)
    trunkSeg(acc, x, top, z, 0.80f * sc, 0.0f, x, top + 1.5f * sc, z, 0.62f * sc, 0.0f, 7, rng, 0.95f, 0.42f, 0.27f, 0.15f);
    acc.windFlutter = 1.0f;
    // copa: 1 central grande + anel de 4 + pontas dos galhos (as 2 laterais são menores)
    float cxs[10], cys[10], czs[10], crs[10];
    cxs[0] = x; cys[0] = top + 1.9f * sc; czs[0] = z; crs[0] = 2.3f * sc;      // a copa ENCOSTA no tronco
    float mo = rng.nextFloat() * TP;
    for (int i = 0; i < 4; i++) {
        float a = mo + i * TP / 4.0f;
        cxs[1 + i] = x + cos(a) * 2.2f * sc; cys[1 + i] = top + 1.45f * sc; czs[1 + i] = z + sin(a) * 2.2f * sc; crs[1 + i] = 1.8f * sc;
    }
    for (int i = 0; i < 3; i++) { cxs[5 + i] = tipX[i]; cys[5 + i] = tipY[i] + 0.5f * sc; czs[5 + i] = tipZ[i]; crs[5 + i] = 1.4f * sc; }
    for (int i = 0; i < 2; i++) { cxs[8 + i] = tipX[3 + i]; cys[8 + i] = tipY[3 + i] + 0.3f * sc; czs[8 + i] = tipZ[3 + i]; crs[8 + i] = 0.95f * sc; }
    for (int i = 0; i < 10; i++) {
        float r = crs[i];
        blob(acc, cxs[i], cys[i], czs[i], r * 0.92f, r * 0.85f, r * 0.92f, bcol(0.14f, 0.40f, 0.14f, 1.0f), 0.25f, rng);
        leafShell(acc, cxs[i], cys[i], czs[i], r * 0.98f, r * 0.92f, r * 0.98f, static_cast<int>(r * 15.0f / sc), 0.75f * sc, 0.26f * sc,
                  0.06f, 0.40f, 0.13f, 0.46f, 0.60f, 0.17f, rng);
    }
    // tufos de folhas (mais claros) sobre a copa
    for (int i = 0; i < 5; i++) {
        for (int rep = 0; rep < 2; rep++) {
            float ang = rng.nextFloat() * TP;
            float dy = 0.15f + rng.nextFloat() * 0.7f;
            float ch = sqrt(1.0f - dy * dy);
            float r = crs[i];
            float kc = 0.9f + rng.nextFloat() * 0.2f;
            blob(acc, cxs[i] + cos(ang) * ch * r * 0.80f, cys[i] + dy * r * 0.78f, czs[i] + sin(ang) * ch * r * 0.80f,
                 r * 0.36f, r * 0.30f, r * 0.36f, bcol(0.20f, 0.50f, 0.17f, kc), 0.3f, rng);
        }
    }
    // maçãs PENDURADAS por cordãozinho (5, 7 ou 9 por árvore). Só o cordão é desenhado aqui.
    static const int NM[3] = {5, 7, 9};
    int nMacas = NM[rng.nextInt(3)];
    for (int q = 0; q < nMacas; q++) {
        int i = rng.nextInt(8);
        float r = crs[i];
        float ang = rng.nextFloat() * TP;
        float dyN = -(0.10f + rng.nextFloat() * 0.65f);
        float ph = rng.nextFloat() * 5.0f;
        hangFruit(acc, cxs[i], cys[i], czs[i], r * 0.92f, r * 0.85f, ang, dyN, 0.40f * sc, 0.23f * sc, 0.22f * sc,
                  0.0f, bcol(0.30f, 0.36f, 0.12f, 1.0f), rng, &macaOut, ph);
    }
}

// Laranjeira: tronco curto, MUITO grosso e retorcido, base em lobos, copa em cúpula e ~18 laranjas. 5-6 m.
void orangeTree(MeshAccum& acc, float x, float y, float z, float hh, JavaRandom& rng, std::vector<float>& laranjaOut) {
    acc.windFlutter = 0.0f;
    float sc = hh / 5.5f;
    const float ys[6] = {-0.15f, 0.4f, 1.0f, 1.7f, 2.4f, 3.2f};    // o ultimo trecho entra dentro da copa
    const float rs[6] = {1.6f, 1.15f, 0.92f, 0.86f, 0.82f, 0.70f};
    float a0 = rng.nextFloat() * TP;
    for (int i = 0; i < 5; i++) {
        trunkSeg(acc, x, y + ys[i] * sc, z, rs[i] * sc, a0 + i * 0.6f, x, y + ys[i + 1] * sc, z, rs[i + 1] * sc, a0 + (i + 1) * 0.6f, 6, rng, 0.95f, 0.50f, 0.30f, 0.14f);
    }
    // lobos grandes na base (como rochas) + caroços no meio do tronco
    for (int k = 0; k < 3; k++) {
        float a = a0 + k * 2.1f + rng.nextFloat() * 0.5f;
        float rad = 1.15f * sc;
        float kc = 0.9f + rng.nextFloat() * 0.3f;
        blob(acc, x + cos(a) * rad, y + 0.25f * sc, z + sin(a) * rad, 0.75f * sc, 0.55f * sc, 0.75f * sc, bcol(0.52f, 0.31f, 0.14f, kc), 0.25f, rng);
    }
    for (int k = 0; k < 4; k++) {
        float a = rng.nextFloat() * TP;
        float yy = y + (0.9f + k * 0.4f) * sc;
        float kc = 0.9f + rng.nextFloat() * 0.3f;
        blob(acc, x + cos(a) * 0.8f * sc, yy, z + sin(a) * 0.8f * sc, 0.32f * sc, 0.45f * sc, 0.32f * sc, bcol(0.44f, 0.26f, 0.12f, kc), 0.2f, rng);
    }
    acc.windFlutter = 1.0f;
    // copa em cúpula
    float ccy = y + 3.5f * sc;      // copa desceu: encosta e envolve o topo do tronco
    float rx = 2.7f * sc;
    float ry = 2.0f * sc;
    blob(acc, x, ccy, z, rx * 0.95f, ry * 0.95f, rx * 0.95f, bcol(0.42f, 0.54f, 0.16f, 1.0f), 0.12f, rng);
    leafShell(acc, x, ccy, z, rx, ry, rx, 150, 0.7f * sc, 0.2f * sc, 0.06f, 0.48f, 0.20f, 0.55f, 0.86f, 0.22f, rng, -0.35f);
    // tufos de folhas (mais claros) sobre a copa
    for (int q = 0; q < 7; q++) {
        float ang = rng.nextFloat() * TP;
        float dy = 0.10f + rng.nextFloat() * 0.75f;
        float ch = sqrt(1.0f - dy * dy);
        float kc = 0.9f + rng.nextFloat() * 0.2f;
        blob(acc, x + cos(ang) * ch * rx * 0.80f, ccy + dy * ry * 0.80f, z + sin(ang) * ch * rx * 0.80f,
             0.85f * sc, 0.70f * sc, 0.85f * sc, bcol(0.55f, 0.66f, 0.22f, kc), 0.3f, rng);
    }
    // laranjas PENDURADAS por cordãozinho, saindo da parte de baixo da copa. Só o cordão é desenhado aqui.
    for (int q = 0; q < 18; q++) {
        float ang = rng.nextFloat() * TP;
        float dyN = -(0.10f + rng.nextFloat() * 0.65f);
        float ph = rng.nextFloat() * 6.6f;
        hangFruit(acc, x, ccy, z, rx * 0.95f, ry * 0.95f, ang, dyN, 0.45f * sc, 0.3f * sc, 0.3f * sc,
                  0.0f, bcol(0.30f, 0.36f, 0.12f, 1.0f), rng, &laranjaOut, ph);
    }
}

}  // namespace Trees
