#include "Water.h"
#include <cmath>
#include <cstring>
#include "Cfg.h"
#include "Color.h"
#include "JavaRandom.h"
#include "KMath.h"
#include "World.h"

using km::max; using km::min;

namespace {
// Color.rgba8888(r,g,b,a) do libGDX: (int)(c*255) truncado
uint32_t rgba8888(float r, float g, float b, float a) {
    return (static_cast<uint32_t>(static_cast<int>(r * 255.0f)) << 24) | (static_cast<uint32_t>(static_cast<int>(g * 255.0f)) << 16) |
           (static_cast<uint32_t>(static_cast<int>(b * 255.0f)) << 8) | static_cast<uint32_t>(static_cast<int>(a * 255.0f));
}

// Mini Pixmap com a mesma matemática do gdx2d do libGDX (fillCircle, hline e mistura SRC_OVER em inteiros).
struct Pixmap {
    int w, h;
    std::vector<uint32_t> px;      // 0xRRGGBBAA
    bool blendOn = true;
    uint32_t color = 0;
    Pixmap(int w_, int h_) : w(w_), h(h_), px(static_cast<size_t>(w_) * h_, 0) {}

    void setColor(float r, float g, float b, float a) { color = rgba8888(r, g, b, a); }
    void setColor(const Color& c) { color = rgba8888(c.r, c.g, c.b, c.a); }
    void fill() { for (auto& p : px) p = color; }

    static uint32_t blend(uint32_t src, uint32_t dst) {
        uint32_t sa = src & 0xff;
        if (sa == 0) return dst;
        uint32_t sb = (src >> 8) & 0xff, sg = (src >> 16) & 0xff, sr = (src >> 24) & 0xff;
        uint32_t da = dst & 0xff, db = (dst >> 8) & 0xff, dg = (dst >> 16) & 0xff, dr = (dst >> 24) & 0xff;
        da -= (da * sa) / 255;
        uint32_t a = da + sa;
        dr = (dr * da + sr * sa) / a;
        dg = (dg * da + sg * sa) / a;
        db = (db * da + sb * sa) / a;
        return (dr << 24) | (dg << 16) | (db << 8) | a;
    }
    void put(int x, int y) {
        if (x < 0 || y < 0 || x >= w || y >= h) return;
        uint32_t& d = px[static_cast<size_t>(y) * w + x];
        d = blendOn ? blend(color, d) : color;
    }
    void drawPixel(int x, int y) { put(x, y); }
    void hline(int x1, int x2, int y) {
        if (y < 0 || y >= h) return;
        if (x1 > x2) { int t = x1; x1 = x2; x2 = t; }
        if (x1 >= w || x2 < 0) return;
        if (x1 < 0) x1 = 0;
        if (x2 >= w) x2 = w - 1;
        for (int x = x1; x <= x2; x++) put(x, y);
    }
    void fillRectangle(int x, int y, int rw, int rh) {
        for (int j = 0; j < rh; j++) hline(x, x + rw - 1, y + j);
    }
    void fillCircle(int x0, int y0, int radius) {
        int f = 1 - radius, ddFx = 1, ddFy = -2 * radius, x = 0, y = radius;
        hline(x0 - radius, x0 + radius, y0);
        while (x < y) {
            if (f >= 0) { y--; ddFy += 2; f += ddFy; }
            x++; ddFx += 2; f += ddFx;
            hline(x0 - x, x0 + x, y0 + y);
            hline(x0 - x, x0 + x, y0 - y);
            hline(x0 - y, x0 + y, y0 + x);
            hline(x0 - y, x0 + y, y0 - x);
        }
    }
    Image toImage() const {
        Image im; im.w = w; im.h = h; im.rgba.resize(static_cast<size_t>(w) * h * 4);
        for (size_t i = 0; i < px.size(); i++) {
            im.rgba[i * 4] = static_cast<uint8_t>(px[i] >> 24); im.rgba[i * 4 + 1] = static_cast<uint8_t>(px[i] >> 16);
            im.rgba[i * 4 + 2] = static_cast<uint8_t>(px[i] >> 8); im.rgba[i * 4 + 3] = static_cast<uint8_t>(px[i]);
        }
        return im;
    }
};

constexpr float TP = 6.2831855f;
constexpr float E0 = 0.5f;          // posição média da frente da onda na textura (0..1)
constexpr float BAND = 8.0f;        // faixa de 8 m a partir da linha d'água, subindo a praia
constexpr float VLOW = 0.05f;       // frente quando a água está baixa (~0,4 m)
constexpr float VHIGH = 0.5625f;    // frente no ponto mais alto (~4,5 m praia adentro)
constexpr float CYCLE = 9.0f;       // segundos por onda
constexpr float LIFT = 0.04f;       // a lâmina fica 4 cm acima do chão (mesma malha => sem furos)

Image makeWaterTexture() {
    Pixmap pm(256, 256);
    pm.setColor(Color::hex(0x00BFFF));
    pm.fill();
    JavaRandom rnd(7);
    for (int it = 0; it < 70; it++) {                    // manchas claras/escuras suaves
        int x = rnd.nextInt(256), y = rnd.nextInt(256), r = 6 + rnd.nextInt(14);
        pm.setColor(0.0f, 0.62f + rnd.nextFloat() * 0.2f, 1.0f, 0.3f);
        for (int dx = -1; dx <= 1; dx++) for (int dy = -1; dy <= 1; dy++) pm.fillCircle(x + dx * 256, y + dy * 256, r);
    }
    for (int it = 0; it < 40; it++) {                    // manchas turquesa (água rasa/clara)
        int x = rnd.nextInt(256), y = rnd.nextInt(256), r = 8 + rnd.nextInt(16);
        pm.setColor(0.05f, 0.82f, 0.88f, 0.20f);
        for (int dx = -1; dx <= 1; dx++) for (int dy = -1; dy <= 1; dy++) pm.fillCircle(x + dx * 256, y + dy * 256, r);
    }
    for (int it = 0; it < 40; it++) {                    // manchas de azul mais fundo
        int x = rnd.nextInt(256), y = rnd.nextInt(256), r = 8 + rnd.nextInt(18);
        pm.setColor(0.0f, 0.38f, 0.85f, 0.22f);
        for (int dx = -1; dx <= 1; dx++) for (int dy = -1; dy <= 1; dy++) pm.fillCircle(x + dx * 256, y + dy * 256, r);
    }
    for (int it = 0; it < 80; it++) {                    // riscos de onda brancos
        int x0 = rnd.nextInt(256), y0 = rnd.nextInt(256), len = 10 + rnd.nextInt(20);
        pm.setColor(1.0f, 1.0f, 1.0f, 0.45f);
        for (int k = 0; k <= len; k++) {
            int x = (x0 + k) & 255;
            int y = (y0 + static_cast<int>(km::sin(static_cast<float>(k) * 0.4f) * 2.0f)) & 255;
            pm.drawPixel(x, y);
            pm.drawPixel(x, (y + 1) & 255);
        }
    }
    for (int it = 0; it < 210; it++) {                   // brilhinhos do sol na água
        int x = rnd.nextInt(256), y = rnd.nextInt(256);
        pm.setColor(1.0f, 1.0f, 1.0f, 0.80f);
        pm.fillRectangle(x, y, 1, 2);
        pm.setColor(0.8f, 1.0f, 1.0f, 0.4f);
        pm.drawPixel((x + 2) & 255, y);
        pm.drawPixel((x - 1) & 255, y);
    }
    return pm.toImage();
}

Image makeSwashTexture(bool wetLayer) {
    const int w = 512, h = 256;
    Pixmap pm(w, h);
    pm.blendOn = false;
    JavaRandom rnd(wetLayer ? 5 : 9);
    std::vector<float> lace(static_cast<size_t>(w) * h);
    for (auto& v : lace) v = rnd.nextFloat();
    for (int y = 0; y < h; y++) {
        float v = static_cast<float>(y) / (static_cast<float>(h) - 1.0f);
        for (int x = 0; x < w; x++) {
            float u = static_cast<float>(x) / static_cast<float>(w);
            float dv = Water::edgeAt(u) - v;             // > 0: atrás da frente (lado do mar); < 0: areia seca
            float ln = lace[static_cast<size_t>(y) * w + x];
            float r = 1.0f, g = 1.0f, b = 1.0f, a;
            if (wetLayer) {
                r = 0.30f; g = 0.20f; b = 0.09f;
                if (dv >= 0.0f) a = 0.34f;
                else if (dv > -0.05f) a = 0.34f * (1.0f + dv / 0.05f);
                else a = 0.0f;
            } else if (dv < -0.014f) {
                a = 0.0f;
            } else if (dv < 0.0f) {
                a = 0.9f * (1.0f + dv / 0.014f);                                  // pontinha da espuma
            } else if (dv < 0.035f) {
                a = ln > dv / 0.035f * 0.7f ? 0.95f : 0.35f;                      // renda de espuma na frente
            } else if (dv >= 0.105f && dv <= 0.125f) {
                a = ln > 0.4f ? 0.55f : 0.12f;                                    // 2ª linha de espuma, fininha
            } else {
                r = 0.72f; g = 0.97f; b = 1.0f;                                   // água rasa: bem transparente na frente
                a = 0.16f + 0.34f * min(1.0f, max(0.0f, (dv - 0.04f) / 0.25f));
            }
            pm.setColor(r, g, b, a);
            pm.drawPixel(x, y);
        }
    }
    return pm.toImage();
}

// raio (a partir do centro) onde a "profundidade" vale `target` metros, por bisseção
float radiusAt(float ang, float target) {
    float dx = km::cos(ang), dz = km::sin(ang);
    float lo = 0.0f, hi = 800.0f;
    for (int i = 0; i < 24; i++) {
        float mid = (lo + hi) / 2.0f;
        if (Base::depth(dx * mid, dz * mid) > target) lo = mid; else hi = mid;
    }
    return (lo + hi) / 2.0f;
}

void pushV(std::vector<float>& v, float x, float y, float z, float nx, float ny, float nz, float col, float u, float vv) {
    v.push_back(x); v.push_back(y); v.push_back(z); v.push_back(nx); v.push_back(ny); v.push_back(nz);
    v.push_back(col); v.push_back(u); v.push_back(vv);
}
}  // namespace

float Water::edgeAt(float u) {
    return 0.5f + 0.085f * km::sin(TP * 3.0f * u + 0.7f) + 0.055f * km::sin(TP * 7.0f * u + 2.1f) +
           0.03f * km::sin(TP * 13.0f * u + 4.0f) + 0.015f * km::sin(TP * 29.0f * u + 1.0f);
}

float Water::swashF(float p) {
    if (p < 0.28f) { float q = p / 0.28f; return 1.0f - (1.0f - q) * (1.0f - q); }
    if (p < 0.42f) return 1.0f;
    float q = (p - 0.42f) / 0.58f;
    return 1.0f - q * q * (3.0f - 2.0f * q);
}

float Water::phase(float t) { return std::fmod(t / CYCLE, 1.0f); }

Image makeNoiseTexture() {
    const int n = 256;
    auto periodic = [](int nn, int cells, int64_t seed) {
        JavaRandom rr(seed);
        std::vector<float> lat(static_cast<size_t>(cells) * cells);
        for (auto& v : lat) v = rr.nextFloat();
        std::vector<float> out(static_cast<size_t>(nn) * nn);
        for (int y = 0; y < nn; y++) {
            float fy = static_cast<float>(y) / static_cast<float>(nn) * static_cast<float>(cells);
            int y0 = static_cast<int>(fy);
            float ty = fy - static_cast<float>(y0);
            int y1 = (y0 + 1) % cells;
            float sy = ty * ty * (3.0f - 2.0f * ty);
            for (int x = 0; x < nn; x++) {
                float fx = static_cast<float>(x) / static_cast<float>(nn) * static_cast<float>(cells);
                int x0 = static_cast<int>(fx);
                float tx = fx - static_cast<float>(x0);
                int x1 = (x0 + 1) % cells;
                float sx = tx * tx * (3.0f - 2.0f * tx);
                float a = lat[static_cast<size_t>(y0) * cells + x0];
                float b = lat[static_cast<size_t>(y0) * cells + x1];
                float c = lat[static_cast<size_t>(y1) * cells + x0];
                float d = lat[static_cast<size_t>(y1) * cells + x1];
                auto lp = [](float p, float q, float t) { return p + (q - p) * t; };
                out[static_cast<size_t>(y) * nn + x] = lp(lp(a, b, sx), lp(c, d, sx), sy);
            }
        }
        return out;
    };
    auto r4 = periodic(n, 4, 11), r8 = periodic(n, 8, 12), r16 = periodic(n, 16, 13);
    auto g4 = periodic(n, 4, 14), g8 = periodic(n, 8, 15), g16 = periodic(n, 16, 16);
    auto bb = periodic(n, 32, 17), aa = periodic(n, 24, 18);
    Pixmap pm(n, n);
    pm.blendOn = false;
    for (int y = 0; y < n; y++) for (int x = 0; x < n; x++) {
        size_t k = static_cast<size_t>(y) * n + x;
        float vr = 0.5f * r4[k] + 0.3f * r8[k] + 0.2f * r16[k];
        float vg = 0.5f * g4[k] + 0.3f * g8[k] + 0.2f * g16[k];
        float cr = km::coerceIn(0.5f + (vr - 0.5f) * 1.5f, 0.0f, 1.0f);
        float cg = km::coerceIn(0.5f + (vg - 0.5f) * 1.5f, 0.0f, 1.0f);
        pm.px[k] = rgba8888(cr, cg, bb[k], aa[k]);
    }
    return pm.toImage();
}

Water::Water() {
    waterTex = makeWaterTexture();

    // grade 36x36 em vez de 1 quadrado gigante (névoa por vértice); 1 repetição da textura = 20 m
    {
        const float half = 1500.0f;
        const int cells = 36;
        const float cs = half * 2.0f / static_cast<float>(cells);
        const float tile = 20.0f;
        const float white = toFloatBits(1.0f, 1.0f, 1.0f, 1.0f);
        for (int j = 0; j < cells; j++) for (int i = 0; i < cells; i++) {
            float xa = -half + static_cast<float>(i) * cs;
            float za = -half + static_cast<float>(j) * cs;
            float xb = xa + cs, zb = za + cs;
            auto V = [&](float x, float z) { pushV(planeVerts, x, 0.0f, z, 0.0f, 1.0f, 0.0f, white, x / tile, z / tile); };
            V(xa, zb); V(xb, zb); V(xb, za);         // corner00, corner10, corner11
            V(xb, za); V(xa, za); V(xa, zb);         // corner11, corner01, corner00
        }
    }

    // anéis de espuma seguindo a costa (inclusive as curvas do ruído)
    {
        const float ranges[3][2] = {{-1.0f, -5.0f}, {-9.0f, -14.0f}, {-19.0f, -24.0f}};
        const int segs = 720;
        const float white = toFloatBits(1.0f, 1.0f, 1.0f, 1.0f);
        for (int ri = 0; ri < 3; ri++) {
            for (int k = 0; k < segs; k++) {
                float a0 = static_cast<float>(k) * 6.2831855f / static_cast<float>(segs);
                float a1 = static_cast<float>(k + 1) * 6.2831855f / static_cast<float>(segs);
                float i0 = radiusAt(a0, ranges[ri][0]), o0 = radiusAt(a0, ranges[ri][1]);
                float i1 = radiusAt(a1, ranges[ri][0]), o1 = radiusAt(a1, ranges[ri][1]);
                float c00[3] = {km::cos(a0) * i0, 0.05f, km::sin(a0) * i0};
                float c10[3] = {km::cos(a0) * o0, 0.05f, km::sin(a0) * o0};
                float c11[3] = {km::cos(a1) * o1, 0.05f, km::sin(a1) * o1};
                float c01[3] = {km::cos(a1) * i1, 0.05f, km::sin(a1) * i1};
                auto V = [&](const float* c) { pushV(foamVerts[ri], c[0], c[1], c[2], 0.0f, 1.0f, 0.0f, white, 0.0f, 0.0f); };
                V(c00); V(c10); V(c11);
                V(c11); V(c01); V(c00);
            }
        }
    }

    swashTex = makeSwashTexture(false);
    wetTex = makeSwashTexture(true);

    // lâmina da onda deitada NA PRÓPRIA MALHA do terreno (mesmos triângulos, 4 cm mais alto)
    {
        const float s = Cfg::CELL;
        const float half = Cfg::HALF;
        const int nn = static_cast<int>(2.0f * half / s);
        const int w = nn + 1;
        const float NaN = std::nanf("");
        std::vector<float> dd(static_cast<size_t>(w) * w, NaN), hh(static_cast<size_t>(w) * w, NaN);
        auto dAt = [&](int i, int j) {
            float& v = dd[static_cast<size_t>(j) * w + i];
            if (std::isnan(v)) v = Base::depth(-half + static_cast<float>(i) * s, -half + static_cast<float>(j) * s);
            return v;
        };
        auto hAt = [&](int i, int j) {
            float& v = hh[static_cast<size_t>(j) * w + i];
            if (std::isnan(v)) v = World::heightAt(-half + static_cast<float>(i) * s, -half + static_cast<float>(j) * s);
            return v;
        };
        const float reps = 22.0f;
        auto fill = [&](int i, int j, float u) {
            float x = -half + static_cast<float>(i) * s;
            float z = -half + static_cast<float>(j) * s;
            float d = dAt(i, j);
            float col = toFloatBits(1.0f, 1.0f, 1.0f, smooth(0.0f, 1.5f, d));       // some suave na linha d'água
            pushV(bandVerts, x, hAt(i, j) + LIFT, z, 0.0f, 1.0f, 0.0f, col, u, d / BAND);
        };
        auto jround = [](float v) { return std::floor(v + 0.5f); };              // Math.round(float)
        auto tri = [&](int i0, int j0, int i1, int j1, int i2, int j2) {
            float u0 = km::atan2(-half + static_cast<float>(j0) * s, -half + static_cast<float>(i0) * s) / TP * reps;
            float u1 = km::atan2(-half + static_cast<float>(j1) * s, -half + static_cast<float>(i1) * s) / TP * reps;
            float u2 = km::atan2(-half + static_cast<float>(j2) * s, -half + static_cast<float>(i2) * s) / TP * reps;
            u1 += jround((u0 - u1) / reps) * reps;                                   // costura do ângulo (±π)
            u2 += jround((u0 - u2) / reps) * reps;
            fill(i0, j0, u0); fill(i1, j1, u1); fill(i2, j2, u2);
        };
        for (int j = 0; j < nn; j++) for (int i = 0; i < nn; i++) {
            float d00 = dAt(i, j), d10 = dAt(i + 1, j), d01 = dAt(i, j + 1), d11 = dAt(i + 1, j + 1);
            float dmin = min(min(d00, d10), min(d01, d11));
            float dmax = max(max(d00, d10), max(d01, d11));
            if (dmax < 0.0f || dmin > BAND + 2.5f) continue;
            // mesma divisão em 2 triângulos que ChunkBuilder.terrain()
            if ((i + j) % 2 == 0) {
                tri(i, j, i, j + 1, i + 1, j + 1);
                tri(i, j, i + 1, j + 1, i + 1, j);
            } else {
                tri(i, j, i, j + 1, i + 1, j);
                tri(i + 1, j, i, j + 1, i + 1, j + 1);
            }
        }
    }
    applySwash(0.0f, 0.0f);
}

void Water::follow(float px, float pz) {
    planeX_ = std::floor(px / 100.0f + 0.5f) * 100.0f;     // Math.round(px/100)*100
    planeZ_ = std::floor(pz / 100.0f + 0.5f) * 100.0f;
}

void Water::applySwash(float t, float dt) {
    float f = swashF(std::fmod(t / CYCLE, 1.0f));
    wetF_ = max(f, wetF_ - dt * 0.05f);                    // areia molhada seca bem mais devagar do que a água recua
    swashOffV_ = E0 - (VLOW + f * (VHIGH - VLOW));
    wetOffV_ = E0 - (VLOW + wetF_ * (VHIGH - VLOW));
    swashOffU_ = t * 0.006f;                               // o desenho da borda corre devagar pela costa
}

void Water::update(float dt, float t) {
    off1U_ += dt * 0.010f;
    off1V_ += dt * 0.006f;
    off2U_ -= dt * 0.008f;
    off2V_ += dt * 0.012f;
    applySwash(t, dt);
    for (int i = 0; i < 3; i++) foamAlpha_[i] = 0.8f * max(0.0f, km::sin(t * 1.3f - static_cast<float>(i) * 1.1f));
}

void Water::fillFrame(WaterFrame& f) const {
    // o desenho usa a parte fracionária: com textura "Repeat" é idêntico, e evita perder precisão depois de horas
    auto fr = [](float v) { return v - std::floor(v); };
    f.planeX = planeX_; f.planeZ = planeZ_;
    f.uv1[0] = fr(off1U_); f.uv1[1] = fr(off1V_); f.uv1[2] = 1.0f; f.uv1[3] = 1.0f;
    f.uv2[0] = fr(off2U_); f.uv2[1] = fr(off2V_); f.uv2[2] = 0.6f; f.uv2[3] = 0.6f;
    f.swashOffU = fr(swashOffU_); f.swashOffV = swashOffV_; f.wetOffV = wetOffV_;
    for (int i = 0; i < 3; i++) f.foamAlpha[i] = foamAlpha_[i];
}
