#include "Wind.h"
#include "JavaRandom.h"

namespace Wind {
namespace {
float clock_ = 0.0f;
float period = 8.0f;
float dur = 4.2f;
float peak = 0.65f;
float side = 1.0f;
constexpr float baseAng = 0.6f;
JavaRandom rnd(77);
}

void update(float dt) {
    clock_ += dt;
    if (clock_ >= period) {
        clock_ -= period;
        period = 7.0f + rnd.nextFloat() * 3.0f;     // intervalo entre rajadas: ~8 s
        dur = 3.6f + rnd.nextFloat() * 1.6f;        // quanto dura a rajada
        peak = 0.45f + rnd.nextFloat() * 0.35f;     // sempre suave (nunca ventania)
        side = -side;                               // um lado, depois o outro
        float ang = baseAng + side * (1.3f + rnd.nextFloat() * 0.4f);
        dirX = km::cos(ang);                        // a direção só muda quando a rajada é ~0: sem tranco
        dirZ = km::sin(ang);
    }
    if (clock_ < dur) {
        float s = km::sin(3.1415927f * clock_ / dur);
        gust = peak * s * s;                        // sobe e desce suave
    } else {
        gust = 0.0f;
    }
}
}  // namespace Wind

namespace WindCpu {
Vec3 offset(float px, float py, float pz, float baseY, float h, float amp, float ph, float fl) {
    float t = km::coerceIn((py - baseY) / h, 0.0f, 1.0f);
    float w = t * t * amp;
    float tt = Wind::time;
    float g = Wind::gust * (0.85f + 0.15f * km::sin(tt * 0.6f + px * 0.05f + pz * 0.04f));
    float sw = 0.6f * km::sin(tt * 0.9f + ph) + 0.4f * km::sin(tt * 1.7f + ph * 1.9f + 1.3f);
    float along = 0.03f + 0.03f * km::sin(tt * 0.5f + ph) + g * (0.55f + 0.25f * sw);
    float across = 0.10f * g * km::sin(tt * 1.3f + ph * 2.1f);
    float dx = Wind::dirX;
    float dz = Wind::dirZ;
    float ox = (dx * along - dz * across) * w;
    float oz = (dz * along + dx * across) * w;
    float oy = 0.0f;
    float f = fl * km::min(1.0f, w * 3.0f);
    float fm = 0.12f + 0.88f * g;
    ox += f * 0.08f * fm * km::sin(tt * 3.1f + ph * 3.0f + px * 0.9f + pz * 0.7f);
    oz += f * 0.08f * fm * km::sin(tt * 2.7f + ph * 2.0f + pz * 0.9f + px * 0.6f);
    oy += f * 0.05f * fm * km::sin(tt * 4.3f + ph + px * 1.1f + pz * 1.3f);
    return {ox, oy, oz};
}
}  // namespace WindCpu
