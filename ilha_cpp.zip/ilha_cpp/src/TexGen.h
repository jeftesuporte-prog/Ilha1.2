#pragma once
// Port 1:1 de TexGen.kt: texturas procedurais 256x256 tileáveis (RGBA8888, bytes na ordem R,G,B,A).
// Os mipmaps são gerados depois, no upload para o Vulkan (etapa 5).
#include <cstdint>
#include <vector>

namespace TexGen {
constexpr int S = 256;
using Pixels = std::vector<uint8_t>;   // S*S*4 bytes

Pixels grass();
Pixels rock(bool moss);
Pixels sand();
Pixels forest();
}
