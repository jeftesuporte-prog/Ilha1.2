#pragma once
// Formas simples (caixa e cilindro, como o BoxShapeBuilder / CylinderShapeBuilder do libGDX) e uma transformação afim
// (como o Matrix4: translate/rotate/scale multiplicam pela DIREITA). Saem no formato de 7 floats (x y z | nx ny nz | cor).
#include <vector>
#include "KMath.h"

namespace Shapes {
using km::cos; using km::sin;

// ---------- transformação afim (equivale ao Matrix4 do libGDX: translate/rotate/scale multiplicam pela DIREITA) ----------
struct Affine {
    float r[9] = {1, 0, 0, 0, 1, 0, 0, 0, 1};   // linha a linha: x' = r0 x + r1 y + r2 z
    float t[3] = {0, 0, 0};

    Affine& translate(float x, float y, float z) {
        t[0] += r[0] * x + r[1] * y + r[2] * z;
        t[1] += r[3] * x + r[4] * y + r[5] * z;
        t[2] += r[6] * x + r[7] * y + r[8] * z;
        return *this;
    }
    Affine& scale(float s) { for (float& v : r) v *= s; return *this; }
    Affine& mulRot(const float q[9]) {
        float n[9];
        for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++)
            n[i * 3 + j] = r[i * 3] * q[j] + r[i * 3 + 1] * q[3 + j] + r[i * 3 + 2] * q[6 + j];
        for (int i = 0; i < 9; i++) r[i] = n[i];
        return *this;
    }
    Affine& rotY(float a) { float c = cos(a), s = sin(a); const float q[9] = {c, 0, s, 0, 1, 0, -s, 0, c}; return mulRot(q); }
    Affine& rotX(float a) { float c = cos(a), s = sin(a); const float q[9] = {1, 0, 0, 0, c, -s, 0, s, c}; return mulRot(q); }
    Affine& rotZ(float a) { float c = cos(a), s = sin(a); const float q[9] = {c, -s, 0, s, c, 0, 0, 0, 1}; return mulRot(q); }
    void pos(float x, float y, float z, float* o) const {
        o[0] = r[0] * x + r[1] * y + r[2] * z + t[0];
        o[1] = r[3] * x + r[4] * y + r[5] * z + t[1];
        o[2] = r[6] * x + r[7] * y + r[8] * z + t[2];
    }
    // normal: só a parte de rotação (a escala é uniforme), renormalizada
    void nor(float x, float y, float z, float* o) const {
        float a = r[0] * x + r[1] * y + r[2] * z, b = r[3] * x + r[4] * y + r[5] * z, c = r[6] * x + r[7] * y + r[8] * z;
        float l = km::sqrt(a * a + b * b + c * c);
        if (l < 1e-9f) l = 1.0f;
        o[0] = a / l; o[1] = b / l; o[2] = c / l;
    }
};

constexpr float TP = 6.2831855f;

// Emite um vértice (já no mundo) no formato de 7 floats.
inline void emit(std::vector<float>& out, const Affine& m, float px, float py, float pz, float nx, float ny, float nz, float col) {
    float p[3], n[3];
    m.pos(px, py, pz, p);
    m.nor(nx, ny, nz, n);
    out.insert(out.end(), {p[0], p[1], p[2], n[0], n[1], n[2], col});
}
inline void tri(std::vector<float>& out, const Affine& m, const float* a, const float* b, const float* c, const float* n, float col) {
    emit(out, m, a[0], a[1], a[2], n[0], n[1], n[2], col);
    emit(out, m, b[0], b[1], b[2], n[0], n[1], n[2], col);
    emit(out, m, c[0], c[1], c[2], n[0], n[1], n[2], col);
}

// BoxShapeBuilder.build(w, h, d) centrado em (cx,cy,cz): 6 faces planas, voltadas para fora (CCW).
inline void box(std::vector<float>& out, const Affine& m, float col, float cx, float cy, float cz, float w, float h, float d) {
    float x0 = cx - w * 0.5f, x1 = cx + w * 0.5f, y0 = cy - h * 0.5f, y1 = cy + h * 0.5f, z0 = cz - d * 0.5f, z1 = cz + d * 0.5f;
    auto quad = [&](const float* a, const float* b, const float* c, const float* dd, const float* n) {
        tri(out, m, a, b, c, n, col);
        tri(out, m, a, c, dd, n, col);
    };
    const float A[3] = {x0, y0, z1}, B[3] = {x1, y0, z1}, C[3] = {x1, y1, z1}, D[3] = {x0, y1, z1};   // frente (+z)
    const float E[3] = {x1, y0, z0}, F[3] = {x0, y0, z0}, G[3] = {x0, y1, z0}, H[3] = {x1, y1, z0};   // trás (-z)
    const float nF[3] = {0, 0, 1}, nB[3] = {0, 0, -1}, nL[3] = {-1, 0, 0}, nR[3] = {1, 0, 0}, nU[3] = {0, 1, 0}, nD[3] = {0, -1, 0};
    quad(A, B, C, D, nF);
    quad(E, F, G, H, nB);
    quad(F, A, D, G, nL);
    quad(B, E, H, C, nR);
    quad(D, C, H, G, nU);
    quad(F, E, B, A, nD);
}

// CylinderShapeBuilder.build(width, height, depth, divisions): lados com normal radial + duas tampas planas.
inline void cylinder(std::vector<float>& out, const Affine& m, float col, float cx, float cy, float cz, float width, float height, float depth, int div) {
    float hw = width * 0.5f, hh = height * 0.5f, hd = depth * 0.5f;
    float yb = cy - hh, yt = cy + hh;
    for (int i = 0; i < div; i++) {
        float a0 = TP * i / div, a1 = TP * (i + 1) / div;
        float c0 = cos(a0), s0 = sin(a0), c1 = cos(a1), s1 = sin(a1);
        float x0 = cx + c0 * hw, z0 = cz + s0 * hd, x1 = cx + c1 * hw, z1 = cz + s1 * hd;
        float n0x = c0, n0z = s0, n1x = c1, n1z = s1;
        // lado: (b0, b1, t1) e (b0, t1, t0), vistos de fora em sentido anti-horário
        emit(out, m, x0, yb, z0, n0x, 0, n0z, col);
        emit(out, m, x0, yt, z0, n0x, 0, n0z, col);
        emit(out, m, x1, yt, z1, n1x, 0, n1z, col);
        emit(out, m, x0, yb, z0, n0x, 0, n0z, col);
        emit(out, m, x1, yt, z1, n1x, 0, n1z, col);
        emit(out, m, x1, yb, z1, n1x, 0, n1z, col);
        // tampa de cima e de baixo
        emit(out, m, cx, yt, cz, 0, 1, 0, col); emit(out, m, x1, yt, z1, 0, 1, 0, col); emit(out, m, x0, yt, z0, 0, 1, 0, col);
        emit(out, m, cx, yb, cz, 0, -1, 0, col); emit(out, m, x0, yb, z0, 0, -1, 0, col); emit(out, m, x1, yb, z1, 0, -1, 0, col);
    }
}


}  // namespace Shapes
