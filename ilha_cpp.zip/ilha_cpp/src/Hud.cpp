#include "Hud.h"
#include <cmath>
#include <cstdio>
#include "HudFont.h"

namespace Hud {
namespace {

constexpr float TP = 6.2831855f;

uint32_t pack(float r, float g, float b, float a) {   // Color.toIntBits: (int)(255*x), sem arredondar
    return static_cast<uint32_t>(static_cast<int>(255.0f * r)) |
           static_cast<uint32_t>(static_cast<int>(255.0f * g)) << 8 |
           static_cast<uint32_t>(static_cast<int>(255.0f * b)) << 16 |
           static_cast<uint32_t>(static_cast<int>(255.0f * a)) << 24;
}

// forma sólida: todos os vértices apontam para o bloco branco do atlas
void solid(std::vector<HudVertex>& out, float x, float y, uint32_t c) {
    out.push_back({x, y, (HudFont::WHITE_X + 2) / static_cast<float>(HudFont::W), (HudFont::WHITE_Y + 2) / static_cast<float>(HudFont::H), c});
}

void triangle(std::vector<HudVertex>& out, float x1, float y1, float x2, float y2, float x3, float y3, uint32_t c) {
    solid(out, x1, y1, c); solid(out, x2, y2, c); solid(out, x3, y3, c);
}

// ShapeRenderer.circle: segmentos = max(1, 6 * cbrt(raio))
void circle(std::vector<HudVertex>& out, float cx, float cy, float r, uint32_t c) {
    const int segs = std::max(1, static_cast<int>(6.0f * std::cbrt(r)));
    for (int i = 0; i < segs; i++) {
        const float a0 = TP * i / segs, a1 = TP * (i + 1) / segs;
        triangle(out, cx, cy, cx + std::cos(a0) * r, cy + std::sin(a0) * r, cx + std::cos(a1) * r, cy + std::sin(a1) * r, c);
    }
}

const HudFont::Glyph* glyphOf(char ch) {
    int code = static_cast<unsigned char>(ch);
    if (code < 32 || code > 126) code = '?';
    return &HudFont::GLYPHS[code - 32];
}

// capTopY = y do TOPO das letras maiúsculas (é o "y" do BitmapFont.draw do libGDX)
void text(std::vector<HudVertex>& out, const char* s, float x, float capTopY, float scale, uint32_t c) {
    const float base = capTopY + HudFont::CAP * scale;
    float pen = x;
    for (; *s; s++) {
        const HudFont::Glyph* g = glyphOf(*s);
        if (g->w > 0) {
            const float x0 = pen + g->xoff * scale, y0 = base + g->yoff * scale;
            const float x1 = x0 + g->w * scale, y1 = y0 + g->h * scale;
            const float u0 = g->x / static_cast<float>(HudFont::W), v0 = g->y / static_cast<float>(HudFont::H);
            const float u1 = (g->x + g->w) / static_cast<float>(HudFont::W), v1 = (g->y + g->h) / static_cast<float>(HudFont::H);
            out.push_back({x0, y0, u0, v0, c}); out.push_back({x1, y0, u1, v0, c}); out.push_back({x1, y1, u1, v1, c});
            out.push_back({x0, y0, u0, v0, c}); out.push_back({x1, y1, u1, v1, c}); out.push_back({x0, y1, u0, v1, c});
        }
        pen += g->adv * scale;
    }
}

// texto centrado em (cx, cy): como o `label` do original (centraliza pela altura das maiúsculas)
void label(std::vector<HudVertex>& out, const char* s, float cx, float cy, float scale, uint32_t c) {
    text(out, s, cx - textWidth(s, scale) / 2.0f, cy - HudFont::CAP * scale / 2.0f, scale, c);
}

}  // namespace

float textScale(int screenH) { return std::max(1.0f, screenH / 540.0f); }

float textWidth(const char* s, float scale) {
    float w = 0.0f;
    for (; *s; s++) w += glyphOf(*s)->adv * scale;
    return w;
}

void build(const Controls& c, const Info& info, std::vector<HudVertex>& out) {
    out.clear();
    const float h = c.height();
    const float s = textScale(static_cast<int>(h));
    const uint32_t white = pack(1, 1, 1, 1);

    // ---- formas ----
    if (c.joyActive() && !c.inBoat) {
        circle(out, c.joyOX, c.joyOY, c.radius, pack(1, 1, 1, 0.18f));
        const float dx = std::min(std::max(c.joyCX - c.joyOX, -c.radius), c.radius);
        const float dy = std::min(std::max(c.joyCY - c.joyOY, -c.radius), c.radius);
        circle(out, c.joyOX + dx, c.joyOY + dy, c.radius * 0.4f, pack(1, 1, 1, 0.45f));
    }
    if (!c.inBoat)   // botão PULAR (some dentro do barco)
        circle(out, c.jumpX(), c.jumpY(), c.jumpR(), pack(1, 0.85f, 0.1f, c.jumpHeld() ? 0.75f : 0.42f));
    if (c.showRow) {   // REMAR, ESQ, DIR
        circle(out, c.goX(), c.goY(), c.goR(), pack(0.25f, 0.6f, 1, c.rowGoHeld() ? 0.8f : 0.45f));
        circle(out, c.leftX(), c.leftY(), c.sideR(), pack(1, 1, 1, c.rowLHeld() ? 0.7f : 0.35f));
        circle(out, c.rightX(), c.leftY(), c.sideR(), pack(1, 1, 1, c.rowRHeld() ? 0.7f : 0.35f));
        const uint32_t dark = pack(0.1f, 0.1f, 0.1f, 0.8f);
        const float ar = c.sideR() * 0.42f;
        const float ly = c.leftY() - c.sideR() * 0.12f;
        triangle(out, c.leftX() - ar, ly, c.leftX() + ar * 0.7f, ly - ar, c.leftX() + ar * 0.7f, ly + ar, dark);
        triangle(out, c.rightX() + ar, ly, c.rightX() - ar * 0.7f, ly - ar, c.rightX() - ar * 0.7f, ly + ar, dark);
    }
    if (c.act1Text) circle(out, c.act1X(), c.act1Y(), c.act1R(), pack(0.2f, 0.85f, 0.35f, c.act1Held() ? 0.85f : 0.55f));
    if (c.act2Text) circle(out, c.act2X(), c.act2Y(), c.act2R(), pack(1, 0.55f, 0.15f, c.act2Held() ? 0.85f : 0.55f));

    // ---- textos ----
    char buf[160];
    const float lh = HudFont::LINE * s;
    std::snprintf(buf, sizeof buf, "Altitude: %d m   |   Boneco: 1.75 m   |   FPS: %d", info.altitude, info.fps);
    text(out, buf, 12.0f, 12.0f, s, white);
    if (!c.inBoat) label(out, "PULAR", c.jumpX(), c.jumpY(), s, white);
    if (c.showRow) {
        label(out, "REMAR", c.goX(), c.goY(), s, white);
        label(out, "ESQ", c.leftX(), c.leftY() + c.sideR() * 0.62f, s, white);   // o label do original já recebe y de toque (para baixo)
        label(out, "DIR", c.rightX(), c.leftY() + c.sideR() * 0.62f, s, white);
    }
    if (c.act1Text) label(out, c.act1Text, c.act1X(), c.act1Y(), s, white);
    if (c.act2Text) label(out, c.act2Text, c.act2X(), c.act2Y(), s, white);
    std::snprintf(buf, sizeof buf, "Chunks: terreno %d / vegetacao %d", info.terrainChunks, info.decoChunks);
    text(out, buf, 12.0f, 12.0f + lh * 1.3f, s, white);
    const int hh = static_cast<int>(info.tod);
    const int mm = static_cast<int>((info.tod - hh) * 60.0f);
    std::snprintf(buf, sizeof buf, "Hora: %02d:%02d   Dia: %d", hh, mm, info.day);
    text(out, buf, 12.0f, 12.0f + lh * 2.6f, s, white);
    // (só no port) o que a qualidade automática por FPS decidiu
    if (info.quality) {
        std::snprintf(buf, sizeof buf, "Qualidade: %s%s   |   terreno %.0f m   |   vegetacao %.0f m", info.quality, info.autoQuality ? " (auto)" : "", info.terrainR, info.decoR);
        text(out, buf, 12.0f, 12.0f + lh * 3.9f, s, white);
    }
}

}  // namespace Hud
