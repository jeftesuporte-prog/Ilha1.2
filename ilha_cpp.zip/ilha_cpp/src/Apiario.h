#pragma once
// Port 1:1 de Apiario.kt: ONDE FICAM AS COLMEIAS e os 3 prados de flores de cada uma. Calculado uma vez (semente fixa).
#include <cstdint>
#include <functional>
#include <vector>

namespace Apiario {

struct Hive {
    float x, z, y, yaw;
    int pal;
    float honey = 0.05f;          // 0..1: quanto mel tem na colmeia (as abelhas enchem)
    std::vector<int> meadows;     // indices em meadows()
    // mundo (x,z) de um ponto da colmeia, em coordenadas dela (lx = para o lado, lz = para a frente/entrada)
    float wx(float lx, float lz) const;
    float wz(float lx, float lz) const;
};

struct Meadow {
    int hive;
    float cx, cz, r;
    std::vector<float> fx, fy, fz;
    std::vector<int> ft;          // 0 margarida, 1 papoula, 2 tulipa, 3 lavanda, 4 girassol
    std::vector<int64_t> fs;      // semente de cada flor (o ChunkBuilder usa a mesma)
    int count = 0;
};

// ninho pendurado no galho (coordenadas locais da colmeia: origem = pe do tronco, +Z = lado do galho/entrada)
constexpr float NEST_Z = 1.5f;
constexpr float ENT_LZ = 1.75f;
constexpr float LAND_LZ = 1.84f;
constexpr float LAND_Y = 1.70f;
constexpr float ORIENT_LZ = 2.7f;
constexpr float APP_LZ = 2.8f;
extern const float HEAD[5];

// Lazy e thread-safe (C++11 magic static): pode ser chamado das threads de carregamento.
const std::vector<Hive>& hives();
const std::vector<Meadow>& meadows();

// area onde arvore/pedra nao nasce: em cima da colmeia e dos prados
bool reserved(float x, float z);
// o ChunkBuilder chama isto para plantar as flores dos prados que caem dentro do chunk
void forEachFlower(float x0, float z0, float x1, float z1,
                   const std::function<void(int, float, float, float, int64_t)>& f);
// colmeia solida: empurra (out[0], out[1]) para fora
void pushOut(float out[2], float pr);
int nearest(float x, float z);
}  // namespace Apiario
