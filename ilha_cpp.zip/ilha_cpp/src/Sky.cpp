#include "Sky.h"
#include <cmath>
#include "Cfg.h"
#include "SkyTables.h"

using km::max; using km::min; using km::coerceIn;

namespace {
inline float lerp(float a, float b, float t) { return a + (b - a) * t; }
inline void setC(Color& c, float r, float g, float b, float a) { c.r = r; c.g = g; c.b = b; c.a = a; }
}

float Sky::Cfg_START_HOUR() { return Cfg::START_HOUR; }

Sky::Sky() {
    // nuvens (mesma ordem de sorteios do Kotlin; os argumentos de Puff/Cloud são avaliados da esquerda para a direita)
    for (int ci = 0; ci < 14; ci++) {
        std::vector<Puff> puffs;
        float base = 45.0f + rnd.nextFloat() * 50.0f;
        int np = 4 + rnd.nextInt(3);
        for (int k = 0; k < np; k++) {
            float ox = static_cast<float>(k - 2) * base * 0.55f + rnd.nextFloat() * 20.0f;
            float oy = rnd.nextFloat() * 18.0f;
            float oz = rnd.nextFloat() * 40.0f - 20.0f;
            float s = base * (0.6f + rnd.nextFloat() * 0.5f);
            puffs.push_back({ox, oy, oz, s});
        }
        Cloud c;
        c.x = rnd.nextFloat() * 1800.0f - 900.0f;
        c.y = 260.0f + rnd.nextFloat() * 160.0f;
        c.z = rnd.nextFloat() * 1800.0f - 900.0f;
        c.speed = 4.0f + rnd.nextFloat() * 4.0f;
        c.puffs = std::move(puffs);
        clouds.push_back(std::move(c));
    }

    // estrelas: céu todo + faixa densa e fraca = via láctea
    V3 band = V3(0.30f, 0.62f, -0.72f).nor();
    for (int i = 0; i < NSTARS; i++) {
        float x = 0, y = 0, z = 0;
        bool milky = i >= 480;
        for (;;) {
            float yy = rnd.nextFloat() * 1.04f - 0.04f;
            float ph = rnd.nextFloat() * 6.2831855f;
            float rr = km::sqrt(max(0.0f, 1.0f - yy * yy));
            x = rr * km::cos(ph); y = yy; z = rr * km::sin(ph);
            if (!milky) break;
            if (km::abs(x * band.x + y * band.y + z * band.z) < 0.07f) break;   // só perto do plano da via láctea
        }
        sdx[i] = x; sdy[i] = y; sdz[i] = z;
        float r = rnd.nextFloat();
        if (milky) {
            ssz[i] = 1.0f; sbr[i] = 0.25f + rnd.nextFloat() * 0.3f; sty[i] = 1;
        } else if (r < 0.80f) {
            ssz[i] = 1.2f + rnd.nextFloat() * 0.8f; sbr[i] = 0.45f + rnd.nextFloat() * 0.4f; sty[i] = rnd.nextInt(3);
        } else if (r < 0.96f) {
            ssz[i] = 2.2f + rnd.nextFloat() * 0.8f; sbr[i] = 0.75f + rnd.nextFloat() * 0.25f; sty[i] = rnd.nextInt(3);
        } else {
            ssz[i] = 3.4f + rnd.nextFloat() * 1.4f; sbr[i] = 1.0f; sty[i] = rnd.nextInt(3);
        }
        sph[i] = rnd.nextFloat() * 6.2831855f;
        ssp[i] = 0.8f + rnd.nextFloat() * 2.6f;
    }

    // O original ainda sorteia a textura antiga do reflexo (128 + 128 + 64*256 sorteios) com o mesmo gerador.
    // Não desenhamos essa textura, mas gastamos os sorteios para que as estrelas cadentes saiam iguais.
    for (int i = 0; i < 128 + 128 + 64 * 256; i++) rnd.nextFloat();

    recompute();
}

void Sky::stopColor(const float arr[5][3], float e, Color& out) {
    using namespace SkyTables;
    if (e >= STOP_E[0]) { setC(out, arr[0][0], arr[0][1], arr[0][2], 1.0f); return; }
    for (int i = 0; i < 4; i++) {
        if (e >= STOP_E[i + 1]) {
            float f = (e - STOP_E[i]) / (STOP_E[i + 1] - STOP_E[i]);
            setC(out, lerp(arr[i][0], arr[i + 1][0], f), lerp(arr[i][1], arr[i + 1][1], f), lerp(arr[i][2], arr[i + 1][2], f), 1.0f);
            return;
        }
    }
    setC(out, arr[4][0], arr[4][1], arr[4][2], 1.0f);
}

void Sky::recompute() {
    using namespace SkyTables;
    float a = (tod - 6.0f) * 3.1415927f / 12.0f;       // 6h nasce no leste, 12h a pino, 18h se põe no oeste (no mar)
    toSun.set(km::cos(a), km::sin(a), -0.28f).nor();
    // a lua NÃO se põe: fica sempre lá em cima (~55-70 graus), só deriva devagar de leste a oeste
    toMoon.set(-km::cos(a) * 0.55f, 0.80f, 0.30f).nor();
    sunE = toSun.y;
    float k = smooth(0.10f, -0.10f, sunE);              // 0 = luz do sol, 1 = luz da lua
    toLight.set(toSun).scl(1.0f - k).mulAdd(toMoon, k).nor();

    int i = 0;
    while (i < 13 - 2 && tod >= KEY[i + 1][0]) i++;
    const float* p = KEY[i];
    const float* q = KEY[i + 1];
    float f = coerceIn((tod - p[0]) / (q[0] - p[0]), 0.0f, 1.0f);
    float s = f * f * (3.0f - 2.0f * f);
    setC(topC, lerp(p[1], q[1], s), lerp(p[2], q[2], s), lerp(p[3], q[3], s), 1.0f);
    setC(horC, lerp(p[4], q[4], s), lerp(p[5], q[5], s), lerp(p[6], q[6], s), 1.0f);
    setC(ambient, lerp(p[7], q[7], s), lerp(p[8], q[8], s), lerp(p[9], q[9], s), 1.0f);
    setC(lightC, lerp(p[10], q[10], s), lerp(p[11], q[11], s), lerp(p[12], q[12], s), 1.0f);
    fog = horC;

    // ----- camadas de cor do pôr do sol / amanhecer -----
    tw = 1.0f - smooth(0.0f, 0.38f, km::abs(sunE + 0.04f));
    stopColor(HOT, sunE, warm1);
    stopColor(MID, sunE, warm2);
    stopColor(HIGH, sunE, warm3);
    warmK = 1.0f - smooth(0.0f, 0.4f, sunE);
    float deep = smooth(0.12f, -0.02f, sunE);
    float sdh = max(km::sqrt(toSun.x * toSun.x + toSun.z * toSun.z), 1e-4f);
    sunHx = toSun.x / sdh;
    sunHz = toSun.z / sdh;
    sunEv.set(toSun.z / sdh, 0.0f, -toSun.x / sdh);
    sunNv.set(-toSun.x * toSun.y / sdh, sdh, -toSun.z * toSun.y / sdh);
    float hv = smooth(-0.25f, 0.0f, sunE);
    setC(haloCol, hv, lerp(0.93f, 0.50f, warmK) * hv, lerp(0.70f, 0.22f, warmK) * hv, 1.0f);
    setC(sunCol, 1.0f, lerp(0.95f, 0.80f, warmK) * (1.0f - 0.12f * deep), lerp(0.70f, 0.46f, warmK) * (1.0f - 0.18f * deep), 1.0f);
    sunR = 0.048f * (1.0f + 0.25f * warmK);
    sunSquash = 1.0f + 0.20f * warmK;
}

void Sky::horizonAt(float dx, float dz, Color& out) const {
    float l = km::sqrt(dx * dx + dz * dz);
    float a = 0.5f;
    if (l > 1e-3f) a = 0.5f + 0.5f * ((dx / l) * sunHx + (dz / l) * sunHz);
    float wa = static_cast<float>(std::pow(static_cast<double>(a), 2.2));
    float w1 = coerceIn(tw * wa * 0.9f, 0.0f, 1.0f);
    float r = lerp(horC.r, warm1.r, w1);
    float g = lerp(horC.g, warm1.g, w1);
    float b = lerp(horC.b, warm1.b, w1);
    float wb = tw * (1.0f - a) * 0.5f;
    r = lerp(r, lerp(warm2.r, horC.r, 0.5f), wb);
    g = lerp(g, lerp(warm2.g, horC.g, 0.5f), wb);
    b = lerp(b, lerp(warm2.b, horC.b, 0.5f), wb);
    setC(out, r, g, b, 1.0f);
}

float Sky::nightK() const { return 1.0f - smooth(-0.22f, 0.0f, sunE); }

void Sky::update(float dt, float camX, float camZ, float dirX, float dirZ) {
    (void)camX; (void)camZ;                            // as nuvens agora seguem a câmera só no desenho
    tod = std::fmod(tod + dt * 24.0f / Cfg::DAY_SECONDS, 24.0f);
    recompute();
    // a névoa tem a cor do horizonte PARA ONDE A CÂMERA OLHA: o mar some no céu sem emenda
    horizonAt(dirX, dirZ, fog);

    for (Cloud& c : clouds) {
        c.x += c.speed * dt;
        if (c.x > 900.0f) c.x = -900.0f;
        // nuvem do lado do sol pega o laranja/rosa do pôr do sol por baixo
        float cl = max(km::sqrt(c.x * c.x + c.z * c.z), 1.0f);
        float ca = 0.5f + 0.5f * (c.x / cl * sunHx + c.z / cl * sunHz);
        float ck = coerceIn(tw * ca * ca, 0.0f, 1.0f);
        c.er = lerp(horC.r * 0.55f, warm1.r * 0.85f, ck);
        c.eg = lerp(horC.g * 0.55f, warm1.g * 0.85f, ck);
        c.eb = lerp(horC.b * 0.55f, warm1.b * 0.85f, ck);
    }

    // brilho do sol/lua na água
    float sunG = smooth(-0.02f, 0.05f, sunE) * (0.9f + 0.5f * warmK);
    setC(sunGlitCol, sunCol.r * sunG, sunCol.g * sunG, sunCol.b * sunG, 1.0f);
    float moonG = 0.55f * smooth(0.02f, 0.25f, toMoon.y) * nightK();
    setC(moonGlitCol, 0.60f * moonG, 0.72f * moonG, 1.0f * moonG, 1.0f);

    // estrelas cadentes: poucas, só de noite fechada
    if (nightK() > 0.7f) {
        meteorTimer -= dt;
        if (meteorTimer <= 0.0f) {
            meteorTimer = 25.0f + rnd.nextFloat() * 45.0f;
            spawnMeteor();
        }
    }
    for (size_t i = 0; i < meteors.size();) {
        meteors[i].age += dt;
        if (meteors[i].age > meteors[i].life) meteors.erase(meteors.begin() + static_cast<long>(i));
        else i++;
    }
}

void Sky::spawnMeteor() {
    float az = camAz + (rnd.nextFloat() - 0.5f) * 1.6f;          // na frente de quem está olhando
    float y = 0.35f + rnd.nextFloat() * 0.5f;
    float rr = km::sqrt(1.0f - y * y);
    V3 d0(rr * km::cos(az), y, rr * km::sin(az));
    float rx = rnd.nextFloat() - 0.5f;
    float ry = rnd.nextFloat() - 0.7f;
    float rz = rnd.nextFloat() - 0.5f;
    V3 r(rx, ry, rz);
    V3 tv(r);
    tv.mulAdd(d0, -r.dot(d0)).nor();
    if (tv.y > 0.0f) tv.scl(-1.0f);                               // cai
    float speed = 0.9f + rnd.nextFloat() * 0.6f;
    float life = 0.8f + rnd.nextFloat() * 0.5f;
    Meteor m;
    m.d0 = d0; m.tv = tv; m.speed = speed; m.life = life;
    meteors.push_back(m);
}

void Sky::fillFrame(SkyFrame& f) const {
    auto c3 = [](float* o, const Color& c) { o[0] = c.r; o[1] = c.g; o[2] = c.b; };
    c3(f.top, topC); c3(f.hor, horC);
    f.sun[0] = toSun.x; f.sun[1] = toSun.y; f.sun[2] = toSun.z;
    f.moon[0] = toMoon.x; f.moon[1] = toMoon.y; f.moon[2] = toMoon.z;
    f.sunH[0] = sunHx; f.sunH[1] = sunHz;
    c3(f.warm1, warm1); c3(f.warm2, warm2); c3(f.warm3, warm3); c3(f.halo, haloCol);
    f.tw = tw;
    f.sunE[0] = sunEv.x; f.sunE[1] = sunEv.y; f.sunE[2] = sunEv.z;
    f.sunN[0] = sunNv.x; f.sunN[1] = sunNv.y; f.sunN[2] = sunNv.z;
    f.sunR = sunR; f.squash = sunSquash;
    c3(f.sunCol, sunCol); c3(f.sunGlit, sunGlitCol); c3(f.moonGlit, moonGlitCol);
    f.refl = 0.85f;
}
