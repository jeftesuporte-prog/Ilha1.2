#pragma once
// HUD (IlhaGame.drawHud): analógico, botão PULAR, botões do barco e os textos (altitude, FPS, chunks, hora, qualidade).
// Gera só a GEOMETRIA 2D (triângulos coloridos + quadrados de letras do atlas); quem desenha é o VkEngine, em 1 chamada.
// Coordenadas em pixels, y para baixo (as mesmas dos toques do Android).
#include <vector>
#include "Controls.h"
#include "HudVertex.h"

namespace Hud {

struct Info {
    int altitude = 0;          // metros (player.pos.y.toInt())
    int fps = 0;
    int terrainChunks = 0, decoChunks = 0;
    float tod = 6.2f;          // hora do dia (0..24)
    int day = 1;               // dia do jogo (1, 2, 3...)
    // qualidade automática por FPS (a etapa 4 já tem; aqui só se mostra)
    const char* quality = nullptr;
    float terrainR = 0, decoR = 0;
    bool autoQuality = true;
};

// Escala do texto: max(1, altura/540), como o original.
float textScale(int screenH);
// Largura em pixels de um texto na escala dada.
float textWidth(const char* s, float scale);
// Monta o HUD inteiro (formas e depois textos) em `out` (limpa antes).
void build(const Controls& c, const Info& info, std::vector<HudVertex>& out);

}  // namespace Hud
