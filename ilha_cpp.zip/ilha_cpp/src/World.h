#pragma once
// Port 1:1 de World.kt (Pal, Base, RoadNet, River, Bridge, Pier, World).
// Tudo é função pura sobre dados criados uma vez (lazy, thread-safe) => pode ser chamado de qualquer thread.
#include <vector>
#include "Cfg.h"
#include "Color.h"

namespace Pal {
constexpr Color GRASS      = Color::hex(0x5DBB35);
constexpr Color SAND       = Color::hex(0xF5DEB3);
constexpr Color WET        = Color::hex(0xD8BE8A);
constexpr Color SEABED     = Color::hex(0xE3CF9E);
constexpr Color ROCK       = Color::hex(0x5A5A5A);
constexpr Color MOSS       = Color::hex(0x4A7C2E);
constexpr Color DIRT       = Color::hex(0x8B5A2B);
constexpr Color TRUNK      = Color::hex(0x8B4513);
constexpr Color CROWN      = Color::hex(0x2E8B57);
constexpr Color PALM_TRUNK = Color::hex(0xA0703C);
constexpr Color PALM_LEAF  = Color::hex(0x2FB84A);
constexpr Color BUSH       = Color::hex(0x3FA34D);
constexpr Color PINK       = Color::hex(0xFF69B4);
constexpr Color YELLOW     = Color::hex(0xFFE135);
constexpr Color BLUE       = Color::hex(0x4D9BFF);

// Pal.bits(c, k): cor multiplicada por k (limitada a 1), empacotada como float de vértice
inline float bits(const Color& c, float k = 1.0f) {
    auto mn = [](float a, float b) { return a <= b ? a : b; };
    return toFloatBits(mn(1.0f, c.r * k), mn(1.0f, c.g * k), mn(1.0f, c.b * k), 1.0f);
}
}  // namespace Pal

struct Peak { float x, z, h, r; };

namespace Base {
const std::vector<Peak>& peaks();
float n(float x, float z);
float shape(float x, float z);
float depth(float x, float z);       // metros até a linha d'água: >0 terra, <0 mar
float forestW(float x, float z, float d, float h);
float orchard(float x, float z);
float grove(float x, float z);
float baseHeight(float x, float z);
}

namespace RoadNet {
constexpr float dirX = -0.8f;
constexpr float dirZ = 0.6f;
float shoreX(); float shoreZ();
float startX(); float startZ();
float bridgeX(); float bridgeZ();
float bridgeTX(); float bridgeTZ();
// out[0] = distância até o eixo da estrada (1e9 se longe), out[1] = altura da estrada ali.
void query(float x, float z, float out[2]);
bool nearPier(float x, float z);
}

namespace River {
float dist(float x, float z);
float w2d(float x, float z);         // 1 dentro do leito, 0 fora do barranco
}

namespace Bridge {
float x(); float z(); float dx(); float dz();
float deckY(); float pitchDeg();
float deckAt(float px, float pz);
float along(float px, float pz);
float across(float px, float pz);
bool onDeck(float px, float pz);
}

namespace Pier {
constexpr float TOP = 0.28f;
constexpr float HALF_W = 1.6f;
float along(float x, float z);
float across(float x, float z);
bool onDeck(float x, float z);
}

namespace World {
float heightAt(float x, float z);
float groundAt(float x, float z);
bool onDeck(float x, float z);
bool inRiver(float x, float z);
bool reserved(float x, float z);
constexpr int SN = 10;               // floats por amostra
// o[k..k+2]=tom, o[k+3]=pedra, o[k+4]=musgo, o[k+5]=areia, o[k+6]=floresta, o[k+7]=estrada, o[k+8]=rio, o[k+9]=dist. água
void sample(float x, float z, float h, float ny, float* o, int k);
}
