#pragma once
// Port 1:1 de Player.kt: boneco de 1,75 m (a régua de todo o mapa). Andar com colisão, pular, gravidade, nadar, e o modelo (7 caixas).
#include <vector>
#include "ChunkManager.h"   // Colliders
#include "KMath.h"

class Player {
public:
    Vec3 pos{0, 0, 0};
    bool grounded = true;
    float heading = 0.0f;   // graus (rotação em Y do modelo)

    // Rumo em graus de uma direção (dx,dz): MathUtils.atan2(dx, dz) * radiansToDegrees do libGDX (aproximado, como no original).
    static float headingFromDir(float dx, float dz);
    void place(float x, float z, float headingDegrees);

    // (dx,dz) = direção unitária no mundo. Colisões: grade da ponte, troncos/pedras/colmeias (pedras: sobe nelas), água = nada.
    // Se a direção está bloqueada, tenta deslizar só em X ou só em Z.
    void move(float dx, float dz, float dt, float speed, const Colliders& c);
    void jump();
    // Chame todo quadro: cola no chão ao andar em rampa, cai de píer/ponte e faz o arco do pulo.
    void physics(float dt, const Colliders& c);

    // O que IlhaGame.update faz com os controles: andar na direção da câmera (yaw), correr, nadar mais devagar, pular, física.
    // moveX = direita(+), moveY = frente(+), ambos -1..1. `jumpPressed` é consumido (vira false).
    void drive(float yaw, float moveX, float moveY, bool run, bool& jumpPressed, float dt, const Colliders& c);

    // Chão onde o boneco fica: terreno + topo das pedras, ou a superfície da água (nada) quando o fundo é fundo demais.
    float floorAt(float x, float z, const Colliders& c) const;

    // Modelo (legs, torso, arms, head, eyes) já no mundo, 7 floats por vértice. Só se a cabeça está fora d'água.
    void buildModel(std::vector<float>& out) const;
    float vy() const { return vy_; }   // velocidade vertical (m/s): só para testes
    bool visible() const { return pos.y + 1.75f > 0.0f; }   // cabeça abaixo da água = boneco some

private:
    bool attempt(float tx0, float tz0, const Colliders& c);
    void setHeading(float deg) { heading = deg; }
    float vy_ = 0.0f;
};
