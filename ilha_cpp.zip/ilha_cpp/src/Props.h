#pragma once
// Port de Props.kt (píer e ponte) e da parte VISUAL do Barco.kt (casco + remos amarrados no píer).
// Tudo sai em coordenadas do MUNDO, no formato de vértice "7 floats" (x y z | nx ny nz | cor empacotada),
// o mesmo da vegetação: desenha com o pipeline "deco". (Remar, amarrar e as cordas entram na etapa do boneco.)
#include <vector>

namespace Props {
// Píer de madeira (+Z do modelo = rumo ao mar), já colocado na costa (Props.placePier).
std::vector<float> pier();
// Ponte de madeira sobre o rio, já colocada no cruzamento estrada x rio, inclinada junto com a estrada (Props.placeBridge).
std::vector<float> bridge();
}

namespace BoatModel {
// lugar do barco e dos cunhos, em coordenadas do PIER (lx = para o lado, lz = para o mar)
constexpr float SLOT_LX = 3.1f;
constexpr float SLOT_LZ = 21.0f;
constexpr float BOLL_LX = 1.42f;
constexpr float BOLL_BOW_LZ = 22.8f;
constexpr float BOLL_STERN_LZ = 19.4f;
float worldX(float lx, float lz);
float worldZ(float lx, float lz);

// Estado necessário para posicionar o barco (Barco.kt: x, z, yaw, moored, v, w, phase, efNeg, efPos).
struct Pose {
    float x, z, yaw;
    bool moored = true;
    float v = 0.0f, w = 0.0f;       // velocidade para a frente (m/s) e giro (rad/s)
    float phase = 0.0f;             // 0..1 da remada
    float efNeg = 0.0f, efPos = 0.0f;   // esforço de cada remo
};
Pose mooredPose();                  // barco parado no píer
// Casco + 2 remos em coordenadas do mundo, balançando nas ondas no instante t (segundos).
void build(const Pose& p, float t, std::vector<float>& out);
}
