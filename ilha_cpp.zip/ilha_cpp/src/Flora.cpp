#include "Flora.h"
#include "Color.h"
#include "KMath.h"
#include "World.h"   // Pal::bits


namespace {
constexpr float TP = 6.2831855f;

float cb(uint32_t hex, float k = 1.0f) { return Pal::bits(Color::hex(hex), k); }

// Tubo (tronco/caule) com `sides` lados; normais para fora do eixo.
void tube(MeshAccum& acc, float x0, float y0, float z0, float r0, float x1, float y1, float z1, float r1, int sides, float col) {
    float da = TP / sides;
    float mx = (x0 + x1) * 0.5f, my = (y0 + y1) * 0.5f, mz = (z0 + z1) * 0.5f;
    for (int k = 0; k < sides; k++) {
        float a0 = k * da;
        float a1 = a0 + da;
        float c0 = km::cos(a0), s0 = km::sin(a0), c1 = km::cos(a1), s1 = km::sin(a1);
        acc.triOut(x0 + c0 * r0, y0, z0 + s0 * r0, x0 + c1 * r0, y0, z0 + s1 * r0, x1 + c0 * r1, y1, z1 + s0 * r1, mx, my, mz, col);
        acc.triOut(x0 + c1 * r0, y0, z0 + s1 * r0, x1 + c1 * r1, y1, z1 + s1 * r1, x1 + c0 * r1, y1, z1 + s0 * r1, mx, my, mz, col);
    }
}

// Cúpula pequena (miolo de flor, botão).
void dome(MeshAccum& acc, float cx, float cy, float cz, float r, float h, int sides, float col) {
    float da = TP / sides;
    for (int k = 0; k < sides; k++) {
        float a0 = k * da;
        float a1 = a0 + da;
        acc.triOut(cx + km::cos(a0) * r, cy, cz + km::sin(a0) * r, cx + km::cos(a1) * r, cy, cz + km::sin(a1) * r, cx, cy + h, cz,
                   cx, cy - r * 0.5f, cz, col);
    }
}

// Folha comprida que sai do pé da planta e se curva para baixo na ponta.
void leaf(MeshAccum& acc, float x, float y, float z, float ang, float len, float wid, float col) {
    float dx = km::cos(ang), dz = km::sin(ang);
    float px = -dz, pz = dx;
    float by = y + 0.03f;
    float mx = x + dx * len * 0.5f, my = by + len * 0.32f, mz = z + dz * len * 0.5f;
    float tx = x + dx * len, ty = by + len * 0.22f, tz = z + dz * len;
    acc.triOut(x, by, z, mx + px * wid, my, mz + pz * wid, mx - px * wid, my, mz - pz * wid, x, by - 0.3f, z, col);
    acc.triOut(mx + px * wid, my, mz + pz * wid, tx, ty, tz, mx - px * wid, my, mz - pz * wid, x, by - 0.3f, z, col);
}

// Pétala em losango, saindo do centro da flor em `ang`, subindo `rise` até a ponta.
void petal(MeshAccum& acc, float hx, float hy, float hz, float ang, float r0, float r1, float wid, float rise,
           float colBase, float colTip) {
    float dx = km::cos(ang), dz = km::sin(ang);
    float px = -dz, pz = dx;
    float rm = r0 + (r1 - r0) * 0.45f;
    float ly = hy + rise * 0.55f;
    acc.triOut(hx + dx * r0, hy, hz + dz * r0,
               hx + dx * rm + px * wid, ly, hz + dz * rm + pz * wid,
               hx + dx * rm - px * wid, ly, hz + dz * rm - pz * wid,
               hx, hy - 0.15f, hz, colBase);
    acc.triOut(hx + dx * rm + px * wid, ly, hz + dz * rm + pz * wid,
               hx + dx * r1, hy + rise, hz + dz * r1,
               hx + dx * rm - px * wid, ly, hz + dz * rm - pz * wid,
               hx, hy - 0.15f, hz, colTip);
}

// Botãozinho em losango (flor da lavanda).
void bud(MeshAccum& acc, float cx, float cy, float cz, float r, float col) {
    for (int k = 0; k < 3; k++) {
        float a0 = k * TP / 3.0f;
        float a1 = (k + 1) * TP / 3.0f;
        float x0 = cx + km::cos(a0) * r, z0 = cz + km::sin(a0) * r;
        float x1 = cx + km::cos(a1) * r, z1 = cz + km::sin(a1) * r;
        acc.triOut(x0, cy, z0, x1, cy, z1, cx, cy + r * 1.5f, cz, cx, cy, cz, col);
        acc.triOut(x0, cy, z0, x1, cy, z1, cx, cy - r * 1.0f, cz, cx, cy, cz, col);
    }
}

// Margarida: 9 pétalas brancas e miolo amarelo.
void daisy(MeshAccum& acc, float x, float y, float z, JavaRandom& rng) {
    const float STEM = cb(0x4E9A3A), LEAF_A = cb(0x3F8F35), LEAF_B = cb(0x5BAA42);
    float s = 0.9f + rng.nextFloat() * 0.4f;
    float hx = x + (rng.nextFloat() - 0.5f) * 0.1f;
    float hz = z + (rng.nextFloat() - 0.5f) * 0.1f;
    float hy = y + (0.32f + rng.nextFloat() * 0.2f) * s;
    tube(acc, x, y, z, 0.012f, hx, hy, hz, 0.009f, 4, STEM);
    float la = rng.nextFloat() * TP;
    leaf(acc, x, y, z, la, 0.14f * s, 0.028f, LEAF_A);
    leaf(acc, x, y, z, la + 3.1f, 0.12f * s, 0.026f, LEAF_B);
    float white = cb(0xFFFFFF), tip = cb(0xF1F4FF);
    const int n = 9;
    for (int k = 0; k < n; k++) {
        petal(acc, hx, hy, hz, k * TP / n + (rng.nextFloat() - 0.5f) * 0.15f, 0.03f * s, 0.12f * s, 0.022f * s, 0.014f, white, tip);
    }
    dome(acc, hx, hy + 0.003f, hz, 0.036f * s, 0.022f, 6, cb(0xFFC81F));
}

// Papoula: 5 pétalas vermelhas largas, em taça, com miolo escuro.
void poppy(MeshAccum& acc, float x, float y, float z, JavaRandom& rng) {
    const float STEM = cb(0x4E9A3A), LEAF_A = cb(0x3F8F35), LEAF_B = cb(0x5BAA42);
    float s = 0.9f + rng.nextFloat() * 0.4f;
    float hx = x + (rng.nextFloat() - 0.5f) * 0.12f;
    float hz = z + (rng.nextFloat() - 0.5f) * 0.12f;
    float hy = y + (0.36f + rng.nextFloat() * 0.25f) * s;
    tube(acc, x, y, z, 0.011f, hx, hy, hz, 0.008f, 4, STEM);
    float la = rng.nextFloat() * TP;
    leaf(acc, x, y, z, la, 0.15f * s, 0.03f, LEAF_B);
    leaf(acc, x, y, z, la + 2.5f, 0.12f * s, 0.026f, LEAF_A);
    float dark = cb(0xB3131B), light = cb(0xEE2B33);
    float a0 = rng.nextFloat() * TP;
    for (int k = 0; k < 5; k++) {
        petal(acc, hx, hy, hz, a0 + k * TP / 5.0f, 0.012f, 0.095f * s, 0.058f * s, 0.075f * s, dark, light);
    }
    dome(acc, hx, hy + 0.004f, hz, 0.022f * s, 0.022f, 5, cb(0x2B1B33));
}

// Tulipa: botão fechado de 6 pétalas, em rosa, magenta, amarelo ou laranja.
void tulip(MeshAccum& acc, float x, float y, float z, JavaRandom& rng) {
    const float STEM = cb(0x4E9A3A), LEAF_A = cb(0x3F8F35), LEAF_B = cb(0x5BAA42);
    float s = 0.9f + rng.nextFloat() * 0.4f;
    float hx = x + (rng.nextFloat() - 0.5f) * 0.08f;
    float hz = z + (rng.nextFloat() - 0.5f) * 0.08f;
    float hy = y + (0.40f + rng.nextFloat() * 0.2f) * s;
    tube(acc, x, y, z, 0.014f, hx, hy, hz, 0.011f, 4, STEM);
    float la = rng.nextFloat() * TP;
    leaf(acc, x, y, z, la, 0.26f * s, 0.04f, LEAF_A);
    leaf(acc, x, y, z, la + 3.3f, 0.22f * s, 0.036f, LEAF_B);
    uint32_t hex;
    switch (rng.nextInt(4)) { case 0: hex = 0xFF6FA8; break; case 1: hex = 0xD6336C; break; case 2: hex = 0xFFD43B; break; default: hex = 0xFF7A3D; }
    float cLow = cb(hex, 0.82f), cMid = cb(hex, 1.0f), cTip = cb(hex, 1.15f), cAlt = cb(hex, 0.92f);
    float cenY = hy + 0.06f;
    float rot = rng.nextFloat() * TP;
    for (int k = 0; k < 6; k++) {
        float a0 = rot + k * TP / 6.0f;
        float a1 = a0 + TP / 6.0f;
        float b0x = hx + km::cos(a0) * 0.022f, b0z = hz + km::sin(a0) * 0.022f;
        float b1x = hx + km::cos(a1) * 0.022f, b1z = hz + km::sin(a1) * 0.022f;
        float m0x = hx + km::cos(a0) * 0.062f, m0z = hz + km::sin(a0) * 0.062f;
        float m1x = hx + km::cos(a1) * 0.062f, m1z = hz + km::sin(a1) * 0.062f;
        float my = hy + 0.07f;
        float c = (k % 2 == 0) ? cMid : cAlt;
        acc.triOut(b0x, hy, b0z, b1x, hy, b1z, m1x, my, m1z, hx, cenY, hz, cLow);
        acc.triOut(b0x, hy, b0z, m1x, my, m1z, m0x, my, m0z, hx, cenY, hz, c);
        acc.triOut(m0x, my, m0z, m1x, my, m1z, hx, hy + 0.15f * s, hz, hx, cenY, hz, cTip);
    }
}

// Lavanda: haste alta com espiga de botões roxos.
void lavender(MeshAccum& acc, float x, float y, float z, JavaRandom& rng) {
    float s = 0.9f + rng.nextFloat() * 0.4f;
    float hx = x + (rng.nextFloat() - 0.5f) * 0.1f;
    float hz = z + (rng.nextFloat() - 0.5f) * 0.1f;
    float top = y + (0.55f + rng.nextFloat() * 0.25f) * s;
    tube(acc, x, y, z, 0.009f, hx, top, hz, 0.006f, 4, cb(0x5E9A48));
    float la = rng.nextFloat() * TP;
    leaf(acc, x, y, z, la, 0.2f * s, 0.014f, cb(0x6FA85A));
    leaf(acc, x, y, z, la + 2.2f, 0.18f * s, 0.013f, cb(0x5E9A48));
    leaf(acc, x, y, z, la + 4.2f, 0.17f * s, 0.013f, cb(0x6FA85A));
    float c1 = cb(0x8E5BD9), c2 = cb(0xA98BE8), c3 = cb(0x6B3FB5);
    bud(acc, hx, top + 0.005f, hz, 0.016f * s, c2);
    for (int i = 0; i < 6; i++) {
        float yy = top - 0.012f - i * 0.042f * s;
        float r = (0.026f - i * 0.0016f) * s;
        float a = i * 2.4f + rng.nextFloat();
        float off = 0.018f * s;
        bud(acc, hx + km::cos(a) * off, yy, hz + km::sin(a) * off, r, (i % 2 == 0) ? c1 : c3);
        if (i < 4) bud(acc, hx + km::cos(a + 3.14f) * off, yy - 0.02f * s, hz + km::sin(a + 3.14f) * off, r * 0.9f, c2);
    }
}

// Girassol pequeno: miolo marrom grande e duas voltas de pétalas amarelas.
void sunflower(MeshAccum& acc, float x, float y, float z, JavaRandom& rng) {
    const float LEAF_A = cb(0x3F8F35), LEAF_B = cb(0x5BAA42);
    float s = 0.9f + rng.nextFloat() * 0.35f;
    float hx = x + (rng.nextFloat() - 0.5f) * 0.14f;
    float hz = z + (rng.nextFloat() - 0.5f) * 0.14f;
    float hy = y + (0.65f + rng.nextFloat() * 0.25f) * s;
    tube(acc, x, y, z, 0.018f, hx, hy, hz, 0.014f, 4, cb(0x4A8F35));
    float la = rng.nextFloat() * TP;
    leaf(acc, x, y, z, la, 0.24f * s, 0.06f, LEAF_A);
    leaf(acc, x, y, z, la + 3.0f, 0.2f * s, 0.055f, LEAF_B);
    float yBack = cb(0xF2A900), yTip = cb(0xFFD21F), yFront = cb(0xFFC20E), yFrontTip = cb(0xFFE04D);
    float a0 = rng.nextFloat() * TP;
    for (int k = 0; k < 12; k++) {
        petal(acc, hx, hy - 0.006f, hz, a0 + (k + 0.5f) * TP / 12.0f, 0.06f * s, 0.15f * s, 0.024f * s, 0.016f, yBack, yTip);
    }
    for (int k = 0; k < 12; k++) {
        petal(acc, hx, hy + 0.002f, hz, a0 + k * TP / 12.0f, 0.06f * s, 0.175f * s, 0.026f * s, 0.022f, yFront, yFrontTip);
    }
    dome(acc, hx, hy + 0.004f, hz, 0.078f * s, 0.016f, 8, cb(0x6B4423));
    dome(acc, hx, hy + 0.014f, hz, 0.046f * s, 0.016f, 8, cb(0x3E2610));
}

const uint32_t CAP[4]   = {0xD4261C, 0x8A5A2C, 0xEEE6D4, 0xE58E26};
const uint32_t STEMC[4] = {0xF3EEE0, 0xE6D6B4, 0xFAF6EC, 0xF3DDA4};
const uint32_t GILL[4]  = {0xEDE3CF, 0xC9AE7E, 0xD9C9A8, 0xF0C070};
const float CAP_R[4]  = {0.15f, 0.17f, 0.10f, 0.12f};
const float STEM_H[4] = {0.20f, 0.14f, 0.14f, 0.22f};
const float CAP_H[4]  = {0.13f, 0.085f, 0.09f, 0.10f};
const float STEM_R[4] = {0.030f, 0.048f, 0.025f, 0.028f};
}  // namespace

namespace Flora {

void flower(MeshAccum& acc, int type, float x, float y, float z, JavaRandom& rng) {
    switch (type) {
        case 0: daisy(acc, x, y, z, rng); break;
        case 1: poppy(acc, x, y, z, rng); break;
        case 2: tulip(acc, x, y, z, rng); break;
        case 3: lavender(acc, x, y, z, rng); break;
        default: sunflower(acc, x, y, z, rng); break;
    }
}

void mushroom(MeshAccum& acc, float x, float y, float z, int kind, float s, JavaRandom& rng) {
    int k = km::coerceIn(kind, 0, 3);
    float capR = CAP_R[k] * s * (0.88f + rng.nextFloat() * 0.24f);
    float stemH = STEM_H[k] * s * (0.85f + rng.nextFloat() * 0.3f);
    float capH = CAP_H[k] * s;
    float stemR = STEM_R[k] * s;
    float lx = (rng.nextFloat() - 0.5f) * 0.05f * s;
    float lz = (rng.nextFloat() - 0.5f) * 0.05f * s;
    float tx = x + lx, tz = z + lz, ty = y + stemH;
    float cStem = cb(STEMC[k]);

    // caule: base mais larga (afundada na terra) e afinando para cima
    tube(acc, x, y - 0.02f, z, stemR * 1.5f, x + lx * 0.4f, y + stemH * 0.45f, z + lz * 0.4f, stemR * 1.1f, 6, cStem);
    tube(acc, x + lx * 0.4f, y + stemH * 0.45f, z + lz * 0.4f, stemR * 1.1f, tx, ty, tz, stemR, 6, cStem);
    if (k == 0) {   // anel (saia) da amanita
        tube(acc, x + lx * 0.5f, y + stemH * 0.52f, z + lz * 0.5f, stemR * 2.1f, x + lx * 0.6f, y + stemH * 0.7f, z + lz * 0.6f, stemR * 1.15f, 6, cb(0xFFFFFF));
    }

    // chapéu: aro -> meio -> alto -> ponta
    float rot = rng.nextFloat() * TP;
    float m1R = capR * 0.86f, m2R = capR * 0.48f;
    float m1Y = ty + capH * 0.55f, m2Y = ty + capH * 0.92f, apY = ty + capH;
    float cenY = ty - capR * 0.35f;
    float cRim = cb(CAP[k], 0.88f), cMid = cb(CAP[k]), cTop = cb(CAP[k], 1.12f), cGill = cb(GILL[k]);
    const int n = 6;
    for (int i = 0; i < n; i++) {
        float a0 = rot + i * TP / n;
        float a1 = a0 + TP / n;
        float c0 = km::cos(a0), s0 = km::sin(a0), c1 = km::cos(a1), s1 = km::sin(a1);
        float r0x = tx + c0 * capR, r0z = tz + s0 * capR;
        float r1x = tx + c1 * capR, r1z = tz + s1 * capR;
        float q0x = tx + c0 * m1R, q0z = tz + s0 * m1R;
        float q1x = tx + c1 * m1R, q1z = tz + s1 * m1R;
        float u0x = tx + c0 * m2R, u0z = tz + s0 * m2R;
        float u1x = tx + c1 * m2R, u1z = tz + s1 * m2R;
        acc.triOut(r0x, ty, r0z, r1x, ty, r1z, q1x, m1Y, q1z, tx, cenY, tz, cRim);
        acc.triOut(r0x, ty, r0z, q1x, m1Y, q1z, q0x, m1Y, q0z, tx, cenY, tz, cRim);
        acc.triOut(q0x, m1Y, q0z, q1x, m1Y, q1z, u1x, m2Y, u1z, tx, cenY, tz, cMid);
        acc.triOut(q0x, m1Y, q0z, u1x, m2Y, u1z, u0x, m2Y, u0z, tx, cenY, tz, cMid);
        acc.triOut(u0x, m2Y, u0z, u1x, m2Y, u1z, tx, apY, tz, tx, cenY, tz, cTop);
        // parte de baixo do chapéu (lamelas), virada para baixo
        acc.triOut(r0x, ty - 0.004f, r0z, r1x, ty - 0.004f, r1z, tx, ty - 0.02f, tz, tx, ty + capR, tz, cGill);
    }
    if (k == 0) {   // pintas brancas na amanita
        float white = cb(0xFFFFFF);
        for (int q = 0; q < 6; q++) {
            float a = rng.nextFloat() * TP;
            float f = 0.15f + rng.nextFloat() * 0.75f;
            float rr = (m1R + (m2R - m1R) * f) * 1.0f;
            float yy = m1Y + (m2Y - m1Y) * f + 0.012f * s;
            float da = 0.03f * s / rr;
            float r2 = rr - 0.028f * s;
            acc.triOut(tx + km::cos(a - da) * (rr + 0.01f * s), yy, tz + km::sin(a - da) * (rr + 0.01f * s),
                       tx + km::cos(a + da) * (rr + 0.01f * s), yy, tz + km::sin(a + da) * (rr + 0.01f * s),
                       tx + km::cos(a) * r2, yy + 0.02f * s, tz + km::sin(a) * r2,
                       tx, cenY, tz, white);
        }
    }
}

}  // namespace Flora
