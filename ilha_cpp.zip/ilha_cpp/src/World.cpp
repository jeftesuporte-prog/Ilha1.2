#include "World.h"
#include <array>
#include <unordered_map>
#include "KMath.h"
#include "SimplexNoise.h"

using km::max; using km::min; using km::coerceIn;

// =============================== Base ===============================
namespace Base {
static const SimplexNoise& noise() { static const SimplexNoise s(Cfg::SEED); return s; }

const std::vector<Peak>& peaks() {
    static const std::vector<Peak> p = {
        {0.0f, 0.0f, Cfg::MAIN_H, Cfg::MAIN_R},   // montanha principal no centro
        {-250.0f, -150.0f, 85.0f, 75.0f},
        {280.0f, 140.0f, 90.0f, 75.0f},
        {-30.0f, -250.0f, 75.0f, 65.0f},
    };
    return p;
}

float n(float x, float z) { return noise().noise(static_cast<double>(x), static_cast<double>(z)); }

float shape(float x, float z) {
    float w = n(x * 0.0035f, z * 0.0035f) * 0.075f + n(x * 0.011f + 40.0f, z * 0.011f) * 0.025f;
    float nx = x / Cfg::A;
    float nz = z / Cfg::B;
    return km::sqrt(nx * nx + nz * nz) * (1.0f + w);
}

float depth(float x, float z) {
    float s = shape(x, z);
    float gx = x / (Cfg::A * Cfg::A);
    float gz = z / (Cfg::B * Cfg::B);
    float nx = x / Cfg::A;
    float nz = z / Cfg::B;
    float r0 = km::sqrt(nx * nx + nz * nz);
    float m = r0 > 1e-3f ? km::sqrt(gx * gx + gz * gz) / r0 : 1.0f / Cfg::B;
    return (1.0f - s) / max(m, 1e-4f);
}

float orchard(float x, float z) {
    float dx = x - Cfg::ORCHARD_X;
    float dz = z - Cfg::ORCHARD_Z;
    return 1.0f - smooth(Cfg::ORCHARD_R * 0.7f, Cfg::ORCHARD_R, km::sqrt(dx * dx + dz * dz));
}

float grove(float x, float z) {
    float dx = x - Cfg::GROVE_X;
    float dz = z - Cfg::GROVE_Z;
    return 1.0f - smooth(Cfg::GROVE_R * 0.7f, Cfg::GROVE_R, km::sqrt(dx * dx + dz * dz));
}

float forestW(float x, float z, float d, float h) {
    if (d <= 0.0f) return 0.0f;
    float inland = smooth(Cfg::BEACH + 6.0f, Cfg::BEACH + 30.0f, d);
    float alt = 1.0f - smooth(35.0f, 60.0f, h);
    float clump = smooth(-0.5f, 0.0f, n(x * 0.010f + 11.0f, z * 0.010f - 4.0f));
    return inland * alt * clump * (1.0f - max(grove(x, z), orchard(x, z)));
}

float baseHeight(float x, float z) {
    float d = depth(x, z);
    if (d <= 0.0f) return max(-14.0f, d * 0.12f);           // fundo do mar suave

    float beach = d * 0.03f;                                 // praia: 0 -> ~1.2 m
    float land = max(1.0f, 2.5f + 2.5f * n(x * 0.012f, z * 0.012f) + 1.2f * n(x * 0.04f, z * 0.04f));
    float w = smooth(Cfg::BEACH - 10.0f, Cfg::BEACH + 20.0f, d);
    float h = beach + (land - beach) * w;

    float m = 0.0f;
    for (const Peak& p : peaks()) {
        float dx = x - p.x;
        float dz = z - p.z;
        float warp = 1.0f + 0.16f * n(x * 0.008f + p.x, z * 0.008f + p.z);
        float rr = km::sqrt(dx * dx + dz * dz) * warp;
        float t = coerceIn(1.0f - rr / p.r, 0.0f, 1.0f);
        if (t > 0.0f) {
            float prof = km::pow(t, 1.35f);
            float crag = 1.0f - km::abs(n(x * 0.03f + p.x, z * 0.03f + p.z));
            float hm = p.h * 0.95f * prof + crag * p.h * 0.05f * km::sqrt(prof);
            if (hm > m) m = hm;
        }
    }
    h += m;
    return h;
}
}  // namespace Base

// ============================== RoadNet ==============================
namespace {
struct RoadData {
    float shoreX, shoreZ, startX, startZ;
    float bridgeX, bridgeZ, bridgeTX, bridgeTZ;
    std::vector<float> xs, zs, hs;
    std::unordered_map<int, std::vector<int>> grid;

    static int key(int i, int j) { return (i + 200) * 1000 + (j + 200); }

    static float cr(float a, float b, float c, float d, float t) {
        float t2 = t * t;
        float t3 = t2 * t;
        return 0.5f * ((2.0f * b) + (-a + c) * t + (2.0f * a - 5.0f * b + 4.0f * c - d) * t2 + (-a + 3.0f * b - 3.0f * c + d) * t3);
    }

    RoadData() {
        using std::array;
        constexpr float dirX = RoadNet::dirX, dirZ = RoadNet::dirZ;
        // 1) acha a costa na direção do píer
        float t = 0.0f;
        while (t < 800.0f && Base::depth(dirX * t, dirZ * t) > 0.0f) t += 1.0f;
        shoreX = dirX * t;
        shoreZ = dirZ * t;
        startX = shoreX - dirX * 12.0f;
        startZ = shoreZ - dirZ * 12.0f;

        // 2) pontos de controle
        std::vector<array<float, 2>> ctrl;
        ctrl.push_back({startX, startZ});
        float th0 = km::atan2(dirZ, dirX);
        float r0 = 148.0f;
        float ex = r0 * km::cos(th0);
        float ez = r0 * km::sin(th0);
        float fx = ex - startX;
        float fz = ez - startZ;
        float fl = km::sqrt(fx * fx + fz * fz);
        float px = -fz / fl;
        float pz = fx / fl;
        const int nf = 12;
        for (int i = 1; i < nf; i++) {                          // trecho sinuoso pela floresta
            float u = static_cast<float>(i) / static_cast<float>(nf);
            float off = 45.0f * km::sin(u * 6.9f) * km::sin(u * 3.14159f);
            ctrl.push_back({startX + fx * u + px * off, startZ + fz * u + pz * off});
        }
        const int steps = 72;                                    // espiral subindo a montanha (2.6 voltas)
        const float turns = 2.6f;
        for (int i = 0; i <= steps; i++) {
            float u = static_cast<float>(i) / static_cast<float>(steps);
            float ang = th0 + u * turns * 6.2831855f;
            float r = 148.0f + (14.0f - 148.0f) * u + 5.0f * km::sin(u * 17.0f);
            ctrl.push_back({r * km::cos(ang), r * km::sin(ang)});
        }

        // 3) Catmull-Rom a cada ~2.5 m
        std::vector<float> sx, sz;
        size_t forestEnd = 0;
        const int cn = static_cast<int>(ctrl.size());
        for (int i = 0; i < cn - 1; i++) {
            const auto& p0 = ctrl[std::max(i - 1, 0)];
            const auto& p1 = ctrl[i];
            const auto& p2 = ctrl[i + 1];
            const auto& p3 = ctrl[std::min(i + 2, cn - 1)];
            float len = km::hypot(p2[0] - p1[0], p2[1] - p1[1]);
            int st = std::max(2, static_cast<int>(len / 2.5f));
            for (int s = 0; s < st; s++) {
                float tt = static_cast<float>(s) / static_cast<float>(st);
                sx.push_back(cr(p0[0], p1[0], p2[0], p3[0], tt));
                sz.push_back(cr(p0[1], p1[1], p2[1], p3[1], tt));
            }
            if (i == nf - 1) forestEnd = sx.size();
        }
        sx.push_back(ctrl.back()[0]);
        sz.push_back(ctrl.back()[1]);
        const int n = static_cast<int>(sx.size());
        std::vector<float> lx(sx), lz(sz), h(n);
        for (int i = 0; i < n; i++) h[i] = Base::baseHeight(lx[i], lz[i]);

        // 4) suaviza a altura ao longo da estrada (rampa contínua, sem degraus)
        for (int rep = 0; rep < 4; rep++) {
            std::vector<float> tmp(h);
            for (int i = 0; i < n; i++) {
                float s = 0.0f;
                int c = 0;
                for (int k = -5; k <= 5; k++) {
                    int j = i + k;
                    if (j >= 0 && j < n) { s += tmp[j]; c++; }
                }
                h[i] = s / static_cast<float>(c);
            }
        }
        xs = lx; zs = lz; hs = h;

        // ponte: no meio do trecho de floresta da estrada
        int bi = km::coerceIn(static_cast<int>(forestEnd) / 2, 4, n - 5);
        bridgeX = lx[bi];
        bridgeZ = lz[bi];
        float btx = lx[bi + 3] - lx[bi - 3];
        float btz = lz[bi + 3] - lz[bi - 3];
        float bl = km::sqrt(btx * btx + btz * btz);
        bridgeTX = btx / bl;
        bridgeTZ = btz / bl;

        // 5) grade espacial p/ consulta rápida
        for (int i = 0; i < n; i++) {
            grid[key(static_cast<int>(std::floor(lx[i] / 16.0f)), static_cast<int>(std::floor(lz[i] / 16.0f)))].push_back(i);
        }
    }
};
const RoadData& road() { static const RoadData r; return r; }
}  // namespace

namespace RoadNet {
float shoreX() { return road().shoreX; }
float shoreZ() { return road().shoreZ; }
float startX() { return road().startX; }
float startZ() { return road().startZ; }
float bridgeX() { return road().bridgeX; }
float bridgeZ() { return road().bridgeZ; }
float bridgeTX() { return road().bridgeTX; }
float bridgeTZ() { return road().bridgeTZ; }

void query(float x, float z, float out[2]) {
    const RoadData& R = road();
    float best = 1e9f;
    float bh = 0.0f;
    int ci = static_cast<int>(std::floor(x / 16.0f));
    int cj = static_cast<int>(std::floor(z / 16.0f));
    const int last = static_cast<int>(R.xs.size()) - 1;
    for (int i = ci - 1; i <= ci + 1; i++) for (int j = cj - 1; j <= cj + 1; j++) {
        auto it = R.grid.find(RoadData::key(i, j));
        if (it == R.grid.end()) continue;
        for (int idx : it->second) {
            float ax = R.xs[idx];
            float az = R.zs[idx];
            if (idx >= last) {
                float d = km::hypot(x - ax, z - az);
                if (d < best) { best = d; bh = R.hs[idx]; }
                continue;
            }
            float bx = R.xs[idx + 1];
            float bz = R.zs[idx + 1];
            float vx = bx - ax;
            float vz = bz - az;
            float l2 = vx * vx + vz * vz;
            float u = l2 > 1e-6f ? ((x - ax) * vx + (z - az) * vz) / l2 : 0.0f;
            u = coerceIn(u, 0.0f, 1.0f);
            float d = km::hypot(x - (ax + vx * u), z - (az + vz * u));
            if (d < best) { best = d; bh = R.hs[idx] + (R.hs[idx + 1] - R.hs[idx]) * u; }
        }
    }
    out[0] = best;
    out[1] = bh;
}

bool nearPier(float x, float z) {
    float rx = x - shoreX();
    float rz = z - shoreZ();
    float along = rx * dirX + rz * dirZ;
    float across = km::abs(-rx * dirZ + rz * dirX);
    return along > -14.0f && along < 36.0f && across < 6.0f;
}
}  // namespace RoadNet

// ================================ River ================================
namespace River {
static constexpr float AMP = 16.0f;   // curvas suaves (meandros)
static constexpr float K = 0.03f;

float dist(float x, float z) {
    float tx = RoadNet::bridgeTX(), tz = RoadNet::bridgeTZ();
    float rx = x - RoadNet::bridgeX();
    float rz = z - RoadNet::bridgeZ();
    float s = -rx * tz + rz * tx;            // posição ao longo do rio (perpendicular à estrada)
    float t = rx * tx + rz * tz;             // posição ao longo da estrada
    float off = AMP * (1.0f - km::cos(K * s));
    float slope = AMP * K * km::sin(K * s);
    return km::abs(t - off) / km::sqrt(1.0f + slope * slope);
}

float w2d(float x, float z) {
    return 1.0f - smooth(Cfg::RIVER_HALF, Cfg::RIVER_HALF + Cfg::RIVER_BANK, dist(x, z));
}
}  // namespace River

// ================================ Bridge ================================
namespace {
struct BridgeData {
    float hA, hB, deckY, pitchDeg;
    BridgeData() {
        float q[2];
        const float hl = Cfg::BRIDGE_HALF_LEN;
        const float x = RoadNet::bridgeX(), z = RoadNet::bridgeZ();
        const float dx = RoadNet::bridgeTX(), dz = RoadNet::bridgeTZ();
        RoadNet::query(x - dx * hl, z - dz * hl, q);
        hA = q[1];
        RoadNet::query(x + dx * hl, z + dz * hl, q);
        hB = q[1];
        deckY = (hA + hB) / 2.0f + 0.03f;           // deck rente ao chão (só 3 cm acima, sem vão)
        pitchDeg = km::atan2(hB - hA, 2.0f * hl) * 57.29578f;
    }
};
const BridgeData& bridge() { static const BridgeData b; return b; }
}  // namespace

namespace Bridge {
float x() { return RoadNet::bridgeX(); }
float z() { return RoadNet::bridgeZ(); }
float dx() { return RoadNet::bridgeTX(); }
float dz() { return RoadNet::bridgeTZ(); }
float deckY() { return bridge().deckY; }
float pitchDeg() { return bridge().pitchDeg; }
float along(float px, float pz) { return (px - x()) * dx() + (pz - z()) * dz(); }
float across(float px, float pz) { return -(px - x()) * dz() + (pz - z()) * dx(); }
float deckAt(float px, float pz) {
    const float hl = Cfg::BRIDGE_HALF_LEN;
    float u = coerceIn((along(px, pz) + hl) / (2.0f * hl), 0.0f, 1.0f);
    return bridge().hA + (bridge().hB - bridge().hA) * u + 0.03f;
}
bool onDeck(float px, float pz) {
    return km::abs(along(px, pz)) <= Cfg::BRIDGE_HALF_LEN && km::abs(across(px, pz)) <= Cfg::BRIDGE_HALF_W;
}
}  // namespace Bridge

// ================================= Pier =================================
namespace Pier {
float along(float x, float z) { return (x - RoadNet::shoreX()) * RoadNet::dirX + (z - RoadNet::shoreZ()) * RoadNet::dirZ; }
float across(float x, float z) { return -(x - RoadNet::shoreX()) * RoadNet::dirZ + (z - RoadNet::shoreZ()) * RoadNet::dirX; }
bool onDeck(float x, float z) {
    float a = along(x, z);
    return a >= -8.0f && a <= 30.0f && km::abs(across(x, z)) <= HALF_W;
}
}  // namespace Pier

// ================================= World =================================
namespace World {
float heightAt(float x, float z) {
    float b = Base::baseHeight(x, z);
    float q[2];
    RoadNet::query(x, z, q);
    float rd = q[0];
    float outer = Cfg::ROAD_W * 1.6f;
    float h = b;
    if (rd < outer) {
        float w = 1.0f - smooth(Cfg::ROAD_W * 0.5f, outer, rd);
        h = b + (q[1] - b) * w;
    }
    float rw = River::w2d(x, z);
    if (rw > 0.0f) {
        float d = Base::depth(x, z);
        if (d > 0.0f) {
            float wf = rw * (1.0f - smooth(8.0f, 16.0f, b));
            float bed = Cfg::RIVER_BED * smooth(0.0f, 6.0f, d);
            if (bed < h) h += (bed - h) * wf;
        }
    }
    return h;
}

float groundAt(float x, float z) {
    if (Bridge::onDeck(x, z)) return Bridge::deckAt(x, z);
    if (Pier::onDeck(x, z)) return Pier::TOP;
    return heightAt(x, z);
}

bool onDeck(float x, float z) { return Bridge::onDeck(x, z) || Pier::onDeck(x, z); }
bool inRiver(float x, float z) { return River::w2d(x, z) > 0.3f; }

bool reserved(float x, float z) {
    if (RoadNet::nearPier(x, z)) return true;
    if (River::dist(x, z) < Cfg::RIVER_HALF + Cfg::RIVER_BANK + 1.5f) return true;
    return km::abs(Bridge::along(x, z)) < Cfg::BRIDGE_HALF_LEN + 5.0f && km::abs(Bridge::across(x, z)) < 7.0f;
}

void sample(float x, float z, float h, float ny, float* o, int k) {
    float d = Base::depth(x, z);
    o[k + 9] = d;
    if (d <= 0.0f) {                                   // fundo do mar: areia que escurece e azula com a profundidade
        float df = smooth(0.0f, 16.0f, -d);
        o[k] = 0.95f - 0.50f * df;
        o[k + 1] = 0.97f - 0.28f * df;
        o[k + 2] = 1.0f - 0.10f * df;
        for (int i = 3; i <= 8; i++) o[k + i] = 0.0f;
        o[k + 5] = 1.0f;                               // fundo do mar = areia 100%
        return;
    }
    float rv = River::w2d(x, z) * (1.0f - smooth(8.0f, 16.0f, h));

    // pedra: encostas íngremes e tudo que é alto; musgo em manchas e no topo
    float steep = 1.0f - smooth(0.62f, 0.86f, ny);
    float high = smooth(40.0f, 95.0f, h);
    float rock = max(steep, high) * (1.0f - smooth(0.0f, 0.25f, rv));
    float mossTop = smooth(150.0f, 190.0f, h) * (0.55f + 0.45f * smooth(0.4f, 0.8f, ny));
    float mossPatch = smooth(0.2f, 0.5f, Base::n(x * 0.045f - 31.0f, z * 0.045f + 5.0f)) * smooth(30.0f, 90.0f, h) * 0.9f;
    float moss = max(mossTop, mossPatch);

    float sandW = max(1.0f - smooth(Cfg::BEACH - 4.0f, Cfg::BEACH + 6.0f, d), smooth(0.0f, 0.15f, rv));
    float fw = Base::forestW(x, z, d, h);

    float q[2];
    RoadNet::query(x, z, q);
    float half = Cfg::ROAD_W * 0.5f;
    float road = (1.0f - smooth(half - 0.3f, half + 0.8f, q[0])) * (1.0f - smooth(0.1f, 0.4f, rv));
    float roadOnLand = road * (1.0f - smooth(0.25f, 0.6f, sandW));

    float wetK = max(1.0f - smooth(0.0f, 7.0f, d), smooth(0.0f, 0.2f, rv)) * 0.9f;
    float sn = 0.97f + 0.03f * Base::n(x * 0.1f, z * 0.1f);
    float sandR = (1.0f - 0.30f * wetK) * sn;
    float sandG = (1.0f - 0.36f * wetK) * sn;
    float sandB = (1.0f - 0.46f * wetK) * sn;
    float grassT = (0.84f + 0.16f * (0.5f + 0.5f * Base::n(x * 0.035f + 5.0f, z * 0.035f))) * (1.0f - 0.12f * fw);
    float forestT = 0.74f + 0.26f * (0.5f + 0.5f * Base::n(x * 0.05f + 9.0f, z * 0.05f));
    float rockT = 0.66f + 0.34f * smooth(5.0f, 190.0f, h) + 0.05f * Base::n(x * 0.08f + 13.0f, z * 0.08f);

    float w1 = 1.0f - rock;
    float wS = w1 * sandW;
    float wRest = w1 * (1.0f - sandW);
    float wF = wRest * fw;
    float wG = wRest - wF;
    float r = rock * rockT + wS * sandR + wF * forestT + wG * grassT;
    float g = rock * rockT + wS * sandG + wF * forestT + wG * grassT;
    float b = rock * rockT + wS * sandB + wF * forestT + wG * grassT;
    r += (1.0f - r) * roadOnLand * 0.95f;
    g += (1.0f - g) * roadOnLand * 0.95f;
    b += (1.0f - b) * roadOnLand * 0.95f;
    o[k] = min(1.0f, r);
    o[k + 1] = min(1.0f, g);
    o[k + 2] = min(1.0f, b);
    o[k + 3] = rock;
    o[k + 4] = moss;
    o[k + 5] = wS;
    o[k + 6] = fw;
    o[k + 7] = roadOnLand;
    o[k + 8] = rv;
}
}  // namespace World
