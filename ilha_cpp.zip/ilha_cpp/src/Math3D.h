#pragma once
// Matemática 3D mínima para o Vulkan. Matrizes em coluna (m[coluna*4 + linha]), igual ao OpenGL/libGDX.
// Convenções: mundo com Y para cima; câmera olha para -Z; profundidade 0..1 (Vulkan); eixo Y da tela invertido na projeção.
#include <cmath>

struct Mat4 {
    float m[16];

    static Mat4 identity() { Mat4 r{}; r.m[0] = r.m[5] = r.m[10] = r.m[15] = 1.0f; return r; }

    // Projeção em perspectiva para Vulkan (profundidade 0..1, Y da tela para baixo).
    static Mat4 perspective(float fovyDeg, float aspect, float zn, float zf) {
        float f = 1.0f / std::tan(fovyDeg * 3.14159265358979f / 360.0f);
        Mat4 r{};
        r.m[0] = f / aspect;
        r.m[5] = -f;
        r.m[10] = zf / (zn - zf);
        r.m[11] = -1.0f;
        r.m[14] = zn * zf / (zn - zf);
        return r;
    }

    static Mat4 lookAt(float ex, float ey, float ez, float tx, float ty, float tz, float ux = 0, float uy = 1, float uz = 0) {
        float fx = tx - ex, fy = ty - ey, fz = tz - ez;
        float fl = std::sqrt(fx * fx + fy * fy + fz * fz);
        fx /= fl; fy /= fl; fz /= fl;
        float sx = fy * uz - fz * uy, sy = fz * ux - fx * uz, sz = fx * uy - fy * ux;   // s = f x up
        float sl = std::sqrt(sx * sx + sy * sy + sz * sz);
        sx /= sl; sy /= sl; sz /= sl;
        float vx = sy * fz - sz * fy, vy = sz * fx - sx * fz, vz = sx * fy - sy * fx;   // u = s x f
        Mat4 r = identity();
        r.m[0] = sx;  r.m[4] = sy;  r.m[8] = sz;
        r.m[1] = vx;  r.m[5] = vy;  r.m[9] = vz;
        r.m[2] = -fx; r.m[6] = -fy; r.m[10] = -fz;
        r.m[12] = -(sx * ex + sy * ey + sz * ez);
        r.m[13] = -(vx * ex + vy * ey + vz * ez);
        r.m[14] = fx * ex + fy * ey + fz * ez;
        return r;
    }

    Mat4 operator*(const Mat4& b) const {
        Mat4 r{};
        for (int c = 0; c < 4; c++) for (int row = 0; row < 4; row++) {
            float s = 0.0f;
            for (int k = 0; k < 4; k++) s += m[k * 4 + row] * b.m[c * 4 + k];
            r.m[c * 4 + row] = s;
        }
        return r;
    }

    // Inversa geral 4x4 (cofatores). Devolve identidade se a matriz for singular.
    Mat4 inverse() const {
        const float* a = m;
        float inv[16];
        inv[0]  =  a[5]*a[10]*a[15] - a[5]*a[11]*a[14] - a[9]*a[6]*a[15] + a[9]*a[7]*a[14] + a[13]*a[6]*a[11] - a[13]*a[7]*a[10];
        inv[4]  = -a[4]*a[10]*a[15] + a[4]*a[11]*a[14] + a[8]*a[6]*a[15] - a[8]*a[7]*a[14] - a[12]*a[6]*a[11] + a[12]*a[7]*a[10];
        inv[8]  =  a[4]*a[9]*a[15]  - a[4]*a[11]*a[13] - a[8]*a[5]*a[15] + a[8]*a[7]*a[13] + a[12]*a[5]*a[11] - a[12]*a[7]*a[9];
        inv[12] = -a[4]*a[9]*a[14]  + a[4]*a[10]*a[13] + a[8]*a[5]*a[14] - a[8]*a[6]*a[13] - a[12]*a[5]*a[10] + a[12]*a[6]*a[9];
        inv[1]  = -a[1]*a[10]*a[15] + a[1]*a[11]*a[14] + a[9]*a[2]*a[15] - a[9]*a[3]*a[14] - a[13]*a[2]*a[11] + a[13]*a[3]*a[10];
        inv[5]  =  a[0]*a[10]*a[15] - a[0]*a[11]*a[14] - a[8]*a[2]*a[15] + a[8]*a[3]*a[14] + a[12]*a[2]*a[11] - a[12]*a[3]*a[10];
        inv[9]  = -a[0]*a[9]*a[15]  + a[0]*a[11]*a[13] + a[8]*a[1]*a[15] - a[8]*a[3]*a[13] - a[12]*a[1]*a[11] + a[12]*a[3]*a[9];
        inv[13] =  a[0]*a[9]*a[14]  - a[0]*a[10]*a[13] - a[8]*a[1]*a[14] + a[8]*a[2]*a[13] + a[12]*a[1]*a[10] - a[12]*a[2]*a[9];
        inv[2]  =  a[1]*a[6]*a[15]  - a[1]*a[7]*a[14]  - a[5]*a[2]*a[15] + a[5]*a[3]*a[14] + a[13]*a[2]*a[7]  - a[13]*a[3]*a[6];
        inv[6]  = -a[0]*a[6]*a[15]  + a[0]*a[7]*a[14]  + a[4]*a[2]*a[15] - a[4]*a[3]*a[14] - a[12]*a[2]*a[7]  + a[12]*a[3]*a[6];
        inv[10] =  a[0]*a[5]*a[15]  - a[0]*a[7]*a[13]  - a[4]*a[1]*a[15] + a[4]*a[3]*a[13] + a[12]*a[1]*a[7]  - a[12]*a[3]*a[5];
        inv[14] = -a[0]*a[5]*a[14]  + a[0]*a[6]*a[13]  + a[4]*a[1]*a[14] - a[4]*a[2]*a[13] - a[12]*a[1]*a[6]  + a[12]*a[2]*a[5];
        inv[3]  = -a[1]*a[6]*a[11]  + a[1]*a[7]*a[10]  + a[5]*a[2]*a[11] - a[5]*a[3]*a[10] - a[9]*a[2]*a[7]   + a[9]*a[3]*a[6];
        inv[7]  =  a[0]*a[6]*a[11]  - a[0]*a[7]*a[10]  - a[4]*a[2]*a[11] + a[4]*a[3]*a[10] + a[8]*a[2]*a[7]   - a[8]*a[3]*a[6];
        inv[11] = -a[0]*a[5]*a[11]  + a[0]*a[7]*a[9]   + a[4]*a[1]*a[11] - a[4]*a[3]*a[9]  - a[8]*a[1]*a[7]   + a[8]*a[3]*a[5];
        inv[15] =  a[0]*a[5]*a[10]  - a[0]*a[6]*a[9]   - a[4]*a[1]*a[10] + a[4]*a[2]*a[9]  + a[8]*a[1]*a[6]   - a[8]*a[2]*a[5];
        float det = a[0]*inv[0] + a[1]*inv[4] + a[2]*inv[8] + a[3]*inv[12];
        if (det == 0.0f) return identity();
        float id = 1.0f / det;
        Mat4 r;
        for (int i = 0; i < 16; i++) r.m[i] = inv[i] * id;
        return r;
    }

    // Transforma o ponto (x,y,z,1) -> clip (x,y,z,w)
    void transform(float x, float y, float z, float out[4]) const {
        for (int row = 0; row < 4; row++) out[row] = m[row] * x + m[4 + row] * y + m[8 + row] * z + m[12 + row];
    }
};

// 6 planos do frustum, extraídos de proj*view (profundidade 0..1). Normais apontam para dentro.
struct Frustum {
    float p[6][4];

    void set(const Mat4& vp) {
        auto row = [&](int i, float o[4]) { o[0] = vp.m[i]; o[1] = vp.m[4 + i]; o[2] = vp.m[8 + i]; o[3] = vp.m[12 + i]; };
        float r0[4], r1[4], r2[4], r3[4];
        row(0, r0); row(1, r1); row(2, r2); row(3, r3);
        for (int i = 0; i < 4; i++) {
            p[0][i] = r3[i] + r0[i];   // esquerda
            p[1][i] = r3[i] - r0[i];   // direita
            p[2][i] = r3[i] + r1[i];   // baixo
            p[3][i] = r3[i] - r1[i];   // cima
            p[4][i] = r2[i];           // perto (z >= 0)
            p[5][i] = r3[i] - r2[i];   // longe (z <= w)
        }
    }

    bool intersectsBox(float minx, float miny, float minz, float maxx, float maxy, float maxz) const {
        for (int i = 0; i < 6; i++) {
            float px = p[i][0] >= 0 ? maxx : minx;
            float py = p[i][1] >= 0 ? maxy : miny;
            float pz = p[i][2] >= 0 ? maxz : minz;
            if (p[i][0] * px + p[i][1] * py + p[i][2] * pz + p[i][3] < 0.0f) return false;
        }
        return true;
    }
};
