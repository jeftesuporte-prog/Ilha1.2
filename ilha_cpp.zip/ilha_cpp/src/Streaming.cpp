#include "Streaming.h"
#include <algorithm>

namespace {
constexpr float kPi = 3.14159265358979f;
constexpr int chunksFor(float r, float keep) {
    float rr = r + keep;
    return static_cast<int>(kPi * rr * rr / 10000.0f) + 6;     // chunks de 100 m dentro do raio de manutenção, com folga
}
constexpr StreamProfile P[Streaming::LEVELS] = {
    //  nome      terreno decor detalhe sombra vaga-l. névoa  keep pend. up/frame  caps(calculados abaixo)
    {"MINIMO",     220.0f,  80.0f, 25.0f, 30.0f, 35.0f,  240.0f, 70.0f, 3, 1, chunksFor(220.0f, 70.0f), chunksFor(80.0f, 70.0f)},
    {"BAIXO",      290.0f, 125.0f, 40.0f, 40.0f, 45.0f,  315.0f, 80.0f, 4, 1, chunksFor(290.0f, 80.0f), chunksFor(125.0f, 80.0f)},
    {"MEDIO",      360.0f, 185.0f, 65.0f, 55.0f, 60.0f,  390.0f, 90.0f, 6, 2, chunksFor(360.0f, 90.0f), chunksFor(185.0f, 90.0f)},
    {"ALTO",       430.0f, 250.0f, 90.0f, 75.0f, 70.0f, 1000.0f, 90.0f, 8, 2, chunksFor(430.0f, 90.0f), chunksFor(250.0f, 90.0f)},
};
}  // namespace

const StreamProfile& Streaming::profile(int level) {
    return P[std::min(std::max(level, 0), LEVELS - 1)];
}

float Streaming::priority(float dist, float toX, float toZ, float dirX, float dirZ) {
    float tl = std::sqrt(toX * toX + toZ * toZ);
    float dl = std::sqrt(dirX * dirX + dirZ * dirZ);
    if (tl < 1e-3f || dl < 1e-3f) return dist;                 // sem direção conhecida: só a distância
    float c = (toX * dirX + toZ * dirZ) / (tl * dl);           // 1 = bem na frente, -1 = atrás
    return dist * (1.0f + 0.5f * (1.0f - c));                  // frente x1.0, lado x1.5, atrás x2.0
}

bool QualityController::frame(float dt) {
    if (dt <= 0.0f || dt > 0.5f) return false;                // pausa/troca de app/engasgo isolado: não conta
    clock_ += dt;
    winT_ += dt;
    winFrames_++;
    if (winT_ < 2.0f) return false;

    fps_ = static_cast<float>(winFrames_) / winT_;
    winT_ = 0.0f;
    winFrames_ = 0;
    if (clock_ > ceilingUntil_) ceiling_ = Streaming::LEVELS - 1;

    if (fps_ < 32.0f) { lowWins_++; highWins_ = 0; }
    else if (fps_ > 55.0f) { highWins_++; lowWins_ = 0; }
    else { lowWins_ = 0; highWins_ = 0; }

    if (lowWins_ >= 2 && level_ > 0) {
        // desceu logo depois de subir: aquele nível mais alto não serve para este celular
        if (clock_ - lastUp_ < 30.0f) { ceiling_ = level_ - 1; ceilingUntil_ = clock_ + 180.0f; }
        level_--;
        lowWins_ = 0;
        lastChange_ = clock_;
        return true;
    }
    if (highWins_ >= 6 && level_ < ceiling_ && clock_ - lastChange_ >= 8.0f) {
        level_++;
        highWins_ = 0;
        lastChange_ = clock_;
        lastUp_ = clock_;
        return true;
    }
    return false;
}
