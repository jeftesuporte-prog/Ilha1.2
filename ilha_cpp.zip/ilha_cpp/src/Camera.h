#pragma once
// Câmera em 3ª pessoa do IlhaGame.update: olha de trás do boneco, 5,5 m de distância, nunca entra no chão nem em pedra.
#include "ChunkManager.h"   // Colliders
#include "KMath.h"
#include "Player.h"
#include "World.h"

struct CameraRig {
    float yaw = km::atan2(-0.6f, 0.8f);    // câmera inicial olha da praia para o centro da ilha
    float pitch = 0.07f;
    static constexpr float DIST = 5.5f;
    static constexpr float LOOK_SENS = 0.0035f;   // radianos por pixel arrastado
    float pos[3] = {0, 0, 0};
    float dir[3] = {1, 0, 0};

    // lookX/lookY = arrasto em pixels (Controls)
    void look(float lookX, float lookY) {
        yaw += lookX * LOOK_SENS;
        pitch = km::coerceIn(pitch - lookY * LOOK_SENS, -0.9f, 1.2f);
    }

    void update(const Vec3& target, const Colliders& c) {
        const float cp = km::cos(pitch);
        float dx = cp * km::cos(yaw), dy = km::sin(pitch), dz = cp * km::sin(yaw);
        // Vector3.nor() do libGDX
        const float len2 = dx * dx + dy * dy + dz * dz;
        if (len2 != 0.0f && len2 != 1.0f) {
            const float s = 1.0f / km::sqrt(len2);
            dx *= s; dy *= s; dz *= s;
        }
        dir[0] = dx; dir[1] = dy; dir[2] = dz;
        const float tx = target.x, ty = target.y + 1.5f, tz = target.z;
        const float cx = tx - dx * DIST;
        float cy = ty - dy * DIST;
        const float cz = tz - dz * DIST;
        cy = km::max(cy, c.rockFloor(cx, cz, World::groundAt(cx, cz)) + 0.6f);
        pos[0] = cx; pos[1] = cy; pos[2] = cz;
    }
};
