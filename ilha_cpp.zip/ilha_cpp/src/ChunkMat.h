#pragma once
// Índices de material das partes de um chunk (ChunkManager.M_* do Kotlin).
namespace ChunkMat {
constexpr int SAND = 0;
constexpr int GRASS = 1;
constexpr int ROCK = 2;
constexpr int ROCKMOSS = 3;
constexpr int FOREST = 4;
constexpr int DECO = 5;       // árvores, arbustos, flores (cor de vértice, stride 7)
constexpr int DECOROCK = 6;   // pedras (textura de pedra)
constexpr int PALM = 7;       // coqueiros e árvores com vento (stride 10)
// Só no port: "detalhe" = flores, cogumelos e pedrinhas, separados para só serem desenhados dentro do raio de detalhe
// (StreamProfile::detailR). Mesmo visual do original, só que em partes à parte.
constexpr int DECO_DETAIL = 8;      // flores e cogumelos (cor de vértice, stride 7)
constexpr int DECOROCK_DETAIL = 9;  // pedrinhas (textura de pedra, stride 9)
constexpr int COUNT = 10;
inline int strideOf(int mat) { return (mat == DECO || mat == DECO_DETAIL) ? 7 : (mat == PALM) ? 10 : 9; }
inline bool isDetail(int mat) { return mat == DECO_DETAIL || mat == DECOROCK_DETAIL; }
}
