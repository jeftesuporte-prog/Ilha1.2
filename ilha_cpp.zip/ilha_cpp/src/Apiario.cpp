#include "Apiario.h"
#include <cmath>
#include "Cfg.h"
#include "JavaRandom.h"
#include "KMath.h"
#include "World.h"

namespace Apiario {

const float HEAD[5] = {0.45f, 0.55f, 0.62f, 0.50f, 0.95f};

float Hive::wx(float lx, float lz) const { return x + lx * km::cos(yaw) + lz * km::sin(yaw); }
float Hive::wz(float lx, float lz) const { return z - lx * km::sin(yaw) + lz * km::cos(yaw); }

namespace {

struct Data {
    std::vector<Hive> hives;
    std::vector<Meadow> meadows;
};

bool siteOk(float x, float z, bool strict) {
    if (km::abs(x) > Cfg::HALF - 40.0f || km::abs(z) > Cfg::HALF - 40.0f) return false;
    float d = Base::depth(x, z);
    if (d < Cfg::BEACH + (strict ? 16.0f : 8.0f)) return false;          // nada na praia
    float h = World::heightAt(x, z);
    if (h > (strict ? 38.0f : 45.0f) || h < 0.8f) return false;
    if (World::reserved(x, z) || World::inRiver(x, z)) return false;      // World::reserved aqui = reservedBase do Kotlin
    if (River::dist(x, z) < Cfg::RIVER_HALF + Cfg::RIVER_BANK + (strict ? 6.0f : 1.0f)) return false;
    float q[2];
    RoadNet::query(x, z, q);
    if (q[0] < Cfg::ROAD_W * (strict ? 1.8f : 0.6f) + (strict ? 5.0f : 2.0f)) return false;
    if (Base::forestW(x, z, d, h) > (strict ? 0.55f : 0.6f)) return false;
    if (strict) {
        float gx = (World::heightAt(x + 2.0f, z) - World::heightAt(x - 2.0f, z)) / 4.0f;
        float gz = (World::heightAt(x, z + 2.0f) - World::heightAt(x, z - 2.0f)) / 4.0f;
        if (1.0f / km::sqrt(1.0f + gx * gx + gz * gz) < 0.94f) return false;   // so chao quase plano
    }
    return true;
}

// um prado: tufos (varias cores) de flores em volta do centro, sem cair na estrada/rio/praia nem em cima da colmeia
Meadow makeMeadow(int hiveIdx, float cx, float cz, float hx, float hz, JavaRandom& rnd) {
    const int n = 190;
    float r = 5.0f + rnd.nextFloat() * 3.5f;
    Meadow m;
    m.hive = hiveIdx; m.cx = cx; m.cz = cz; m.r = r;
    m.fx.assign(n, 0.0f); m.fy.assign(n, 0.0f); m.fz.assign(n, 0.0f);
    m.ft.assign(n, 0); m.fs.assign(n, 0);
    int mainType = rnd.nextInt(5);
    int nt = 5 + rnd.nextInt(3);   // 5 a 7 tufos dentro do prado
    std::vector<float> tx(nt), tz(nt);
    std::vector<int> tt(nt);
    for (int i = 0; i < nt; i++) {
        float a = rnd.nextFloat() * 6.2831855f;
        float rr = r * 0.75f * km::sqrt(rnd.nextFloat());
        tx[i] = cx + km::cos(a) * rr;
        tz[i] = cz + km::sin(a) * rr;
        tt[i] = rnd.nextFloat() < 0.55f ? mainType : rnd.nextInt(5);
    }
    int tries = 0;
    while (m.count < n && tries < n * 4) {
        tries++;
        int ti = rnd.nextInt(nt);
        // (Kotlin avalia da esquerda para a direita: as 2 chamadas de cada linha saem em ordem)
        float r1 = rnd.nextFloat(); float r2 = rnd.nextFloat();
        float x = tx[ti] + (r1 + r2 - 1.0f) * 2.6f;
        float r3 = rnd.nextFloat(); float r4 = rnd.nextFloat();
        float z = tz[ti] + (r3 + r4 - 1.0f) * 2.6f;
        if (km::hypot(x - hx, z - hz) < 3.4f) continue;                 // deixa a colmeia livre
        float d = Base::depth(x, z);
        if (d < Cfg::BEACH + 8.0f) continue;
        float h = World::heightAt(x, z);
        if (h < 0.8f || h > 45.0f) continue;
        if (World::reserved(x, z) || World::inRiver(x, z)) continue;
        if (River::dist(x, z) < Cfg::RIVER_HALF + Cfg::RIVER_BANK + 1.0f) continue;
        float q[2];
        RoadNet::query(x, z, q);
        if (q[0] < Cfg::ROAD_W * 0.5f + 2.0f) continue;
        if (Base::forestW(x, z, d, h) > 0.6f) continue;
        int i = m.count++;
        m.fx[i] = x; m.fy[i] = h; m.fz[i] = z;
        m.ft[i] = rnd.nextFloat() < 0.8f ? tt[ti] : rnd.nextInt(5);
        m.fs[i] = rnd.nextLong();
    }
    return m;
}

Data build() {
    Data D;
    JavaRandom rnd(4242);
    const int want = Cfg::COLMEIAS;
    float startX = RoadNet::startX();
    float startZ = RoadNet::startZ();
    int guard = 0;
    while (static_cast<int>(D.hives.size()) < want && guard < want * 6) {
        guard++;
        float bx = 0.0f, bz = 0.0f, bd = -1.0f;
        for (int t = 0; t < 60; t++) {
            float x, z;
            if (D.hives.empty()) {                       // a primeira: perto do comeco (50 a 120 m)
                float a = rnd.nextFloat() * 6.2831855f;
                float r = 55.0f + rnd.nextFloat() * 65.0f;
                x = startX + km::cos(a) * r;
                z = startZ + km::sin(a) * r;
            } else {
                float ra = rnd.nextFloat();
                x = (ra * 2.0f - 1.0f) * (Cfg::HALF - 60.0f);
                float rb = rnd.nextFloat();
                z = (rb * 2.0f - 1.0f) * (Cfg::HALF - 60.0f);
            }
            if (!siteOk(x, z, true)) continue;
            float md = 1e9f;
            for (const Hive& h : D.hives) md = km::min(md, km::hypot(h.x - x, h.z - z));
            if (md > bd) { bd = md; bx = x; bz = z; }     // o candidato mais longe das outras colmeias
        }
        if (bd < 0.0f) continue;
        if (!D.hives.empty() && bd < 50.0f) continue;     // nunca muito juntas
        float gy = World::groundAt(bx, bz);
        // 3 prados em volta
        float a0 = rnd.nextFloat() * 6.2831855f;
        std::vector<Meadow> found;
        for (int m = 0; m < 3; m++) {
            for (int tries = 0; tries < 8; tries++) {
                float ra = rnd.nextFloat();
                float a = a0 + m * 2.0943952f + (ra - 0.5f) * 0.9f;
                float dist = 14.0f + rnd.nextFloat() * 24.0f;
                float mx = bx + km::cos(a) * dist;
                float mz = bz + km::sin(a) * dist;
                if (!siteOk(mx, mz, false)) continue;
                Meadow mead = makeMeadow(static_cast<int>(D.hives.size()), mx, mz, bx, bz, rnd);
                if (mead.count >= 40) { found.push_back(std::move(mead)); break; }
            }
        }
        if (found.empty()) continue;                      // sem flores perto: descarta o lugar
        float yaw = km::atan2(found[0].cx - bx, found[0].cz - bz);   // a entrada olha para o primeiro prado
        Hive h2{bx, bz, gy, yaw, static_cast<int>(D.hives.size()) % 3};
        h2.honey = 0.05f + 0.2f * rnd.nextFloat();
        for (Meadow& m : found) {
            h2.meadows.push_back(static_cast<int>(D.meadows.size()));
            D.meadows.push_back(std::move(m));
        }
        D.hives.push_back(std::move(h2));
    }
    return D;
}

const Data& data() {
    static const Data D = build();
    return D;
}

}  // namespace

const std::vector<Hive>& hives() { return data().hives; }
const std::vector<Meadow>& meadows() { return data().meadows; }

bool reserved(float x, float z) {
    for (const Hive& h : hives()) {
        float dx = x - h.x, dz = z - h.z;
        if (dx * dx + dz * dz < 6.5f * 6.5f) return true;
    }
    for (const Meadow& m : meadows()) {
        float dx = x - m.cx, dz = z - m.cz;
        float rr = m.r + 1.2f;
        if (dx * dx + dz * dz < rr * rr) return true;
    }
    return false;
}

void forEachFlower(float x0, float z0, float x1, float z1,
                   const std::function<void(int, float, float, float, int64_t)>& f) {
    for (const Meadow& m : meadows()) {
        if (m.cx + m.r < x0 || m.cx - m.r > x1 || m.cz + m.r < z0 || m.cz - m.r > z1) continue;
        for (int i = 0; i < m.count; i++) {
            float x = m.fx[i], z = m.fz[i];
            if (x < x0 || x >= x1 || z < z0 || z >= z1) continue;
            f(m.ft[i], x, m.fy[i], z, m.fs[i]);
        }
    }
}

void pushOut(float out[2], float pr) {
    for (const Hive& h : hives()) {
        float dx = out[0] - h.x;
        if (dx > 2.5f || dx < -2.5f) continue;
        float dz = out[1] - h.z;
        if (dz > 2.5f || dz < -2.5f) continue;
        float rr = 0.35f + pr;            // so o tronco da arvore da colmeia e solido (o ninho fica no alto)
        float d2 = dx * dx + dz * dz;
        if (d2 < rr * rr) {
            if (d2 < 1e-6f) {
                out[0] = h.x + rr;
            } else {
                float d = km::sqrt(d2);
                out[0] = h.x + dx / d * rr;
                out[1] = h.z + dz / d * rr;
            }
        }
    }
}

int nearest(float x, float z) {
    int best = -1;
    float bd = 3.4028235e38f;
    const auto& hv = hives();
    for (int i = 0; i < static_cast<int>(hv.size()); i++) {
        float dx = hv[i].x - x, dz = hv[i].z - z;
        float d = dx * dx + dz * dz;
        if (d < bd) { bd = d; best = i; }
    }
    return best;
}

}  // namespace Apiario
