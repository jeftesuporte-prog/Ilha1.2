#pragma once
// Port 1:1 das primitivas de vegetação do ChunkBuilder.kt (blob, tronco, copas, coqueiro, bananeira, pomar).
// IMPORTANTE: a ordem das chamadas ao JavaRandom é a do Kotlin (a mesma árvore sai em qualquer chunk).
#include <cstdint>
#include <vector>
#include "Apiario.h"
#include "JavaRandom.h"
#include "MeshAccum.h"

namespace Trees {
// Prepara o vento de UMA árvore: base no chão, altura, fase própria e intensidade (1 = coqueiro, ~0,2 = árvore da mata).
void windTree(MeshAccum& a, float baseY, float h, int64_t seed, float amp);

void blob(MeshAccum& acc, float cx, float cy, float cz, float rx, float ry, float rz, float col, float jit, JavaRandom& rng);
void blobRock(MeshAccum& acc, float cx, float cy, float cz, float rx, float ry, float rz, float col, float jit, JavaRandom& rng);

void bigTree(MeshAccum& acc, float x, float y, float z, float hh, JavaRandom& rng, const Apiario::Hive* hive = nullptr);
// cocoOut/bananaOut/macaOut/laranjaOut: 12 floats por item (ver Coconuts.kt / Bananas.kt / Frutas.kt)
void palm(MeshAccum& acc, float x, float y, float z, float hh0, JavaRandom& rng, std::vector<float>& cocoOut);
void banana(MeshAccum& acc, float x, float y, float z, float hh, JavaRandom& rng, std::vector<float>& bananaOut);
void appleTree(MeshAccum& acc, float x, float y, float z, float hh, JavaRandom& rng, std::vector<float>& macaOut);
void orangeTree(MeshAccum& acc, float x, float y, float z, float hh, JavaRandom& rng, std::vector<float>& laranjaOut);
}  // namespace Trees
