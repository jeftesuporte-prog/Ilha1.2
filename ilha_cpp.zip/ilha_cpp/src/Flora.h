#pragma once
// Port 1:1 de Flora.kt: cogumelos (caule + chapéu) e 5 tipos de flores low-poly.
// Só funções puras (rodam em thread de fundo). Tudo vai para o MeshAccum de vértice colorido (stride 7).
#include "JavaRandom.h"
#include "MeshAccum.h"

namespace Flora {
// type: 0 margarida, 1 papoula, 2 tulipa, 3 lavanda, 4 girassol
void flower(MeshAccum& acc, int type, float x, float y, float z, JavaRandom& rng);
// kind: 0 amanita vermelha, 1 marrom gordinho, 2 branco (champignon), 3 laranja alto
void mushroom(MeshAccum& acc, float x, float y, float z, int kind, float s, JavaRandom& rng);
}  // namespace Flora
