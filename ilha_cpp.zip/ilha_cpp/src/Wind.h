#pragma once
// Port 1:1 de Wind.kt (Wind + WindCpu). O shader do vento (WindGlsl.SWAY) vai para shaders/wind_sway.glsl (etapa 6).
#include "KMath.h"

namespace Wind {
inline float time = 0.0f;
inline float gust = 0.0f;     // 0 = ar parado, ~0.5-0.8 = pico da rajada
inline float dirX = 0.82f;    // para onde o vento SOPRA (vetor unitário no plano do chão)
inline float dirZ = 0.57f;

void update(float dt);        // chame todo frame (dt em segundos)
}

namespace WindCpu {
// A MESMA conta do shader de vento, feita na CPU: de quanto um ponto da árvore se desloca agora.
Vec3 offset(float px, float py, float pz, float baseY, float h, float amp, float ph, float fl);
}
