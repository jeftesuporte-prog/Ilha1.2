#include "ChunkBuilder.h"
#include <cmath>
#include "ChunkMat.h"
#include "Cfg.h"
#include "KMath.h"
#include "World.h"
#include "Apiario.h"
#include "Flora.h"
#include "JavaRandom.h"
#include "Trees.h"

using km::max; using km::min;

namespace {
// Quantas vezes um triângulo na borda entre dois materiais (areia/grama/estrada...) é dividido em 4
// (3 => pedaços de ~0,3 m: borda lisa).
constexpr int ROAD_EDGE_DEPTH = 3;

struct TerrainBuilder {
    int sn = World::SN;
    float x0 = 0, z0 = 0, inv = 0;
    std::vector<MeshAccum> accs;

    // Material de UM ponto (sem "tremor": a borda entre materiais segue a curva suave, sem dentes).
    static int matOf(const float* a, int o) {
        if (a[o + 9] <= 0.0f) return ChunkMat::SAND;
        if (a[o + 7] > 0.5f) return ChunkMat::FOREST;
        if (a[o + 3] > 0.5f) return a[o + 4] > 0.4f ? ChunkMat::ROCKMOSS : ChunkMat::ROCK;
        if (a[o + 5] > 0.5f) return ChunkMat::SAND;
        if (a[o + 6] > 0.5f) return ChunkMat::FOREST;
        return ChunkMat::GRASS;
    }

    // Triângulo com dados de vértice (ai/ao = tom, pedra, musgo, areia, floresta, estrada, rio, dist. água).
    // Triângulos que cruzam a BORDA da estrada são subdivididos (depth) para a borda ficar reta e lisa.
    // A altura dos novos vértices é interpolada linearmente (mesma superfície do triângulo original => sem rachaduras).
    void put(float ax, float ay, float az, const float* ai, int ao,
             float bx, float by, float bz, const float* bi, int bo,
             float cx2, float cy, float cz2, const float* ci, int co,
             int depth) {
        float ux = bx - ax, uy = by - ay, uz = bz - az;
        float vx = cx2 - ax, vy = cy - ay, vz = cz2 - az;
        float nx = uy * vz - uz * vy;
        float ny = uz * vx - ux * vz;
        float nz = ux * vy - uy * vx;
        float l = km::sqrt(nx * nx + ny * ny + nz * nz);
        if (l < 1e-9f) return;

        float r0 = ai[ao + 7], r1 = bi[bo + 7], r2 = ci[co + 7];
        int m0 = matOf(ai, ao), m1 = matOf(bi, bo), m2 = matOf(ci, co);
        // areia/estrada: até o nível máximo; floresta/grama/pedra: 1 nível a menos (poupa triângulos)
        bool finoSand = m0 == ChunkMat::SAND || m1 == ChunkMat::SAND || m2 == ChunkMat::SAND;
        if (depth > 0 && (m0 != m1 || m1 != m2) && (depth > 1 || finoSand || max(r0, max(r1, r2)) >= 0.5f)) {
            float nyN = km::abs(ny / l);
            float mxab = (ax + bx) * 0.5f, mzab = (az + bz) * 0.5f, myab = (ay + by) * 0.5f;
            float mxbc = (bx + cx2) * 0.5f, mzbc = (bz + cz2) * 0.5f, mybc = (by + cy) * 0.5f;
            float mxca = (cx2 + ax) * 0.5f, mzca = (cz2 + az) * 0.5f, myca = (cy + ay) * 0.5f;
            float iab[World::SN]; World::sample(mxab, mzab, myab, nyN, iab, 0);
            float ibc[World::SN]; World::sample(mxbc, mzbc, mybc, nyN, ibc, 0);
            float ica[World::SN]; World::sample(mxca, mzca, myca, nyN, ica, 0);
            int d1 = depth - 1;
            put(ax, ay, az, ai, ao, mxab, myab, mzab, iab, 0, mxca, myca, mzca, ica, 0, d1);
            put(mxab, myab, mzab, iab, 0, bx, by, bz, bi, bo, mxbc, mybc, mzbc, ibc, 0, d1);
            put(mxca, myca, mzca, ica, 0, mxbc, mybc, mzbc, ibc, 0, cx2, cy, cz2, ci, co, d1);
            put(mxab, myab, mzab, iab, 0, mxbc, mybc, mzbc, ibc, 0, mxca, myca, mzca, ica, 0, d1);
            return;
        }

        // qual textura? decide pela média dos 3 vértices (borda lisa: os triângulos de fronteira já foram subdivididos)
        float d = min(ai[ao + 9], min(bi[bo + 9], ci[co + 9]));   // triângulo que encosta na água/mar = areia (nunca grama)
        float rock = (ai[ao + 3] + bi[bo + 3] + ci[co + 3]) / 3.0f;
        float moss = (ai[ao + 4] + bi[bo + 4] + ci[co + 4]) / 3.0f;
        float sand = (ai[ao + 5] + bi[bo + 5] + ci[co + 5]) / 3.0f;
        float fw = (ai[ao + 6] + bi[bo + 6] + ci[co + 6]) / 3.0f;
        float road = (r0 + r1 + r2) / 3.0f;
        int mat;
        if (d <= 0.0f) mat = ChunkMat::SAND;
        else if (road > 0.5f) mat = ChunkMat::FOREST;
        else if (rock > 0.5f) mat = moss > 0.4f ? ChunkMat::ROCKMOSS : ChunkMat::ROCK;
        else if (sand > 0.5f) mat = ChunkMat::SAND;
        else if (fw > 0.5f) mat = ChunkMat::FOREST;
        else mat = ChunkMat::GRASS;
        accs[mat].triVC(
            ax, ay, az, toFloatBits(ai[ao], ai[ao + 1], ai[ao + 2], 1.0f), (ax - x0) * inv, (az - z0) * inv,
            bx, by, bz, toFloatBits(bi[bo], bi[bo + 1], bi[bo + 2], 1.0f), (bx - x0) * inv, (bz - z0) * inv,
            cx2, cy, cz2, toFloatBits(ci[co], ci[co + 1], ci[co + 2], 1.0f), (cx2 - x0) * inv, (cz2 - z0) * inv,
            nx / l, ny / l, nz / l);
    }
};
}  // namespace

namespace ChunkBuilder {

Built terrain(int cx, int cz) {
    const int n = Cfg::CELLS;
    const float s = Cfg::CELL;
    const float x0 = static_cast<float>(cx) * Cfg::CHUNK - Cfg::HALF;
    const float z0 = static_cast<float>(cz) * Cfg::CHUNK - Cfg::HALF;
    const int w = n + 1;
    const int m = n + 3;                                  // grade com 1 de margem (para as normais nas bordas)
    std::vector<float> big(static_cast<size_t>(m) * m);
    for (int j = -1; j <= n + 1; j++) for (int i = -1; i <= n + 1; i++)
        big[(j + 1) * m + (i + 1)] = World::heightAt(x0 + static_cast<float>(i) * s, z0 + static_cast<float>(j) * s);

    std::vector<float> hs(static_cast<size_t>(w) * w);
    const int sn = World::SN;
    std::vector<float> inf(static_cast<size_t>(w) * w * sn);
    float minY = 1e9f;
    float maxY = -1e9f;
    for (int j = 0; j <= n; j++) for (int i = 0; i <= n; i++) {
        float h = big[(j + 1) * m + (i + 1)];
        hs[j * w + i] = h;
        if (h < minY) minY = h;
        if (h > maxY) maxY = h;
        float gx = (big[(j + 1) * m + (i + 2)] - big[(j + 1) * m + i]) / (2.0f * s);
        float gz = (big[(j + 2) * m + (i + 1)] - big[j * m + (i + 1)]) / (2.0f * s);
        float ny = 1.0f / km::sqrt(1.0f + gx * gx + gz * gz);
        World::sample(x0 + static_cast<float>(i) * s, z0 + static_cast<float>(j) * s, h, ny, inf.data(), (j * w + i) * sn);
    }

    TerrainBuilder tb;
    tb.x0 = x0; tb.z0 = z0; tb.inv = 1.0f / Cfg::TILE;
    tb.accs.reserve(5);
    for (int k = 0; k < 5; k++) tb.accs.emplace_back();

    auto emit = [&](int a, int b, int c) {
        tb.put(x0 + static_cast<float>(a % w) * s, hs[a], z0 + static_cast<float>(a / w) * s, inf.data(), a * sn,
               x0 + static_cast<float>(b % w) * s, hs[b], z0 + static_cast<float>(b / w) * s, inf.data(), b * sn,
               x0 + static_cast<float>(c % w) * s, hs[c], z0 + static_cast<float>(c / w) * s, inf.data(), c * sn,
               ROAD_EDGE_DEPTH);
    };

    for (int j = 0; j < n; j++) for (int i = 0; i < n; i++) {
        int i00 = j * w + i;
        int i10 = i00 + 1;
        int i01 = i00 + w;
        int i11 = i01 + 1;
        if ((i + j) % 2 == 0) {
            emit(i00, i01, i11);
            emit(i00, i11, i10);
        } else {
            emit(i00, i01, i10);
            emit(i10, i01, i11);
        }
    }

    Built b;
    b.layer = 0;
    b.key = cz * Cfg::CHUNKS + cx;
    for (int k = 0; k < 5; k++) for (auto& p : tb.accs[k].finish()) { b.parts.push_back(std::move(p)); b.mats.push_back(k); }
    b.minY = minY;
    b.maxY = maxY;
    return b;
}

namespace {
// p[0]=altura, p[1]=normalY, p[2]=distância da água (m), p[3]=distância da estrada, p[4]=peso de floresta
void probe(float x, float z, float p[5]) {
    p[0] = World::heightAt(x, z);
    float gx = (World::heightAt(x + 1.2f, z) - World::heightAt(x - 1.2f, z)) / 2.4f;
    float gz = (World::heightAt(x, z + 1.2f) - World::heightAt(x, z - 1.2f)) / 2.4f;
    p[1] = 1.0f / km::sqrt(1.0f + gx * gx + gz * gz);
    p[2] = Base::depth(x, z);
    float q[2];
    RoadNet::query(x, z, q);
    p[3] = q[0];
    p[4] = Base::forestW(x, z, p[2], p[0]);
}

// World.reserved do Kotlin = área fixa (píer, rio, ponte) OU colmeias e prados de flores
bool reservedAll(float x, float z) { return World::reserved(x, z) || Apiario::reserved(x, z); }
}  // namespace

Built decor(int cx, int cz) {
    MeshAccum acc(7);       // árvores, arbustos, flores (cor de vértice)
    MeshAccum racc;         // pedras (textura de pedra)
    MeshAccum pacc(10);     // coqueiros (balançam ao vento: cada vértice leva dados de vento)
    MeshAccum tacc(10);     // árvores da mata, bananeiras, macieiras, laranjeiras (balançam BEM pouco)
    MeshAccum dacc(7);      // [port] flores e cogumelos: parte à parte (só desenhada dentro do raio de detalhe)
    MeshAccum rdacc;        // [port] pedrinhas pequenas: idem
    Built b;
    std::vector<float>& solids = b.solids;
    std::vector<float>& rocks = b.rocks;
    std::vector<float>& bananaOut = b.bananas;
    std::vector<float>& laranjaOut = b.laranjas;
    std::vector<float>& macaOut = b.macas;
    std::vector<float>& cocoOut = b.palms;
    auto addSolid = [&](float x, float z, float r) { solids.push_back(x); solids.push_back(z); solids.push_back(r); };

    const float x0 = cx * Cfg::CHUNK - Cfg::HALF;
    const float z0 = cz * Cfg::CHUNK - Cfg::HALF;
    JavaRandom rng(Cfg::SEED * 31LL + static_cast<int64_t>(cx) * 7919LL + static_cast<int64_t>(cz) * 104729LL);
    float p[5];
    const float roadClear = Cfg::ROAD_W * 0.5f + 3.0f;

    // ---- árvores da floresta (modelo "TREE_01"): 7-9 m, tronco grosso torcido + galhos + copa de bolotas ----
    // Tronco TEM COLISÃO (copa o boneco atravessa).
    {
        const float sp = Cfg::TREE_SPACING;
        const int cnt = static_cast<int>(km::ceil(Cfg::CHUNK / sp));
        for (int gz = 0; gz < cnt; gz++) for (int gx = 0; gx < cnt; gx++) {
            float x = x0 + (gx + 0.5f) * sp + (rng.nextFloat() - 0.5f) * sp * 0.8f;
            float z = z0 + (gz + 0.5f) * sp + (rng.nextFloat() - 0.5f) * sp * 0.8f;
            float roll = rng.nextFloat();
            float hh = 7.0f + rng.nextFloat() * 2.0f;
            int64_t tseed = rng.nextLong();
            if (x >= x0 + Cfg::CHUNK || z >= z0 + Cfg::CHUNK) continue;
            if (max(Base::grove(x, z), Base::orchard(x, z)) > 0.2f) continue;   // bananal e pomar: só as árvores deles
            if (reservedAll(x, z)) continue;
            probe(x, z, p);
            if (p[2] < Cfg::BEACH + 4.0f || p[3] < roadClear + 1.0f || p[0] > 70.0f || p[1] < 0.78f) continue;
            float dens = 0.5f + 0.5f * Base::n(x * 0.02f + 3.0f, z * 0.02f);
            // floresta fechada onde o chão é terra; algumas árvores soltas no campo de grama
            float prob = (0.14f + 0.86f * p[4]) * (0.7f + 0.3f * dens) * (1.0f - smooth(35.0f, 70.0f, p[0]));
            if (roll > prob) continue;
            Trees::windTree(tacc, p[0], hh, tseed, 0.28f);
            { JavaRandom tr(tseed); Trees::bigTree(tacc, x, p[0], z, hh, tr); }
            addSolid(x, z, 0.75f);
        }
    }

    // ---- arvores das colmeias (Apiario): arvore GRANDE (10 m), com o galho do ninho ----
    if (Cfg::COLMEIAS > 0) {
        const auto& hv = Apiario::hives();
        for (int hi = 0; hi < static_cast<int>(hv.size()); hi++) {
            const Apiario::Hive& h = hv[hi];
            if (h.x < x0 || h.x >= x0 + Cfg::CHUNK || h.z < z0 || h.z >= z0 + Cfg::CHUNK) continue;
            int64_t hseed = 4242LL + hi * 977LL;
            Trees::windTree(tacc, h.y, 10.0f, hseed, 0.08f);
            JavaRandom tr(hseed);
            Trees::bigTree(tacc, h.x, h.y, h.z, 10.0f, tr, &h);
            addSolid(h.x, h.z, 0.95f);
        }
    }

    // ---- bananal (onde era a menor montanha): bananeiras com cacho, tronco com colisão ----
    {
        const float bsp = 6.5f;
        const int bcnt = static_cast<int>(km::ceil(Cfg::CHUNK / bsp));
        for (int gz = 0; gz < bcnt; gz++) for (int gx = 0; gx < bcnt; gx++) {
            float x = x0 + (gx + 0.5f) * bsp + (rng.nextFloat() - 0.5f) * bsp * 0.7f;
            float z = z0 + (gz + 0.5f) * bsp + (rng.nextFloat() - 0.5f) * bsp * 0.7f;
            float roll = rng.nextFloat();
            float hh = 4.5f + rng.nextFloat() * 1.5f;
            int64_t bseed = rng.nextLong();
            if (x >= x0 + Cfg::CHUNK || z >= z0 + Cfg::CHUNK) continue;
            if (Base::grove(x, z) < 0.25f || roll > 0.85f) continue;
            if (reservedAll(x, z)) continue;
            probe(x, z, p);
            if (p[2] < Cfg::BEACH + 4.0f || p[3] < roadClear || p[1] < 0.8f) continue;
            Trees::windTree(tacc, p[0], hh, bseed, 0.36f);
            { JavaRandom tr(bseed); Trees::banana(tacc, x, p[0], z, hh, tr, bananaOut); }
            addSolid(x, z, 0.4f);
        }
    }

    // ---- pomar (onde era a 2ª menor montanha): macieiras e laranjeiras em XADREZ ----
    {
        const float osp = 9.5f;
        const float ox = Cfg::ORCHARD_X - Cfg::ORCHARD_R;
        const float oz = Cfg::ORCHARD_Z - Cfg::ORCHARD_R;
        if (x0 + Cfg::CHUNK > ox && x0 < ox + 2.0f * Cfg::ORCHARD_R && z0 + Cfg::CHUNK > oz && z0 < oz + 2.0f * Cfg::ORCHARD_R) {
            int ix0 = static_cast<int>(km::floor((x0 - ox) / osp)) - 1;
            int ix1 = static_cast<int>(km::floor((x0 + Cfg::CHUNK - ox) / osp)) + 1;
            int iz0 = static_cast<int>(km::floor((z0 - oz) / osp)) - 1;
            int iz1 = static_cast<int>(km::floor((z0 + Cfg::CHUNK - oz) / osp)) + 1;
            for (int iz = iz0; iz <= iz1; iz++) for (int ix = ix0; ix <= ix1; ix++) {
                JavaRandom cr(ix * 73856093LL + iz * 19349663LL + Cfg::SEED * 83492791LL);   // mesma árvore em qualquer chunk
                float x = ox + (ix + 0.5f) * osp + (cr.nextFloat() - 0.5f) * osp * 0.5f;
                float z = oz + (iz + 0.5f) * osp + (cr.nextFloat() - 0.5f) * osp * 0.5f;
                float hh = 5.0f + cr.nextFloat() * 1.2f;
                int64_t tseed = cr.nextLong();
                if (x < x0 || x >= x0 + Cfg::CHUNK || z < z0 || z >= z0 + Cfg::CHUNK) continue;
                if (Base::orchard(x, z) < 0.3f) continue;
                if (reservedAll(x, z)) continue;
                probe(x, z, p);
                if (p[2] < Cfg::BEACH + 4.0f || p[3] < roadClear + 1.0f || p[1] < 0.8f) continue;
                if (((ix + iz) & 1) == 0) {
                    Trees::windTree(tacc, p[0], hh, tseed, 0.28f);
                    JavaRandom tr(tseed); Trees::appleTree(tacc, x, p[0], z, hh, tr, macaOut);
                    addSolid(x, z, 0.7f);
                } else {
                    Trees::windTree(tacc, p[0], hh, tseed, 0.28f);
                    JavaRandom tr(tseed); Trees::orangeTree(tacc, x, p[0], z, hh, tr, laranjaOut);
                    addSolid(x, z, 0.85f);
                }
            }
        }
    }

    // ---- coqueiros da praia: 8-12 m (5x o boneco). TRONCO TEM COLISÃO ----
    {
        const float pg = 9.0f;
        const int pc = static_cast<int>(Cfg::CHUNK / pg);
        for (int gz = 0; gz < pc; gz++) for (int gx = 0; gx < pc; gx++) {
            float x = x0 + (gx + 0.5f) * pg + (rng.nextFloat() - 0.5f) * 5.0f;
            float z = z0 + (gz + 0.5f) * pg + (rng.nextFloat() - 0.5f) * 5.0f;
            float roll = rng.nextFloat();
            float hh = 8.0f + rng.nextFloat() * 4.0f;
            int64_t seed = rng.nextLong();
            if (roll > 0.6f || reservedAll(x, z)) continue;
            probe(x, z, p);
            if (p[2] < 5.0f || p[2] > 37.0f || p[3] < 5.0f || p[0] < 0.3f) continue;
            pacc.windBaseY = p[0];
            pacc.windAmp = 1.7f;                       // coqueiro balança mais
            pacc.windH = hh * 0.9f;
            pacc.windPhase = static_cast<int>(seed & 0xffffLL) / 65535.0f * 6.2831855f;
            { JavaRandom tr(seed); Trees::palm(pacc, x, p[0], z, hh, tr, cocoOut); }
            addSolid(x, z, 0.4f);
        }
    }

    // ---- arbustos 1-2 m (sem colisão: o boneco passa por dentro) ----
    for (int it = 0; it < 70; it++) {
        float x = x0 + rng.nextFloat() * Cfg::CHUNK;
        float z = z0 + rng.nextFloat() * Cfg::CHUNK;
        float rx = 0.6f + rng.nextFloat() * 0.5f;
        float ry = 0.55f + rng.nextFloat() * 0.45f;
        float br = 0.85f + rng.nextFloat() * 0.3f;
        probe(x, z, p);
        if (p[2] > Cfg::BEACH + 2.0f && p[3] > 5.0f && p[0] < 90.0f && p[1] > 0.8f && !reservedAll(x, z)) {
            // chao mais baixo debaixo da moita (em ladeira/barranco o lado de baixo ficava no ar = moita flutuando)
            float hLow = p[0];
            float rr = rx * 1.05f;
            for (int k = 0; k < 8; k++) {
                float a = k * 0.7853982f;
                float hh2 = World::heightAt(x + km::cos(a) * rr, z + km::sin(a) * rr);
                if (hh2 < hLow) hLow = hh2;
            }
            Trees::blob(acc, x, hLow + ry * 0.8f, z, rx, ry, rx, Pal::bits(Pal::BUSH, br), 0.4f, rng);
        }
    }

    // ---- pedras grandes (>= 2.4 m): textura de pedra + COLISÃO ----
    for (int it = 0; it < 14; it++) {
        float x = x0 + rng.nextFloat() * Cfg::CHUNK;
        float z = z0 + rng.nextFloat() * Cfg::CHUNK;
        float hh = 2.4f + rng.nextFloat() * 1.6f;
        float wd = 1.1f + rng.nextFloat() * 0.6f;
        float br = 0.78f + rng.nextFloat() * 0.22f;
        probe(x, z, p);
        if (p[2] > 8.0f && p[3] > 6.0f && !reservedAll(x, z)) {
            float rx = hh * wd * 0.5f;
            Trees::blobRock(racc, x, p[0] + hh * 0.3f, z, rx, hh * 0.55f, rx, Pal::bits(Color::hex(0xFFFFFF), br), 0.5f, rng);
            // SEM parede invisível: a pedra vira chão andável (o boneco sobe nela), ver ChunkManager.rockFloor
            rocks.push_back(x); rocks.push_back(z); rocks.push_back(p[0] + hh * 0.3f); rocks.push_back(rx); rocks.push_back(hh * 0.55f);
        }
    }

    // ---- pedrinhas pequenas espalhadas na grama e na floresta (enfeite, sem colisão) ----
    for (int it = 0; it < 45; it++) {
        float x = x0 + rng.nextFloat() * Cfg::CHUNK;
        float z = z0 + rng.nextFloat() * Cfg::CHUNK;
        float r = 0.18f + rng.nextFloat() * 0.3f;
        float br = 0.7f + rng.nextFloat() * 0.3f;
        probe(x, z, p);
        if (p[2] > Cfg::BEACH + 4.0f && p[3] > 3.5f && p[0] < 60.0f && !reservedAll(x, z)) {
            Trees::blobRock(rdacc, x, p[0] + r * 0.35f, z, r * 1.2f, r * 0.7f, r, Pal::bits(Color::hex(0xFFFFFF), br), 0.4f, rng);
        }
    }

    // ---- cogumelos de verdade (caule + chapéu): grupinhos na grama e na beira da mata ----
    {
        const int nCog = static_cast<int>(14 * Cfg::COGUMELOS);
        for (int it = 0; it < nCog; it++) {
            float bx = x0 + rng.nextFloat() * Cfg::CHUNK;
            float bz = z0 + rng.nextFloat() * Cfg::CHUNK;
            int kind = rng.nextInt(4);
            int cnt2 = 1 + rng.nextInt(4);
            for (int q = 0; q < cnt2; q++) {
                float x = bx + (rng.nextFloat() - 0.5f) * 1.4f;
                float z = bz + (rng.nextFloat() - 0.5f) * 1.4f;
                float sc = 0.85f + rng.nextFloat() * 0.8f;
                int64_t sd = rng.nextLong();
                probe(x, z, p);
                if (p[2] > Cfg::BEACH + 6.0f && p[3] > 4.5f && p[0] < 60.0f && p[1] > 0.8f && !reservedAll(x, z)) {
                    JavaRandom fr(sd);
                    Flora::mushroom(dacc, x, p[0], z, kind, sc, fr);
                }
            }
        }
    }

    // ---- flores (5 tipos: margarida, papoula, tulipa, lavanda, girassol) em manchas pelo campo de grama ----
    {
        const int nFlo = static_cast<int>(34 * Cfg::FLORES);
        for (int it = 0; it < nFlo; it++) {
            float bx = x0 + rng.nextFloat() * Cfg::CHUNK;
            float bz = z0 + rng.nextFloat() * Cfg::CHUNK;
            int type = rng.nextInt(5);
            int nn = 4 + rng.nextInt(5);
            float patch = Base::n(bx * 0.025f + 5.0f, bz * 0.025f + 9.0f);      // só em alguns lugares do mapa (manchas de flores)
            for (int q = 0; q < nn; q++) {
                float x = bx + (rng.nextFloat() - 0.5f) * 2.8f;
                float z = bz + (rng.nextFloat() - 0.5f) * 2.8f;
                int64_t sd = rng.nextLong();
                if (patch < -0.15f) continue;
                probe(x, z, p);
                if (p[2] > Cfg::BEACH + 6.0f && p[3] > 4.5f && p[0] < 40.0f && p[1] > 0.85f && p[4] < 0.45f && !reservedAll(x, z)) {
                    JavaRandom fr(sd);
                    Flora::flower(dacc, type, x, p[0], z, fr);
                }
            }
        }
    }

    // ---- prados de flores das colmeias (Apiario): as abelhas pousam nestas flores ----
    if (Cfg::COLMEIAS > 0) {
        Apiario::forEachFlower(x0, z0, x0 + Cfg::CHUNK, z0 + Cfg::CHUNK, [&](int type, float fx, float fy, float fz, int64_t seed) {
            JavaRandom fr(seed);
            Flora::flower(dacc, type, fx, fy, fz, fr);
        });
    }

    b.layer = 1;
    b.key = cz * Cfg::CHUNKS + cx;
    for (auto& pt : acc.finish())  { b.parts.push_back(std::move(pt)); b.mats.push_back(ChunkMat::DECO); }
    for (auto& pt : racc.finish()) { b.parts.push_back(std::move(pt)); b.mats.push_back(ChunkMat::DECOROCK); }
    for (auto& pt : pacc.finish()) { b.parts.push_back(std::move(pt)); b.mats.push_back(ChunkMat::PALM); }
    for (auto& pt : tacc.finish()) { b.parts.push_back(std::move(pt)); b.mats.push_back(ChunkMat::PALM); }
    for (auto& pt : dacc.finish()) { b.parts.push_back(std::move(pt)); b.mats.push_back(ChunkMat::DECO_DETAIL); }
    for (auto& pt : rdacc.finish()) { b.parts.push_back(std::move(pt)); b.mats.push_back(ChunkMat::DECOROCK_DETAIL); }
    b.minY = -5.0f;
    b.maxY = 240.0f;
    return b;
}

}  // namespace ChunkBuilder
