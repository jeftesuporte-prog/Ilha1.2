#pragma once
#include <cstdint>
#include <cstring>
// Cor RGBA em float (0..1). Equivale ao com.badlogic.gdx.graphics.Color.valueOf("RRGGBB").
struct Color {
    float r, g, b, a;
    static constexpr Color hex(uint32_t rgb) {
        return { ((rgb >> 16) & 255u) / 255.0f, ((rgb >> 8) & 255u) / 255.0f, (rgb & 255u) / 255.0f, 1.0f };
    }
};

// ---- empacotamento de cor do libGDX (Color.toFloatBits / NumberUtils) ----
// A cor do vértice vai dentro de um float, com os 4 bytes R,G,B,A. Mantemos o mesmo formato do Kotlin:
// no Vulkan o atributo é lido como R8G8B8A8_UNORM (os mesmos 4 bytes).
inline float intToFloatColor(uint32_t v) {
    v &= 0xfeffffffu;                      // evita NaN (zera o bit mais baixo do alpha)
    float f; std::memcpy(&f, &v, 4); return f;
}
inline float toFloatBits(float r, float g, float b, float a) {
    uint32_t c = (static_cast<uint32_t>(static_cast<int>(255.0f * a)) << 24) |
                 (static_cast<uint32_t>(static_cast<int>(255.0f * b)) << 16) |
                 (static_cast<uint32_t>(static_cast<int>(255.0f * g)) << 8) |
                  static_cast<uint32_t>(static_cast<int>(255.0f * r));
    return intToFloatColor(c);
}
inline uint32_t floatToIntColor(float value) {
    uint32_t bits; std::memcpy(&bits, &value, 4);
    bits |= static_cast<uint32_t>(static_cast<int>(static_cast<float>(bits >> 24) * (255.0f / 254.0f))) << 24;
    return bits;
}
