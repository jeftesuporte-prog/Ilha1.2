#include "MeshAccum.h"
#include "KMath.h"

void MeshAccum::tri(float ax, float ay, float az, float bx, float by, float bz, float cx, float cy, float cz, float col) {
    float ux = bx - ax, uy = by - ay, uz = bz - az;
    float vx = cx - ax, vy = cy - ay, vz = cz - az;
    float nx = uy * vz - uz * vy;
    float ny = uz * vx - ux * vz;
    float nz = ux * vy - uy * vx;
    float l = km::sqrt(nx * nx + ny * ny + nz * nz);
    if (l < 1e-9f) return;
    triN(ax, ay, az, bx, by, bz, cx, cy, cz, nx / l, ny / l, nz / l, col);
}

void MeshAccum::triOut(float ax, float ay, float az, float bx, float by, float bz, float cx, float cy, float cz,
                       float ox, float oy, float oz, float col) {
    triOutUV(ax, ay, az, bx, by, bz, cx, cy, cz, ox, oy, oz, col, false);
}

void MeshAccum::triOutUV(float ax, float ay, float az, float bx, float by, float bz, float cx, float cy, float cz,
                         float ox, float oy, float oz, float col, bool uv) {
    float ux = bx - ax, uy = by - ay, uz = bz - az;
    float vx = cx - ax, vy = cy - ay, vz = cz - az;
    float nx = uy * vz - uz * vy;
    float ny = uz * vx - ux * vz;
    float nz = ux * vy - uy * vx;
    float l = km::sqrt(nx * nx + ny * ny + nz * nz);
    if (l < 1e-9f) return;
    nx /= l; ny /= l; nz /= l;
    float mx = (ax + bx + cx) / 3.0f - ox;
    float my = (ay + by + cy) / 3.0f - oy;
    float mz = (az + bz + cz) / 3.0f - oz;
    bool flip = nx * mx + ny * my + nz * mz < 0.0f;
    const float k = 0.35f;
    const float ky = 0.2f;
    if (nv_ + 3 > MAXV) flush();
    // (u, v) de cada vértice: relativos ao centro (ox,oy,oz) => valores pequenos
    auto U = [&](float px, float py) { return uv ? (px - ox) * k + (py - oy) * ky : 0.0f; };
    auto V = [&](float pz, float py) { return uv ? (pz - oz) * k + (py - oy) * ky : 0.0f; };
    if (flip) {
        put(ax, ay, az, -nx, -ny, -nz, col, U(ax, ay), V(az, ay));
        put(cx, cy, cz, -nx, -ny, -nz, col, U(cx, cy), V(cz, cy));
        put(bx, by, bz, -nx, -ny, -nz, col, U(bx, by), V(bz, by));
    } else {
        put(ax, ay, az, nx, ny, nz, col, U(ax, ay), V(az, ay));
        put(bx, by, bz, nx, ny, nz, col, U(bx, by), V(bz, by));
        put(cx, cy, cz, nx, ny, nz, col, U(cx, cy), V(cz, cy));
    }
}

void MeshAccum::triN(float ax, float ay, float az, float bx, float by, float bz, float cx, float cy, float cz,
                     float nx, float ny, float nz, float col) {
    if (nv_ + 3 > MAXV) flush();
    put(ax, ay, az, nx, ny, nz, col, 0.0f, 0.0f);
    put(bx, by, bz, nx, ny, nz, col, 0.0f, 0.0f);
    put(cx, cy, cz, nx, ny, nz, col, 0.0f, 0.0f);
}

void MeshAccum::triVC(float ax, float ay, float az, float ca, float ua, float va,
                      float bx, float by, float bz, float cb, float ub, float vb,
                      float cx, float cy, float cz, float cc, float uc, float vc,
                      float nx, float ny, float nz) {
    if (nv_ + 3 > MAXV) flush();
    put(ax, ay, az, nx, ny, nz, ca, ua, va);
    put(bx, by, bz, nx, ny, nz, cb, ub, vb);
    put(cx, cy, cz, nx, ny, nz, cc, uc, vc);
}

void MeshAccum::put(float x, float y, float z, float nx, float ny, float nz, float c, float u, float v) {
    size_t i = static_cast<size_t>(nv_) * stride_;
    buf_[i++] = x; buf_[i++] = y; buf_[i++] = z;
    buf_[i++] = nx; buf_[i++] = ny; buf_[i++] = nz;
    buf_[i++] = c;
    if (stride_ == 9) {
        buf_[i++] = u; buf_[i] = v;
    } else if (stride_ == 10) {
        float t = km::coerceIn((y - windBaseY) / windH, 0.0f, 1.0f);
        buf_[i++] = t * t * windAmp; buf_[i++] = windPhase; buf_[i] = windFlutter;
    }
    nv_++;
}

void MeshAccum::flush() {
    if (nv_ > 0) {
        parts_.emplace_back(buf_.begin(), buf_.begin() + static_cast<size_t>(nv_) * stride_);
        nv_ = 0;
    }
}

std::vector<std::vector<float>> MeshAccum::finish() {
    flush();
    return parts_;
}
