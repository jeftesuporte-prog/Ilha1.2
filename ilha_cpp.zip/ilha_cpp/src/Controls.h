#pragma once
// Port de Controls.kt (sem teclado/Gdx): esquerda da tela = analógico de andar (ancorado onde o dedo encosta, corre se empurrar
// até o fim); direita = arrastar para olhar; botão PULAR no canto inferior direito; botões do barco (REMAR/ESQ/DIR/ação 1/ação 2).
// Coordenadas em pixels de toque (y de cima para baixo), como no Android. Independente de plataforma (testável no PC).
#include <algorithm>
#include <cmath>

class Controls {
public:
    // ---- estado lido pelo jogo ----
    float moveX = 0, moveY = 0;      // andar: direita(+) e frente(+), -1..1
    float lookX = 0, lookY = 0;      // arrasto acumulado desde o último consumeLook() (pixels)
    bool run = false;
    bool jump = false;               // "tocou agora" (o jogo zera depois de ler)
    float radius = 100.0f;

    // botões do barco (o Barco escolhe quais aparecem)
    bool inBoat = false;             // boneco no comando do barco: some o PULAR
    bool showRow = false;            // mostra ESQ / DIR / REMAR
    const char* act1Text = nullptr;  // ação 1 (acima): DESAMARRAR / ENTRAR / AMARRAR
    const char* act2Text = nullptr;  // ação 2 (ao lado): SAIR
    bool act1 = false, act2 = false; // "tocou agora"

    // analógico (para desenhar)
    float joyOX = 0, joyOY = 0, joyCX = 0, joyCY = 0;
    bool joyActive() const { return movePtr_ != -1; }

    void setScreen(int w, int h) {
        w_ = static_cast<float>(w); h_ = static_cast<float>(h);
        radius = std::max(70.0f, std::min(w_, h_) * 0.12f);
    }
    float width() const { return w_; }
    float height() const { return h_; }

    // ---- geometria dos botões (centro e raio, em pixels y-down) ----
    bool jumpHeld() const { return jumpPtr_ != -1; }
    float jumpR() const { return radius * 0.8f; }
    float jumpX() const { return w_ - radius * 1.7f; }
    float jumpY() const { return h_ - radius * 1.7f; }
    float goX() const { return w_ - radius * 1.7f; }
    float goY() const { return h_ - radius * 1.7f; }
    float goR() const { return radius * 0.95f; }
    float leftX() const { return radius * 1.5f; }
    float rightX() const { return radius * 3.5f; }
    float leftY() const { return h_ - radius * 1.7f; }
    float sideR() const { return radius * 0.8f; }
    float act1X() const { return w_ - radius * 1.7f; }
    float act1Y() const { return h_ - radius * 3.7f; }
    float act1R() const { return radius * 0.75f; }
    float act2X() const { return w_ - radius * 3.9f; }
    float act2Y() const { return h_ - radius * 1.7f; }
    float act2R() const { return radius * 0.7f; }
    bool rowLHeld() const { return showRow && ptrL_ != -1; }
    bool rowRHeld() const { return showRow && ptrR_ != -1; }
    bool rowGoHeld() const { return showRow && ptrGo_ != -1; }
    bool act1Held() const { return ptrA1_ != -1; }
    bool act2Held() const { return ptrA2_ != -1; }

    // ---- toques ----
    void touchDown(int id, float sx, float sy) {
        if (act1Text != nullptr && hit(sx, sy, act1X(), act1Y(), act1R())) { if (ptrA1_ == -1) ptrA1_ = id; act1 = true; return; }
        if (act2Text != nullptr && hit(sx, sy, act2X(), act2Y(), act2R())) { if (ptrA2_ == -1) ptrA2_ = id; act2 = true; return; }
        if (showRow) {
            if (hit(sx, sy, goX(), goY(), goR())) { if (ptrGo_ == -1) ptrGo_ = id; return; }
            if (hit(sx, sy, leftX(), leftY(), sideR())) { if (ptrL_ == -1) ptrL_ = id; return; }
            if (hit(sx, sy, rightX(), leftY(), sideR())) { if (ptrR_ == -1) ptrR_ = id; return; }
        }
        const float jx = sx - jumpX(), jy = sy - jumpY();
        if (!inBoat && jx * jx + jy * jy <= jumpR() * jumpR() * 1.6f) {       // tocou no botão de pular
            if (jumpPtr_ == -1) jumpPtr_ = id;
            jump = true;
            return;
        }
        if (sx < w_ / 2) {
            if (movePtr_ == -1) {
                movePtr_ = id;
                joyOX = sx; joyOY = sy;
                joyCX = joyOX; joyCY = joyOY;
            }
        } else if (lookPtr_ == -1) {
            lookPtr_ = id;
            lastX_ = sx; lastY_ = sy;
        }
    }
    void touchMove(int id, float sx, float sy) {
        if (id == movePtr_) {
            joyCX = sx; joyCY = sy;
        } else if (id == lookPtr_) {
            lookX += sx - lastX_;
            lookY += sy - lastY_;
            lastX_ = sx; lastY_ = sy;
        }
    }
    void touchUp(int id) {
        if (id == movePtr_) movePtr_ = -1;
        if (id == lookPtr_) lookPtr_ = -1;
        if (id == jumpPtr_) jumpPtr_ = -1;
        if (id == ptrL_) ptrL_ = -1;
        if (id == ptrR_) ptrR_ = -1;
        if (id == ptrGo_) ptrGo_ = -1;
        if (id == ptrA1_) ptrA1_ = -1;
        if (id == ptrA2_) ptrA2_ = -1;
    }
    void cancelAll() {
        movePtr_ = lookPtr_ = jumpPtr_ = ptrL_ = ptrR_ = ptrGo_ = ptrA1_ = ptrA2_ = -1;
        moveX = moveY = 0.0f; run = false;
    }

    // Chame todo quadro, antes de usar moveX/moveY/run.
    void poll() {
        float mx = 0, my = 0;
        bool joyRun = false;
        if (movePtr_ != -1) {
            mx = clampf((joyCX - joyOX) / radius, -1.0f, 1.0f);
            my = clampf(-(joyCY - joyOY) / radius, -1.0f, 1.0f);
            joyRun = mx * mx + my * my > 0.85f;
        }
        moveX = clampf(mx, -1.0f, 1.0f);
        moveY = clampf(my, -1.0f, 1.0f);
        run = joyRun;
    }
    void consumeLook() { lookX = 0.0f; lookY = 0.0f; }

private:
    static float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
    static bool hit(float sx, float sy, float cx, float cy, float r) {
        const float dx = sx - cx, dy = sy - cy;
        return dx * dx + dy * dy <= r * r * 1.5f;
    }
    float w_ = 1, h_ = 1;
    int movePtr_ = -1, lookPtr_ = -1, jumpPtr_ = -1, ptrL_ = -1, ptrR_ = -1, ptrGo_ = -1, ptrA1_ = -1, ptrA2_ = -1;
    float lastX_ = 0, lastY_ = 0;
};
