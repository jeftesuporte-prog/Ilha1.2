#pragma once
// Distâncias de carregamento ("streaming") e qualidade automática, no estilo dos battle royales de celular:
// só existe o que está perto; a névoa esconde o corte; o que está na FRENTE do jogador carrega primeiro;
// e se o FPS cai, os raios encolhem sozinhos (e voltam a crescer se o celular aguentar).
//
// Atenção: as distâncias reais do Free Fire não são públicas. Os valores abaixo são escolhas minhas para celular;
// o nível 3 (ALTO) é exatamente o do jogo original (Cfg.TERRAIN_R = 430, Cfg.DECO_R = 250...).
#include <cmath>

struct StreamProfile {
    const char* name;
    float terrainR;     // raio de carregamento do terreno (m)
    float decoR;        // árvores, pedras, arbustos (m)
    float detailR;      // coisinhas pequenas: flores, cogumelos, frutas no chão (m)  [usado na etapa 3B]
    float shadowR;      // sombras (m)                                                 [usado na etapa 9]
    float fireflyR;     // vaga-lumes (m)                                              [usado na etapa 10]
    float fogFar;       // distância em que a névoa cobre tudo; menor = esconde o corte do terreno
    float keepExtra;    // histerese: só descarrega depois de raio + isto (evita carregar/descarregar na borda)
    int maxPending;     // quantos chunks podem estar sendo montados ao mesmo tempo
    int uploadsPerFrame;// quantos chunks sobem para a GPU por quadro
    int maxTerrainChunks;
    int maxDecoChunks;
};

namespace Streaming {
constexpr int LEVELS = 4;
constexpr int DEFAULT_LEVEL = 2;                 // começa em MÉDIO e o controle automático sobe/desce
const StreamProfile& profile(int level);         // 0 = MÍNIMO, 1 = BAIXO, 2 = MÉDIO, 3 = ALTO (= original)
// Quanto um chunk "vale" para a fila de carregamento: menor = carrega antes. Chunks na frente ganham de chunks atrás.
float priority(float dist, float toX, float toZ, float dirX, float dirZ);
}

// Observa o tempo de cada quadro e sugere subir/descer o nível de qualidade.
// Regras: janelas de 2 s; FPS < 32 por 4 s seguidos => desce 1 nível; FPS > 55 por 12 s => sobe 1 nível
// (no máximo a cada 8 s). Se descer logo depois de subir, o nível mais alto fica proibido por 3 minutos (sem oscilar).
class QualityController {
public:
    explicit QualityController(int level = Streaming::DEFAULT_LEVEL) : level_(level), ceiling_(Streaming::LEVELS - 1) {}
    // dt = tempo real do quadro em segundos. Devolve true se o nível mudou.
    bool frame(float dt);
    int level() const { return level_; }
    float lastFps() const { return fps_; }

private:
    int level_;
    int ceiling_;
    float clock_ = 0.0f;          // tempo total observado
    float winT_ = 0.0f;           // tempo na janela atual
    int winFrames_ = 0;
    float fps_ = 60.0f;
    int lowWins_ = 0, highWins_ = 0;
    float lastChange_ = -100.0f;
    float lastUp_ = -100.0f;
    float ceilingUntil_ = 0.0f;
};
